# Passation C1 du 07/10/2026 (session cloud, branche `claude/v7-simultaneous`)

**Contexte.** C2, C3 et C7 sont exclus. Avec Behbahani–Lam, tout srg(99,14,1,2) est asymétrique, donc **C1 est tout le
problème de Conway**. Cette page résume ce que la session a établi et ce qu'il faut savoir avant de reprendre.

## Acquis de la session (notes 155 à 164)
| Note | Résultat | Statut |
|---|---|---|
| 155 | Invariant de classe mod 7 ; transferts = q + ⟨q_v, 1⟩ ; V7 reconstruit | démontré, calculs exacts |
| 156 | Pas de route par réseaux à la C2 (masse du genre de rang 48 ≈ 10¹²¹) | calcul |
| 157 | **Route Ω complète** : un complément étoilé enraciné, valeur propre 3, H = N[v] ∪ 30 labels ; équivalence (★) : Γ 12-régulier sur les 84 labels avec T² = 7T | démontré, validé sur des SRG connus |
| 158 | Deux étoiles mates = boule de triangle ; théorème de rang 8 (Z = F₋₄ ⊕ F₃) ; étage F presque forcé (≤ 2 branches) | démontré, vérifié sur BvLS |
| 159–160 | **Second srg(243,22,1,2)**, tordu ; il réfute la conjecture de Reimbayev et F20 | vérificateur autonome, nauty |
| 161 | Dépôt openai/math : rien d'utile pour C1 (leur hiérarchie de moments = note 91) | — |
| 162 | Inventaire des 12 dépôts, avec annexes | — |
| 163 | **Étage colonnes = plan à blocs à trois couches** (60 blocs de 6 sur 36 points, concurrences 2J − 4 permutations) ; ≈ 1,5·10¹¹ classes de C ; kissat et le solveur dédié restent indécis, même sur l'instance réelle de BvLS | formules exactes sur 286 triangles ; mesures |
| 164 | La piste « cartes D₇ / holonomie » : le changement de carte n'est pas dans W(D) dès qu'il y a torsion ; la branche non tordue = Makhnev / L1 | calcul sur les deux 243 |

## Ce qu'il faut savoir avant de reprendre C1
1. **Bancs d'essai obligatoires.** Tout lemme de non-existence doit d'abord passer sur Paley(9), BvLS et **le 243 tordu**
   (`data/srg243/`). Un lemme valable pour toute la famille λ = 1, μ = 2 ne peut pas exclure 99, puisque le 243 tordu
   existe. Il faut utiliser des nombres propres à 99 (7 | t, côté 7-adique).
2. **Routes déjà mesurées comme trop chères.**
   - Hiérarchie locale jusqu'à 8 sommets : bute sur le mur L16 (note 91).
   - Genre de réseaux de rang 48 : trop gros (note 156).
   - Énumération des boules de triangle puis des colonnes : ≥ 10¹⁰ heures CPU (note 163).
3. **Règles de travail.**
   - UNKNOWN n'est jamais UNSAT, et le SAT d'une relaxation n'est jamais le SAT du graphe.
   - Relire les notes existantes avant de lancer une campagne présentée comme nouvelle (leçon de la note 161).
4. **Pistes encore ouvertes, à mon avis.**
   - Une obstruction structurelle sur le plan à trois couches de la note 163, de type double couverture orthogonale,
     propre à m = 12.
   - Des contraintes globales sur la famille des holonomies σ_T des 231 triangles (Σ fix σ_T = 2P ≤ 2302).
   - L'arithmétique 7-adique : 25 ≤ rang₇(A − 3I) ≤ 43 ; il reste à resserrer.
5. **Code utile** (`code/omega/`) :
   - `colmodel.py` : extraction de la structure à trois couches d'un graphe ;
   - `colgram.py` : vue de Gram ;
   - `colsolve.c` et `colsat.py` : solveurs ;
   - `switch243.py` : bascule de triangle ;
   - `code/moments/` : hiérarchie exacte ;
   - `data/srg243/hexagons.c`, `verify_srg243.py`.
