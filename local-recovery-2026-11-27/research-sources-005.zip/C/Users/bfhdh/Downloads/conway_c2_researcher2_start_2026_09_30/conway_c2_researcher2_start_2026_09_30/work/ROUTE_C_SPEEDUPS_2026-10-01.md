# Route (C): two new reductions, measured (2026-10-01, evening)

**Context.** These follow the audit `work/ROUTE_C_SPEEDUP_AUDIT.md`, section E. They are developed beside the production engine and
not yet deployed.
- The AWS run (4 × c7a.8xlarge, since 20:12 UTC) uses the frozen engine: frame_dfs b48cf844, hstage_stream cfbfd9c0.
- Development files are in `Desktop\c2_experimental\scripts\`:
  - `make_frame_dfs_next.py` generates `frame_dfs_next.py`;
  - `make_hstage_stream_next.py` generates `hstage_stream_next.py`;
  - test scripts: `ab_sym2.py`, `ab_chunk.py`.
- Both generators start from the exact AWS files (sha asserted). Every textual replacement is asserted to match exactly once.

## 1. Depth-1 symmetry breaking (flag FD_SYM2)

**Rule.**
1. At depth 0 the engine already branches on a target-1 point β0. It keeps one representative per orbit of the candidates through
   β0 under G0 = ⟨reflections in the roots of U orthogonal to y1, y2, β0⟩ (C2 28/09, PROVEN).
2. **New.** In the branch of a depth-0 representative h1, choose a target-1 point β1 not touched by h1, such that
   G1 = ⟨reflections in the roots orthogonal to y1, y2, β0, h1, β1⟩ is non-trivial.
   - Among the admissible β1, take the one with the fewest candidates compatible with h1.
   - Branch at depth 1 on β1 only, and only on one representative per G1-orbit of S = {candidates through β1 compatible with h1}.
   - If no such β1 exists, depth 1 keeps the engine's own heuristic.

**Soundness (same argument as the depth-0 rule).**
- **G1 preserves the problem.** G1 ⊂ W(R) ⊂ Aut(U) fixes y1, y2, β0, β1 and h1. The stage-1 problem is defined from (U, y1, y2)
  alone: admissible h, new roots, y-hit / flex / exact targets, compatibility (orthogonality, Same/Opp cells, no shared target-1
  point), Lemma U+ and boundary points. G1 therefore maps true frames containing h1 to true frames containing h1.
- **β1 must be covered.** β1 has target 1 and is not covered by h1. A frame containing h1 therefore covers β1 with exactly one
  h2 ∈ S. Some g ∈ G1 maps h2 to its representative, up to sign; the h are kept one per ± line, and the frame conditions are
  sign-symmetric. So g(frame) lies in the representative's subtree.
- **The engine's relaxations do not matter.** The engine may use only a subset of the true constraints, e.g. at most 1000
  boundary points. The argument only needs g(true frame) to be a true frame, and a true frame passes every relaxed test.
- **Removal of explored candidates stays sound.** After a branch is explored, its candidate is removed from cand. This cannot lose
  a frame: two candidates through β0, or two through β1, can never be in the same frame, because the point is covered exactly once.
- **Representatives.** They are the minima of the connected components of the reflection graph on S (`sym_reps`, the production
  routine). A component lies inside a G1-orbit, so this is sound even if S is not G1-invariant.

**Measurements.** A/B against the exact AWS engine, same pairs (sampled searched pairs of the AWS run), same environment, this PC:

| Lattice | Pairs | Nodes old → new | Time per searched pair | Verdict mismatches |
|---|---|---|---|---|
| 011 | 10 + 10 | ÷3.84, ÷3.48 | ×1.74, ×2.19 faster | 0 |
| 018 | 10 | ÷3.85 | ×1.51 | 0 |
| 014 | 10 | ÷3.92 | ×1.70 | 0 |
| 019 | 10 | ÷4.43 | ×2.40 | 0 |
| 032 | 12 | ÷6.81 | ×1.96 | 0 |
| 034 | 12 | ÷4.89 | ×1.28 | 0 |
| 118 (rich; full calibration job, end to end) | 1,272 | – | ×0.96 (overhead) | – |

- Remaining time split on 011 (12 pairs, new engine): DFS ~60 %, pair setup ~20 %, depth-1 mask computation ~20 %.
- **To do before deployment:** enable FD_SYM2 per lattice (root-poor lattices only, for example ≤ 100 roots), or gate it per pair.

## 2. Twin-canonical rule (flag FD_TWINCANON)

**Rule.** Skip a pair P of U (new verdict `TWIN-CANON (k(U+)<k(U))`, counted as covered in `chunk_done`) when all of these hold:
- (a) the twin U⁺ = F(U)+J of Astra 29/09 §5 (PROVEN; roots by §5.2) has the root-system type of U;
- (b) that type belongs to U alone among the 156;
- (c) k(U⁺, P) < k(U, P).

The key is k(L; y1, y2) = (max E, min E, histogram of Y(α) over the positive roots α of L), with E = E_L(y1), E_L(y2). It is
intrinsic and symmetric in y1, y2 and their signs.

**Soundness.**
- Suppose P has a frame. Then U⁺ holds the same frame (§5). U⁺ is one of the 156, since it is odd unimodular with no norm-1 vector
  under min K* ≥ 8/7.
- U⁺ has U's type, so U⁺ ≅ U by (b). An isometry φ maps the frame to the pair P′ = φ(P) of U.
- k(U, P′) = k(U⁺, P) < k(U, P).
- By completeness of the enumeration, P′ is equivalent to a listed pair P″ (up to Aut(U) × signs × order) with the same k.
- Every skip strictly decreases k; the swap rule keeps k and never cycles. Following skips therefore ends at a pair excluded by a
  sound test, and the frame would have to exist there. Contradiction.
- The lattice-level rule is unchanged: U is excluded when all its chunks are done and every non-skipped pair is excluded.
  No cross-lattice dependency is created.

**Verified prerequisite.** On all 156 envelope files, the type computed from the actual roots equals the Borcherds label in the
tracker, and the root counts agree. Checked in 48 s; 0 mismatches. This also backs the existing twin transfer.

**Measurement.** Sampled searched pairs of the AWS run; time model 0.107 s + 3 µs per node; share of the searched-pair time skipped:

| Lattice | 011 | 018 | 014 | 019 | 032 | 034 |
|---|---|---|---|---|---|---|
| Searched-pair time skipped | 33.1 % | 13.7 % | 14.5 % | 3.9 % | 3.9 % | 3.9 % |

- The skipped side is the costly one: a lower E means more y-hits and smaller trees.
- End to end (job 118:2:8): same stream (sha 0651f2b1…, 1,272 pairs), chunk_done True for both engines, no non-excluded pair.
  118 has no same-type twins.

## 3. Combined estimate (to be confirmed on full jobs)
| Lattice | Share of remaining hours | Twin rule | Then FD_SYM2 | Combined |
|---|---|---|---|---|
| 011 | 20 % | −33 % | ÷1.9 | ≈ ÷2.8 |
| 018 | 12 % | −14 % | ÷1.5 | ≈ ÷1.75 |
| 014 | 7 % | −14.5 % | ÷1.7 | ≈ ÷2 |
| 019 | 5 % | – | – | ≈ ÷2.5 |
| 032 | 5 % | – | – | ≈ ÷2 |
| 034 | 4 % | – | – | ≈ ÷1.3 |

- Over these six lattices (53 % of the remaining estimate): ≈ ÷2.1.
- The other 47 % is not measured yet. If it gains ÷1.5, the whole remaining batch would take ≈ ÷1.8 fewer CPU-hours.

## 4. Deployment constraints (the AWS run is live)
- **A new package** is needed: engine files, MANIFEST, and a calibration reference recomputed with the new consumer.
  - The 118:2 counts differ only through the tracker snapshot. The new consumer reads the lab tracker; the package must ship one
    snapshot and keep it.
- **Import** must accept both engine shas.
- **stream_finish** must count `TWIN-CANON` as covered (chunk_done already does).
- **Switching the fleet:** drain the current machines (`monitor_q.py --drain`) and launch new ones on the new package. The queue
  is unchanged; mixed engines are fine, because the rule only skips the costlier member of a twin couple, and the old engine
  searches both.
- **Not done yet:**
  - per-lattice gating of FD_SYM2;
  - a second reader of both proofs;
  - a full-chunk A/B on a root-poor lattice (about 2 h of one core per job).

## 5. Follow-up (same evening)

**Twin-canonical rule: consistency check on a COMPLETE pair list (lattice 028).**
- **Method.** `scripts/twin_canon_fullcheck.py` reproduced the full pair list of 028 with the package producer: 8 chunks, all
  complete, 50,646 pairs, 1,050 distinct keys.
- **Twin data.** It computed the twin data of every untrapped, swap-canonical pair: 197 same-type twin pairs, of which 151 are
  ties and **20 skippable**.
- **(i) Twin key present.** For all 20 skippable pairs, the twin key k(U⁺, P) is the key of a listed pair.
- **(ii) Involution.** For all 20, the examined set contains the partner pair with key k(U⁺, P) whose twin key is k(U, P):
  **20 / 20**.
- **Scope.** This is a necessary-condition check: it would catch a wrong twin identification or a wrong key. It does not replace
  the proof.

**Depth-1 symmetry breaking is now two-phase (FD_SYM2_T, default 10,000).**
- **Phase 1.** The production search runs with a small node budget. If it completes, the result is exactly the production result,
  same nodes and same verdict, with no overhead.
- **Phase 2.** Otherwise the depth-1 masks are computed and the search restarts with them.

A/B against the AWS engine:

| Lattice | Speed-up | Nodes ÷ | Verdict mismatches |
|---|---|---|---|
| 011 | ×1.69 | 3.84 | 0 |
| 018 | ×1.43 | 3.85 | 0 |
| 034 | ×1.25 | 4.74 | 0 |
| 118:2 full job | ×1.03 (always-on was ×0.96) | – | 0 (same stream) |

- With a budget of 30,000 the speed-ups were 011 ×1.65, 032 ×1.83, 018 ×1.39 and 034 ×1.18.

## 6. Lead 4 — the lattices outside the batch (O24 = 000, Golay family 001/002/004/010)

**O24.** Status before tonight:
- 141 (y1, y2) classes (C1).
- 86 excluded by the whole-class LP (certificates verified twice).
- 9 classes searched EMPTY.
- **47 classes never run** (`logs/o24_todo_47.txt`).

Profile of the last runs:

| Class | DFS (numba) | Stage 2 | Leaves | Local survivors |
|---|---|---|---|---|
| 21 | 834 s | **11,677 s** | 2.8·10⁵ | 200 |
| 16 | 960 s | 4,188 s | 1.6·10⁵ | – |

The joint star-sum check was pure Python, about 58 s per surviving leaf on class 21.
- **New: `scripts/o24_joint_nb.py`.** The same search in numba: 42 slots, distinct words, orientation towards the star, coordinate
  bounds.
  - Validation by a **planted-solution differential test**: targets are replaced by the sums of a random valid assignment.
    4/4 real leaves of class 21 gave identical solution lists, and both versions found the planted solution.
  - On the 200 real survivors of class 21: 41.9 s in total (0.21 s per leaf), 0 joint solutions, as recorded.
- **New: `scripts/o24_run_fast.py`.** kernel 3 + Lemma Z re-check + numba joint stage + the same full (F) check.
- **Cost of the 47 remaining classes:** about 15 min per class, i.e. **≈ 12 CPU-hours instead of ≈ 100–160**.
  - Not launched: it is a larger run. Plan: 4 threads on the PC (≈ 3 h), or 1 AWS job type.

**001 (a1^8), Golay frame (structures 3e9690b).**
- Known so far: 14 y1 classes; pair classes enumerated for classes 0 (819) and 1 (1,957), swap-filtered.
  **[Corrected 02/10, see section 9: 1,957 is the class-1 count before the swap filter; 1,949 after it.]**
- **New measurement with the current engine** (characteristic trap, Astra 28/09, which structures did not have on 27/09):
  - first 309 of 819 pair classes of class 0: **75 % killed by the trap** at about 1 ms;
  - the rest searched: 31 die at the local star sums, 45 at stage 1, about 3.3 s per pair, slowest 12.6 s;
  - no survivor.
- Extrapolation: a few CPU-hours for all of 001.
- **Missing:** the y2 enumeration and Stab(y1) reduction for the other 12 y1 classes (structures' `golay_y2.py` / `golay_y3.py` /
  `golay_swapfilter.py`).

**002 (a1^12), 004 (a1^16), 010 (a1^24).**
- Nothing computed.
- Structures' builder (`golay_family.u1_lattice`) only builds id 1, with K = an octad. These need:
  - K = a dodecad, the complement of an octad, and all 24 positions;
  - the matching glue vector;
  - the same self-checks (det 1, odd, min ≥ 2, root system, neighbours as in the tracker);
  - then G1 = Stab_M24(K) × admissible signs (M12, 2⁴:A8, M24), giving orbit reduction from generators only, and the same
    y1 → y2 → pair-class pipeline.
- Their identity-Γ plans were 44k h (004) and 1.1k h (010): the whole cost is the missing symmetry.

## 7. Lead 3 (a constraint aimed at low-K, flex-heavy pairs): no new constraint yet
The quick candidates are already covered by the audit:
- mod-2 parity of the supports;
- Lemma Z early;
- counting identities;
- static consistency.

**Next step.** With FD_SYM2 the remaining DFS bulk sits at depths 2–4, which is exactly where low-K pairs spend their nodes. The
same soundness argument extends to every depth, with the branching point a pending target-1 point. Design:
- A per-pair image table img[h, r] (index of s_r(h) among the candidates, for the ≤ ~20 roots of Rs) is computed once,
  vectorised.
- At each node, the group uses the roots of Rs orthogonal to the chosen h's and to the branching point. The orbits come from a
  union-find over img in numba, at about µs cost per node.
- This also removes the 20 % mask overhead of FD_SYM2.

This is the most promising lever left for the expensive pairs. It is not implemented yet.

## 8. FD_SYM3 measured, package v2 deployed (night of 01→02/10, user asleep, "loop mode" authorised)

**FD_SYM3 (symmetry at every depth, in-kernel, along target-1 paths; two-phase).** A/B against the AWS engine on the same pairs,
0 verdict mismatches on 64 pairs:

| Lattice | 011 | 018 | 014 | 019 | 032 | 034 |
|---|---|---|---|---|---|---|
| Speed-up | ×2.33 | ×1.97 | ×2.04 | ×3.87 | ×2.45 | ×1.64 |

- On the full job 118:2:8 the new consumer gave the same stream, chunk_done, and ×1.05.
- On a 1,200-pair stream of job 011:0:646 it gave the same pairs, no non-excluded pair, 2 TWIN-CANON skips, and ×2.50.

**Package v2** (compute repo master 376db9c; zip sha256 7705ae5d…):
- frame_dfs_next + hstage_stream_next, with FD_SYM3 and FD_TWINCANON on by default.
- Two calibrations: 118:2, and the v2 stream of 011.
- `mode_v2` control for a lossless switch.
- **Rehearsals:** GitHub run 36934538241 PASS. An earlier run (36934044532) caught a manifest bug before any spend: the run_jobs
  tarball was inside the MANIFEST.
- **Deployed at 22:24–22:30 UTC:**
  - 4 v2 machines in us-east-2c and 2 in eu-north-1 (1a, 1c). All passed both calibrations on real AWS.
  - v1 machines set to drain. Two v1 machines had just been reclaimed by AWS (spot interruption in eu-north-1b); their jobs were
    released correctly.

**Lead 4, 001 in the Golay frame:**
- structures' pipeline was reproduced in the lab (`Desktop\c2_experimental\golay_work`).
- It gives the same 14 y1 classes, and identical pair lists for classes 0 (819) and 1 (1,949), basis-equivalent (T integral, det −1).
- All 14 classes are being enumerated: 103,051 pair classes after 9 classes.
- v2 engine cost on 001: 0.38 s per pair (59-pair block: 68 % trapped, all excluded).

## 9. Packages v3 and v4: O24 and the whole Golay family (night of 01→02/10, continued)

**Package v3** adds two job kinds next to the unchanged stream jobs:
- `o24`: one of the 47 remaining O24 classes (kernel 3 + numba joint star sums, `o24_run_fast`).
- `golay_pairs`: a block of the 117,068 pair classes of 001 in the Golay frame.

How it was tested and deployed:
- **First CI rehearsal (36937295071) failed for a real reason.**
  - The O24 job computed its whole class (12 min) and then crashed while saving: the cloud package has no
    `data/finishC/o24_dfs`.
  - Fixed with a `makedirs` in `o24_run_fast.py`; no computation changed.
- **Second rehearsal (36938999472): PASS.**
  - Golay slice 001:5:4000, stream 118:2:8 and O24 class 31 all ran.
  - Class 31 gave exactly the lab's node counts per depth: `[1, 1816, 668436, 39477724, 522688961, 167075341, 3301025, 226415]`,
    EMPTY.
- **Deployment.** One v3 machine in eu-north-1c (23:28 UTC). Three in us-east-2c (00:06 UTC), replacing three v2 machines that
  AWS had reclaimed at ~23:09.
- The 64 v3 keys (17 blocks of 001, the 47 O24 classes) were put at the front of the queue. Older agents ignore keys that are
  not in their own `jobs.json`.
- **First imports:** 28 of the 47 O24 classes are EMPTY so far, with no alert.

**Generic Golay pipeline (`golay_work/golay_gen.py`)**, for any frame written by `golay_general.py`.
- **Frame.** U = N0_v + Z g in a-coordinates (norm a·a/8). Here g = d + x0, and K = {j : d_j even} is the set of root positions
  ±4e_j.
- **Admissible y.** Driven by codewords: the parity set X of c' = (a − g)/2 must lie in the Golay code C.
  - X is enumerated modulo C_in, the codewords inside K^c.
  - Each position has a unique minimal |a_j|. The positions that deviate from it share the remaining norm budget of 56.
  - Membership in U is tested, then the shadow-root and norm-3 filters are applied as in `golay_y`.
- **Symmetry.** This is computed, not assumed.
  - The sign group is S_U = F2^K × C_in:
    - signs on K are the reflections in the roots;
    - a flip on w ⊂ K^c preserves N0_v iff w ∈ C;
    - the glue condition holds;
    - all of this is also checked on the basis.
  - The permutation part P_U comes from a listed candidate group Q:
    - Q is Stab_M24(K), or the stabiliser of the coset H + C when K is everything.
    - For each π ∈ Q, the sign correction on K^c is solved from π(g): X(π g) must become a codeword.
    - (π, ε_π) is kept iff it maps all 24 basis vectors of U into U.
  - Every group element used maps the admissible set (and each y2 set) into itself. This is asserted.
- **Pairs.** Exactly as in `golay_y2` / `golay_y3`:
  - y2 runs over all sign variants on supp(y1) ∩ K and all C_in variants on K^c;
  - flips on K \ supp(y1) are put in canonical form, since they lie in Stab(y1);
  - orbits are taken under generators of Stab(±y1): a sample whose permutations generate the whole permutation part, plus all
    sign-only elements, plus y2 → −y2;
  - then the swap filter is applied.

**Validation on 001 against structures' independent code, exact at every step:**
- 118,428 canonical admissible y, the identical set.
- The same 14 y1 classes, as a partition.
- For all 14 classes, the same stabiliser sizes and the same orbit and kept counts: 819/819, 1,957/1,949, 30,462/30,155, …,
  2,536/27. Total 117,068.

**Results:**

| id | roots | admissible y (mod S_U) | P_U | y1 classes | pair classes (after swap) |
|---|---|---|---|---|---|
| 001 | a1^8 | 118,428 | 322,560 = Stab(octad) | 14 | 117,068 |
| 002 | a1^12 | 534,876 | 95,040 = M12 (87,120 with a K^c sign correction) | 26 | 718,422 |
| 004 | a1^16 | 147,504 | 21,504 | 31 | 416,383 |
| 010 | a1^24 | 21,120 | 138,240 = sextet stabiliser 2^6:3.S6 | 3 | 3,962 |

- The permutation groups were predicted before computing them.
  - 002: the K^c sign corrections let all of M12 act.
  - 004: the stabiliser in AGL(4,2) of the direction k1 + k2, so 322,560/15.
  - 010: the stabiliser of H + C, where H is a sextet tetrad pair.
- **Frames re-checked:** det 1, odd, no norm-1 vector, root systems a1^8, a1^12, a1^16, a1^24. Each type is unique among the 156,
  so the frame lattices are 001, 002, 004 and 010.
- **Cost samples** (job logic on random pairs, PC):

  | id | Sample | s/pair | Trapped | Notes |
  |---|---|---|---|---|
  | 002 | 111 pairs | 1.38 | 77 % | |
  | 004 | 111 pairs | 2.20 | 79 % | one pair took 108 s |
  | 010 | 400 pairs | 0.14 | | |

  - All sampled pairs were excluded.
  - 010 nevertheless has rare heavy pairs: indices 349 and 830 of class 0 stop INCOMPLETE at the 2·10⁸-node limit.

**Package v4** (pending CI): v3 plus 706 `golay_pairs` jobs.
- 002 has 360 blocks, 004 has 330 and 010 has 16.
- The job script is v4:
  - it parses the pair files one at a time and keeps only its block;
  - an INCOMPLETE pair is searched again with a limit of 4·10⁹ nodes, and the first attempt is recorded.
- The job gives identical verdicts to v3 on 001:5:4000 and on 010 block 0/12.
- `calib_v4` adds two checks:
  - a compact 010 slice;
  - the retry path: pair 365 is INCOMPLETE at 2·10⁵ nodes, then EXCLUDED with exactly the node counts of the unlimited run.
- `scripts/cloud/import_golay.py` replaces `import_v3.py`. It handles every Golay id and every package version.
- An id becomes EXCLUDED only when all of its blocks are chunk_done and their ranges tile [0, N) exactly.

**Exclusions this night:**
- 053, by the queue.
- 049: its two AWS INCOMPLETE pairs were resolved on the PC without a node limit. Both are EXCLUDED (stage 1 empty), after
  1,373 s and 1,405 s.
- 050 and 055, by the queue.
- **Tracker: 106/156 excluded.**

**Status of a future Golay-family exclusion.** It is computational and not reviewed. It rests on four things:
1. the admissible-y and pair filters of the Golay pipeline, which are structures' exact filters;
2. the G1 reductions, computed and checked;
3. the identification of each frame lattice by classification and shell counts;
4. the stage-1 engine of the stream, `frame_dfs_next`.

**Correction logged.** Section 6 said "1,957, swap-filtered" for class 1 of 001. 1,957 is the count before the swap filter. The
filtered count, in structures' file and in ours (identical sets), is 1,949.

**Update 02/10 ~01:10 UTC: 000 (O24) is EXCLUDED; tracker 107/156.**
- The 47 remaining classes all came back from AWS complete and EMPTY: 46 "no joint star sums", 1 "no local star sums".
  - Not one joint star sum and no frame.
  - They ran on 2 v3 machines, 564–1,070 s per class.
- Accounting checked from the files themselves:
  - `o24_globallp_results.json`: 86 classes EXCLUDED, each with an exact certificate on disk (86 `.npz`), and 55 LP-feasible.
  - The 55 LP-feasible classes are the 8 lab-EMPTY classes (`o24_dfs`: 8, 12, 15, 16, 17, 21, 23, 34) plus the 47 of
    `logs/o24_todo_47.txt`, all EMPTY in `o24_cloud`.
  - The union covers all 141 (y1, y2) classes of C1 48eabf2.
- **Status:** computational, resting on four inputs:
  - C1's class list;
  - structures' LP certificates, verified twice;
  - C2's O24 search (kernel 3 + Lemma Z + local/joint star sums; the numba joint stage was validated against the Python one by
    planted-solution tests);
  - the CI check of identical node counts on class 31.

**Correction 02/10 ~02:15 UTC (cost of 001).**
- The v3 estimate of 0.5 s per pair was wrong. It came from a single 59-pair block of y1 class 0.
- A random sample over all 14 classes (137 pairs, seed 7, `golay_sample_cost.py`) gives **1.69 s per pair** on the PC:
  - 75 % trapped;
  - the searched pairs take 1–30 s;
  - all EXCLUDED.
- So 001 costs about 71 cloud CPU-hours, not 17. Each of the 17 blocks (~6,900 pairs) takes about 4 h on AWS. That is
  consistent with the blocks still running 2.6 h after their start, with no failure.
- The 002 and 004 estimates of v4 came from random samples from the start: 1.38 and 2.20 s per pair.

**Update 02/10 ~02:30 UTC: 010 (a1^24) is EXCLUDED; tracker 108/156.**
- All 16 v4 blocks (3,962 pair classes) were done on one v4 machine, every pair EXCLUDED:

  | Verdict | Pairs |
  |---|---|
  | char trap | 2,777 |
  | stage 1 empty | 1,102 |
  | no local star sums | 73 |
  | twin transfer | 10 |

- The two heavy pairs of y1 class 0 that stop INCOMPLETE at 2·10⁸ nodes were closed by the v4 retry:
  - pair 349: stage 1 empty, 2.55·10⁸ nodes, 334 s;
  - pair 830: no local star sums, 2.46·10⁸ nodes, 340 s.
- 004 was also running: 34/330 blocks done after about 30 min, faster than the 1 h per block estimated.
- The two v1 machines were stopped selectively (mode=stop, mode_v2=run). Two v4 machines took their quota in eu-north-1c.
