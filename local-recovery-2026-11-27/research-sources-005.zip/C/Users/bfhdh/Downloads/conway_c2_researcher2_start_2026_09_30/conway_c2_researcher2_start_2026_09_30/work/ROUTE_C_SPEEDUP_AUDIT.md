# Route (C): audit of every attempt to reduce the compute (2026-10-01)

**Purpose.** Before proposing any new reduction, list what was already tried, where it is recorded, its status, and its
measured effect. I did not re-prove anything. Status labels are copied from the sources.

## Sources read
1. **Transcript of the lab session** (25–29/09), `~/.claude/projects/C--Users-bfhdh-Desktop/19a7c411-....jsonl`.
   - 360 user messages and 12 compaction summaries.
   - I read in full the summaries of 28/09 18:44 and 29/09 16:38, and the exchanges of 29/09 17:40–19:20.
   - I grepped the summaries of 26/09 23:31, 27/09 (11:06, 14:33, 18:27) and 28/09 00:16.
2. **Lab notes and memory.**
   - Lab notes: `notes/56_PROMPT_ASTRA_ROUTE_C_28_09.md` (brief and results), `notes/57_PROMPT_ASTRA_MICROSCOPE_29_09.md`,
     `notes/PROOF_SKELETON_C2.md` (Part II), lab `NEGATIVE_RESULTS.md` (23–25/09: conceptual attempts, not Route C speed).
   - Lab memory `route-c-engine-2909.md`.
3. **The engine actually running on AWS:** `c2_cloud_run/scripts/frame_dfs.py`, `hstage_stream.py`, `run_jobs.env_exact`.
   Flags were checked in the code.
4. **Repos.**
   - `conway99-rank17`: README, RANK17_HANDOFF §1–4, `r17_char/README.md`, `evenframe/README.md`.
   - `conway99-c2-campaign`: README, STATUS, `compute/ROUTE_C.md`, `compute/NATIVE_SOLVER.md`.
5. **The 400 AWS chunks imported 01/10:** 14 lattices, 32.0 M pairs, 1,063 h of wall time.
   - `data/finishC/stream/*/chunks.jsonl`, records with `imported_from`.

## A. In the production engine today (all ON in the AWS run; flags checked)
| # | Reduction | Origin / status (as written) | Measured effect |
|---|---|---|---|
| A1 | Pair enumeration: W(R)-dominant y1 mod Γ = Aut(U)/W(R); y2 mod Stab(y1) × signs | C1 `y_pairs_gamma.py`. COMPUTED, complete up to Aut(U)×signs; Γ verified. 025's Γ corrected 29/09 (|Γ|=8, was identity) | orbit reduction by \|Γ\|. 025: ~600 h → ~80 h; it is in the queue with `gamma/025` |
| A2 | Lemma U+ (u hits at 3/2 only w=1, non-y-hit points; Same/Opp cells) | C1 notes 145. PROVEN (C1). Flag FD_LEMMA_U=1 | non-rigid lattices: 1–6 s/pair (27/09) |
| A3 | Symmetry breaking: reflections fixing y1, y2 and a target-1 point β0 | C2 28/09. PROVEN. FD_SYM=1 | 17–30× fewer nodes; 1.7–2.1× wall |
| A4 | Characteristic trap: for z characteristic of norm 16, (z,y1)²+(z,y2)² ≤ 66 | Astra 28/09, checked by C2. FD_CHAR=1 | **50 % of all pairs** killed at about 1 ms (AWS data) |
| A5 | Swap rule: unordered pairs, invariant I(y) with sorted coset hits | C2. Verified on the full 078 list; one orphan (sign flip) fixed. FD_SWAP=1 | **36 % of pairs** skipped (AWS) |
| A6 | Twin envelope U† = F(U)+J: pair transfer, plus deferral to richer twins | Astra shell theorems §5–7, checked by C2. FD_TWIN=1; stream_finish fixed point | 4.3 % of pairs (AWS); lattice-level deferral (e.g. 058 waits on its twins) |
| A7 | Endpoint confinement, plus all boundary points Y_z=58 (= the twin's new roots) | Astra/"5.6" flex package, checked by C2. FD_EC=1, FD_BND=1000 | nodes ÷3 (078: 105k → 34k; 097: 15k → 1.9k). The biggest node gain ever |
| A8 | Engine work: pair_setup_fast, compat_fast, pack_V, vectorised sym_reps, integer y conversion, twin check 38 → 1.3 ms | C2 29/09. Each checked "identical verdicts + nodes per depth" | searched pair on 078: 467 → 140 ms (×3.3) |
| A9 | Lattice-level component budget (Σ_f \|P_i f\|² = 7·rank R_i) | C2 28/09. PROVEN | excluded 130 and 143 outright (094 via C1 packing) |
| A10 | Scheduling: richest-first, twin dependencies, `resolve_incomplete` for monster pairs (no node limit) | C2 | makes exclusions flow; no CPU saving |

## B. Tried, sound, switched OFF (no net gain)
| Item | Result |
|---|---|
| Per-pair root-class budget ILP (FD_PREBUDGET) | kills 17–100 % depending on lattice (×8.8 on 119), but costs 2.5 s/pair on 078 for 27 % kills. OFF |
| Shared per-y1 setup (FD_SHARED / y1_cache) | no gain (measured on mid lattices) |
| FD_WPRUNE, FD_ECSIGN, FD_FASTCOMPAT (float32 BLAS) | sound, no gain |
| Astra root-star filters (static and node-level) | static: −0 to −31 % nodes; node-level: −0 to −36 % nodes but 8–15× slower |
| Static 3-consistency, static PC3 | PROVEN; −41 % / −81 % nodes, but cost more than the search |
| lp_cover (LP relaxation of the exact cover) | 86 % kills on 097 (×1.6), 32 % on 078 (×0.9) |
| Fail-first reordering (same tree) | ×1.09 |
| Tie-breaking of the symmetry representatives | 3–12 % |
| Lemma Z (Σh ∈ 2U) checked early | cuts at depth 4, where nodes die anyway |

## C. Tried and failed, refuted, or rejected before running
- **Weaker search spaces.** y-free h search: 38–44k candidates per lattice. y1-only relaxation: millions of leaves, incomplete at 20 M nodes.
- **Pair grouping by hit set:** no reduction (22,198 pairs give 20,211 groups on 078).
- **Counting / knapsack:** support-size knapsack, degree knapsack, h-coverage window, hcover_test: 0 kills. The aggregated identities are automatic.
- **Solvers** (CaDiCaL, CP-SAT) on the whole model: all timed out. The user ruled them out as the proof.
- **Universal fractional tight-frame LP.** It was infeasible on 16/16 sampled survivors (078/097). It is **refuted as universal**: Astra gave
  an exact feasible fractional frame for O24 class 8 and its twin 008.
  - The y1-orbit version was too weak (feasible 8/13).
  - Aut-invariant class certificates exist for only 1 pair in 8.
- **Joint search over all partners of a y1:** estimated ≤ ×2, not built.
- **Norm-24 characteristic constraints:** already implied (0 nodes saved).
- **Y_z = 50 points:** rejected on paper (they only impose parity and never saturate).
- **Microscope** (COMPUTED/PATTERN, 29/09):
  - deaths come at flex points: the needed third h always clashes on a used y-hit (100 % of 12,000 sampled triples);
  - the kill is not local: it needs both Niemeier neighbours at once (97 sample);
  - it is not counting;
  - there is no small core (minimal cores of 43–66 of 104 points).
- **Astra's "signed-quotient construction" bet:** NO PROGRESS.
- **Solver-free "rogue" models of the joint witness** (28/09): pilots timed out.

## D. Alternative finite routes (bypassing the 156)
- **Rank-17 switch** (RANK17_HANDOFF Thm 3.1, 27/09; hand proofs, "not independently audited").
  - The route has 1,272 (V, y) classes. It is a necessary-condition route.
  - The characteristic test (χ of norm 1/9 decide min Char(K*) ≥ 3) closed 228 of 751 classes. It is Astra's, re-proved by C2,
    re-verified by C1. **526 open.**
  - Cost estimate, 29/09 19:05:

    | Part | Classes | State | CPU-h |
    |---|---|---|---|
    | R5 | 274 | engine ready | ~50 |
    | Type 0 | 76 | no engine; ~1,700 h if an engine like R5's sufficed | ~1,700 |
    | Type II | 156 | no engine | ~40,000 |
    | Rest | ~20 + Z17 | not costed (A11E6p:8 alone ≈ 1.2·10¹⁰ leaves) | – |

    **Not cheaper than Route C as of 29/09.**
- **Even sector / L_β** (structures, 01/10, `conway99-rank17/evenframe`): work in progress; nothing closed; later solver versions not re-validated.
- **Native four-state solver** (campaign `NATIVE_SOLVER.md`): not built.

## E. Measured or proposed but NOT implemented
| Lead | Status |
|---|---|
| Twin canonical rule | On 011, half of the searched pairs duplicate their same-type twin; ≈ 20 % of searched pairs could be skipped. Needs a soundness argument. Measured 29/09, not deployed (production engine unchanged; trials in `frame_dfs_ff.py`, `camp15`–`camp30`) |
| Golay family 001/002/004/010 and O24 (000) | Outside the batch. They need orbit reduction from generators only (the C1 tool lists all of Aut). "Programming, not a breakthrough" |
| Shared per-y1 setup on root-poor lattices | Proposed 29/09 18:39 (≈107 ms of setup vs 30 ms of tree on a median searched pair). Stopped before measurement. **The AWS data below show the tree dominates on root-poor lattices**, so the expected gain there is small |
| Deeper symmetry breaking | Offered 28/09, never started |

## F. Where the remaining time goes (AWS data, 400 chunks, 32.0 M pairs, 1,063 h)
- **Pair fates:** trap 50 %, swap 36 %, twin 4.3 %, **searched 10.3 %**.
- **Cost:** about 1.15 s of wall time per searched pair on average. On the root-poor lattices: 018 1.30 s, 019 1.71 s, 011 1.87 s,
  014 1.89 s. On 054/055/061: 0.25–0.33 s.
- **What dominates.** On 018 the search tree dominates the wall time. The mean is of order 10⁵–10⁶ nodes per searched pair, with a heavy
  tail up to 2²¹; this is a crude estimate from the log2 histogram.
  - Sample pair: K = 22 y-hit points; 100 of 128 points are flex.
  - The 29/09 diagnosis is consistent with this: nodes depend almost only on K (K=16 → ~10⁵; K=32 → ~1.5·10³), and low-K pairs carry
    half the work.
- **Concentration.** 12 lattices hold 84 % of the remaining estimate: 011 20 %, 018 12 %, 014 7 %, 005 6 %, 007 6 %, 015 5 %, 032 5 %,
  019 5 %, 029 5 %, 034 4 %, 009 4 %, 021 3 %.

## G. Bookkeeping
- **Counts.** Campaign repo: "91/156, ≈6,600 CPU-h", marked campaign-reported, sync needed. Lab tracker 01/10: **94/156**.
  Queue: 5,894 est-h × 1.30 = **7,662 job-h**.
- **Open lattices not in the queue:** 000 (O24, partial) and 001, 002, 004, 010 (Golay family). Also 058: swept, waiting on its twin classes.

## H. What this implies for any new proposal
1. Anything that only removes pairs that already die cheaply (trap, swap, twin) is worthless. The target is the **10 % searched pairs of
   the root-poor lattices**, i.e. the big trees of low-K, flex-heavy pairs.
2. Node reductions already achieved: ÷17–30 (A3), ÷3 (A7). Constant-factor engine work is exhausted. Per-node cost is about 3 µs, and
   fail-first gives ×1.09.
3. Rejected classes of ideas, to avoid repeating: LP relaxations (refuted as universal), counting identities (automatic), local or
   per-component filters (the kill is global), solvers.
4. **Not yet tried on the expensive part:**
   - the twin canonical rule, ~20 % of searched pairs, which needs a proof;
   - orbit reduction for the Golay family and O24 (excluded from the batch);
   - deeper symmetry breaking;
   - any constraint aimed specifically at **low-K / flex-heavy** pairs.
   - None of these has a measured ×2 yet.
