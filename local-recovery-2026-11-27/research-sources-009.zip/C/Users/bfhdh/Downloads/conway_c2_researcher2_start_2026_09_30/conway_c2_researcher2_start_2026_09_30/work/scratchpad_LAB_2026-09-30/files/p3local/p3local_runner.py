"""P3 on the lab PC after the end of AWS (LAB 20/10/2026).  The 8 slices i/16 still missing at the shutdown of the
p3split machines are re-cut EXACTLY into the 16 sub-slices (i + 16 t)/256 each (py_extend.py deals the distinct
known matrices of a border round-robin by rank of first appearance mod n, so slice i/16 is the union of the
sub-slices j/256 with j = i mod 16).  Same flags as p3split.  Each job runs in the package directory, one thread,
with a per-job time limit (probe mode); results go to out/ and one JSON line per job to p3local_done.jsonl
(EXCLUDED jobs are never re-run).
usage: python p3local_runner.py <pkg dir> <workers> <timeout seconds>"""
import gzip
import json
import os
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

PKG, W, TO = sys.argv[1], int(sys.argv[2]), float(sys.argv[3])
HERE = os.path.dirname(os.path.abspath(__file__))
DONE = os.path.join(HERE, "p3local_done.jsonl")
PY = sys.executable
MISSING = [(9, 1960, 1), (9, 1960, 5), (9, 1960, 6), (9, 1960, 8), (9, 2284, 2), (10, 3258, 13), (51, 3418, 2),
           (88, 3270, 8)]
TOTAL = {}
for ci in {m[0] for m in MISSING}:
    TOTAL[ci] = json.load(gzip.open(os.path.join(PKG, "data/p3_boundaries/core_%03d.json.gz" % ci)))["boundary_count"]
jobs = [(ci, bi, i + 16 * t) for ci, bi, i in MISSING for t in range(16)]
done = {}
if os.path.exists(DONE):
    for l in open(DONE):
        d = json.loads(l)
        done[d["id"]] = d
lock = threading.Lock()
env = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1")


def run(job):
    ci, bi, j = job
    name = "core%03d_b%06d_s%03d_n256" % (ci, bi, j)
    if name in done and str(done[name].get("status", "")).startswith("EXCLUDED"):
        return
    idx = os.path.join(PKG, "idx", "idx_%s.json" % name)
    with open(idx, "w") as f:
        json.dump([bi], f)
    out = "out/%s.json.gz" % name
    cmd = [PY, "-I", "-u", "-X", "utf8", "code/lab3/py_extend.py", "code/codex", "P3",
           "data/p3_boundaries/core_%03d.json.gz" % ci, "0", str(TOTAL[ci]), "--sat", "--lean", "--enc=seq",
           "--all-attachments", "--conflicts=3000000", "--att-slice=%d/256" % j, "--indices=idx/idx_%s.json" % name,
           "--out=%s" % out]
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=PKG, env=env, capture_output=True, text=True, timeout=TO)
        code, to = p.returncode, False
        tail = p.stdout[-400:]
    except subprocess.TimeoutExpired:
        code, to, tail = None, True, ""
    wall = round(time.time() - t0, 1)
    status, case = None, {}
    f = os.path.join(PKG, out)
    if not to and os.path.exists(f):
        try:
            c = json.load(gzip.open(f))["cases"][0]
            status = c["status"]
            case = {k: c.get(k) for k in ("slice", "enumerated_total", "enumeration_sha256", "counts", "cpu_seconds")}
        except Exception:
            status = "UNREADABLE"
    rec = dict(id=name, core=ci, border=bi, sub=j, exit=code, timeout=to, wall=wall, status=status, **case)
    with lock:
        with open(DONE, "a") as g:
            g.write(json.dumps(rec) + "\n")
        print("%s %s %s %.1fs" % (time.strftime("%H:%M:%S"), name, status if not to else "TIMEOUT", wall), flush=True)


with ThreadPoolExecutor(max_workers=W) as ex:
    list(ex.map(run, jobs))
print("ALL JOBS VISITED", flush=True)
