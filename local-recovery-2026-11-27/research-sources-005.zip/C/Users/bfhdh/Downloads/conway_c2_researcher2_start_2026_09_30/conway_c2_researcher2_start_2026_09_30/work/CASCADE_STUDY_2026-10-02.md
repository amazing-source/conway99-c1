# Microscope on the 052 cascade (2026-10-02, C2)

**Data.** Frozen copy of the stream records of the 23 lattices excluded together on 02/10 (052 cascade): lab
`data/cascade_snapshot_2026-10-02`, with a sha256 manifest.

| | |
|---|---|
| Pairs | 101,397,664 ordered pairs, coarsest complete chunking per lattice |
| Telemetry per chunk | histograms of trap Y_z, root energies E(y1), E(y2), nodes, depth, K |
| Search samples | 50 per chunk, 46,400 in total |
| Heavy pairs | 35 resolved without a node limit: 31 of 037, 4 of 052 |

**Scripts** (lab `scripts/analysis/`): `cascade_study.py`, `cascade_energy.py`, `cascade_hardness.py`,
`heavy_pairs_invariants.py`, `budget_on_heavy.py`.

**Status.** Measurements only. Nothing below is a proven statement, unless marked "proven elsewhere".

## M1. Death mechanisms are almost lattice-independent

In all 23 lattices (80 to 112 roots, 22 different root systems), the shares of the pairs are close to each other:

| Mechanism | Share of pairs |
|---|---|
| characteristic-vector trap | 39.5–47.7 % (about 44 %) |
| stage 1 empty | 10.3–14.4 % |
| swap-covered | 36.8–45.0 % |
| twin transfer | 0.3–0.9 % |
| twin-canonical | < 0.3 % |
| twin-deferred | 0.3–3.3 % |
| no local star sums | ≤ 0.01 % |

Among the pairs that are neither duplicates nor twin-related, about 80 % die in the trap and about 20 % at stage 1.

**The star-sum stages are essentially never needed.** Every searched pair dies at stage 1, almost always at depth 4 or 5:

| Depth reached | Searched pairs |
|---|---|
| 5 | 6,894,318 |
| 4 | 3,744,006 |
| 3 | 342,557 |
| 6 | 32,964 |
| 7 | 1,966 |

## M2. The trap fires only with Y_z ∈ {74, 98}
The trap fired 44,417,141 times with Y_z = 74 and 27,066 times with Y_z = 98, and never with another value.
- Y_z is a sum of two odd squares, so 74 = 5² + 7² and 98 = 7² + 7².
- In other words, the trap fires exactly when a norm-16 characteristic vector z sees one of y1, y2 at 7 and the other at 5 or 7.
- In the engine's energy identity, any Y_z > 66 is excluded. The value |z·y| = 9 (Y_z ≥ 82) never occurs for these pairs.

## M3. Trap rate against the root energy E(y) = Σ_{r>0} (r·y)²
The trap rate falls smoothly as E1 + E2 grows:

| E1 + E2 | Trap rate |
|---|---|
| ≤ 34 | 97–100 % |
| about 40 | 89 % |
| about 48 | 81 % |
| ≥ 56 | plateau at 76–78 % |

There is no sharp threshold: energy alone does not predict which pairs escape the trap.

## M4. Search cost is governed by K
K is the number of y-hit points, i.e. the new roots β with |(y1,β)| or |(y2,β)| = 3/2, the points of target 1. Over the 46,400
sampled searched pairs:

| K | Pairs | Median nodes | Notes |
|---|---|---|---|
| 0 | 11 | 1.7·10⁸ | all heavy, 3 INCOMPLETE at 2·10⁸; all points flex |
| ≤ 12 | | | every pair above 2²² nodes has K ≤ 12 |
| 12 | | 67,000 | |
| 20 | | 11,000 | |
| 30 | | 3,900 | |
| 40 | | 1,500 | |
| ≥ 14 | | | never above 2²² nodes |

**Share of the sampled search work:**

| Pairs | Share of searched pairs | Share of search nodes |
|---|---|---|
| K = 0 | 0.024 % | 45 % |
| 0 < K ≤ 12 | 4.7 % | 19 % |
| K > 12 | 95.3 % | 35 % |

## M5. The heavy pairs are the pairs whose y lie (almost) in the span of the roots
This holds for all 35 resolved heavy pairs:
- K = 0;
- every point is flexible: 80 points for 052, 72 for 037;
- E(y1) = E(y2) = the maximal energy seen in the lattice: 46 for 052, 40 for 037;
- the part of y outside the real span of the roots has norm in {0, 0.143, 0.476, 0.5, 0.643}, against y·y = 7. Some y lie exactly
  in that span.

All 35 are EXCLUDED: 31 at stage 1 (empty) and 4 with no local star sums. Each search took 20–145 min without a node limit.

For 052 (a₇a₃⁴a₁⁴, rank 23) the orthogonal complement of the root span has dimension 1.

## M6. The per-component budget does NOT explain them
The per-pair component-budget ILP (`pair_budget.py`, proven 28/09, audit A9; OFF by default for cost) declares all 35 heavy pairs
**feasible**:
- 0 of 4 for 052;
- 0 of 31 for 037;
- 0.3–2.6 s each.

So their obstruction is not an energy budget per root component. It is combinatorial: compatible sets of h reach size 4–5, never 7,
with the coverage rule (every point covered 1 or 3 times, all points flexible).

## Leads (hypotheses, not results)

### H1. A stage-1 lemma for K = 0
Find why no 7-set of pairwise orthogonal admissible h (norm 4, ⊥ y1, y2, |(h,β)| ≤ 1) can cover every new root 1 or 3 times
when y1 and y2 lie in the root span.
- **Candidates:**
  - a parity or counting argument on the coverage, with all points flexible;
  - a clique bound in the compatibility graph of the h-candidates, which is highly symmetric for these pairs.
- **Payoff:** about 45 % of the search work (M4) would disappear, and more if it extends to small K.

### H2. Check the K distribution on the remaining lattices
Check whether the remaining big root-poor lattices (011, 014, 018, …) also have rare K = 0 pairs carrying the cost. Their
completed chunks carry the same `sample_search` telemetry.

### H3. Read M1 and M2 as structure
- The near-constant shares across 22 different root systems suggest that the trap is governed by a local, lattice-independent
  condition on (y1, y2).
- Under that reading, a parity statement about norm-16 characteristic vectors (M2) would be the natural first target for a proof
  without computation.

---

# Addendum (2026-10-02, afternoon): an exact law behind M4/M5, and what it means for the remaining work

**Scripts** (lab `scripts/analysis/`): `identity_check.py`, `coset_identity_check.py`, `coxeter_table.py` (output
`logs/coxeter_table.jsonl`, all 156 envelopes), `h2_remaining.py`, `parity_probe.py`, `f2_cover_probe.py`, `intersection_probe.py`.

## P1. K + E(y1) + E(y2) is a lattice constant (PROVED below; checked on all data)

**Setting.**
- U is an envelope: odd unimodular, rank 24, minimum ≥ 2.
- U_0 is its even part. S_1 and S_2 are the two shadow cosets of U_0.
- N_j = U_0 ∪ S_j (j = 1, 2) are the two even neighbours. They are Niemeier lattices, with Coxeter numbers h_j (h_j = 0 for Leech).
- Φ = Φ(U) is the root system of U. E(x) = Σ_{r∈Φ⁺} (r, x)² is the root energy.
- A new root of coset j is a norm-2 vector of S_j.

**Classical fact.** The roots of a Niemeier lattice with roots form a 2-design:

    Σ_{r ∈ Φ(N)} (r, x)² = 2 h(N) |x|²   for every x.

Reason: all components of Φ(N) have the same Coxeter number, the components span R^24, and on an irreducible simply-laced component
Σ (r, x)² = 2h |proj x|².

**Step 1 (moment per coset).** Φ(N_j) = Φ(U) ∪ (new roots of coset j). Hence, for every vector x:

    Σ_{β new root of coset j, ±} (β, x)² = 2 h_j |x|² − 2 E(x).

**Step 2 (counting).** Trace gives #new roots of coset j = 24 h_j − |Φ|. With `lattice_data`'s assertion 2P = |Φ| + 48, which holds for
all 156 envelopes, this gives h_1 + h_2 = |Φ|/8 + 2.

**Step 3 (count the hits).** Feed in the values (x, β) can take. Counts are per ± pair.

| Identity | Vector | Value set of (x, β) | Formula |
|---|---|---|---|
| (Y) | frame y (norm 7) | {±1/2, ±3/2} by the frame identity | K_j(y) = 2 h_j + |Φ|/16 − E(y)/2 |
| (U) | any norm-3 u | {±1/2, ±3/2} automatically | m_j(u) = |Φ|/16 − E(u)/2 |
| (H) | admissible h (norm 4) | {0, ±1} | d_j(h) = 4 h_j − E(h) |

- K_j(y) counts the new-root pairs of coset j hit at 3/2 by y.
- m_j(u) is the same count for u. It is equal in both cosets.
- d_j(h) counts the coset-j pairs covered by h.

**General form.** Let x ∈ U be odd with |x|² = n and every (x, β) ∈ {±1/2, ±3/2}, and let m_j(x) be its number of 3/2-hit pairs in
coset j. Then:

    m_j(x) = (n − 3) h_j / 2 + |Φ|/16 − E(x)/2,   so   m_1(x) − m_2(x) = (n − 3)(h_1 − h_2)/2.

The asymmetry vanishes exactly for norm 3. (Y) is the case n = 7 and (U) the case n = 3.

Check of the general form at n = 5: every norm-5 vector of 018 and of 052 with all |(x, β)| ≤ 3/2 was tested, both cosets.

| Envelope | Vectors tested | Violations |
|---|---|---|
| 018 | 1,128,768 | 0 |
| 052 | 1,127,296 | 0 |

**Consequences.**
1. K(y) = K_1 + K_2 = 3|Φ|/8 + 4 − E(y). For a pair: **K + E(y1) + E(y2) = 3|Φ|/4 + 8.** This explains M5: K = 0 exactly when both y
   have the maximal energy 3|Φ|/8 + 4.
2. **K_1(y) − K_2(y) = 2 (h_1 − h_2).** Hence:
   - every frame y has K(y) ≥ 2 |h_1 − h_2|;
   - every pair has K ≥ 4 |h_1 − h_2|;
   - **K = 0 pairs exist only in envelopes with h_1 = h_2.** That is 39 of the 156; table in `logs/coxeter_table.jsonl`.
3. Combined with M4 (cost is governed by K), envelopes with h_1 ≠ h_2 have no heavy K = 0 pairs. The larger |h_1 − h_2|, the cheaper
   their searches.

**Checks.**

| Check | Scope | Result |
|---|---|---|
| K + E1 + E2 constant per lattice | all 47 lattices with sampled searched pairs | 0 exceptions; constants 50, 56, …, 104 = 3|Φ|/4 + 8 |
| (Y), (U), (H) per coset | 052 (h = 8/8) and 018 (h = 6/5): 7,100 y, 600 u, 11,500 h | 0 violations |
| K = 0 pairs only where h_1 = h_2 | all stream telemetry | K = 0 seen in 023, 024, 026, 028, 037, 049, 052 only, all with h_1 = h_2 |
| min observed K ≥ 4 |h_1 − h_2| | all 47 lattices | holds everywhere |

**Duplication.**
- The method, the 2-design of Niemeier roots restricted to a shadow coset, is C1's. See `external_runs/c1_96a94fe/code/
  packing_criterion.py`, 27/09: identity (U), there written m_j = r/8 − E counting ±β.
- New here:
  - the y and h versions;
  - the coset asymmetry K_1 − K_2 = 2(h_1 − h_2);
  - the explanation of M4/M5 and of where heavy pairs can occur.

**Limits.**
- Summed over a frame, these identities are tautologies: they reduce to n1 + n3 = P, and the bound h_min ≥ |Φ|/24 is trivial.
- They exclude nothing by themselves, and they give no pruning in the engine, which computes K directly.

## H2 answered: the remaining big lattices have no heavy pairs

Measured from the exact per-chunk telemetry of the completed chunks:

| lid | h_1/h_2 | chunks | searched pairs | K = 0 | nodes in pairs > 2^22 | nodes in pairs > 2^26 |
|---|---|---|---|---|---|---|
| 011 | 5/4 | 47 | 345,089 | 0 | 26 % | 0 |
| 014 | 5/5 | 12 | 133,071 | 0 | 32 % | 0.4 % |
| 018 | 6/5 | 322 | 3,880,694 | 0 | 20 % | 0.1 % |
| 019 | 6/5 | 104 | 471,619 | 0 | 35 % | 0.6 % |
| 024 | 6/6 | 12 (all) | 387,252 | 54 | 36 % | 10 % |
| 026 | 6/6 | 15 | 558,769 | 24 | 27 % | 4 % |
| 028 | 6/6 | 8 (all) | 8,127 | 39 | 80 % | 67 % |

- The big open lattices (005, 009, 011, 012, 015–021) have h_1 ≠ h_2, so there are no K = 0 pairs there at all. Their cost is
  volume (many pairs with K ≥ 10), so a K = 0 lemma would not shorten them.
- The open lattices with h_1 = h_2 are 001, 003, 006, 007, 008, 013, 014, 023, 024, 026 and 028.
- Operational finding: 024 and 028 are fully computed. They were still open only because of 54 + 39 K = 0 pairs left INCOMPLETE by the
  v2 engine (limit 2·10⁸). 026 and 023 carry 24 + 1 more. These go to package v8 (resolve jobs, one pair each; see the HANDOFF).

## H1: negative results (no short stage-1 argument for K = 0 found)

All of these come from the 052 and 037 heavy pairs.

| Test | Result |
|---|---|
| Parity | Every candidate h has d(h) ≡ 0 mod 4, and |P| ≡ 0 mod 4: no parity contradiction. Note (H): d_j(h) = 4h_j − E(h), so E(h) is even here. |
| F2 coverage | χ(h_1) + … + χ(h_7) = 1 is solvable in the span. 052: rank 18 for 80 points. 037: rank 19 for 72 points. |
| Pairwise intersections | Over the 7,013,879 orthogonal candidate pairs of 052, I(h, h') = \|supp h ∩ supp h'\| is always even. No mod-4 obstruction, since Σ I = 3 n3. |
| Uniform death depth | The 052 heavy pairs never reach depth 6 (e.g. 32.8·10⁶ valid 5-sets, 0 6-sets). But 8 of the 31 resolved 037 heavy pairs reach depth 6 or 7, and 4 die only at the local star sums. The K = 0 obstruction is not uniform. |
| Symmetry | For K = 0 the engine's FD_SYM/FD_SYM2/FD_SYM3 never apply: they need a target-1 point. A depth-0 reduction by the reflections fixing y1, y2 and a chosen flex point would still be valid ("every solution covers that point at least once"). This is only a speed-up idea, not implemented or validated. |

## Possible speed-up for K = 0 pairs (measured, NOT implemented)

Script: `scripts/analysis/k0_symmetry_gain.py`.

**Measurement.** On the first four 028 heavy pairs:
- 9–13 roots of U are orthogonal to y1, y2 and a suitable point β.
- The candidates through β number 1,980–2,025. They fall into 165–345 orbits under the reflections in those roots.
- Branching at depth 0 on orbit representatives would therefore cut the root fan-out by 6–12×. The whole search should shrink by a
  similar factor, which is not checked.

**Validity argument.**
- The reflections fix y1, y2 and β.
- They preserve every stage-1 and stage-2 constraint.
- Every frame covers β at least once.

**Status.** Not used. Deploying it needs:
- an engine change;
- proof review;
- verdict-equivalence tests on the 35 resolved heavy pairs;
- a CI rehearsal.

For the 118 pending K = 0 pairs, the validated engine on AWS (package v8) was preferred.
