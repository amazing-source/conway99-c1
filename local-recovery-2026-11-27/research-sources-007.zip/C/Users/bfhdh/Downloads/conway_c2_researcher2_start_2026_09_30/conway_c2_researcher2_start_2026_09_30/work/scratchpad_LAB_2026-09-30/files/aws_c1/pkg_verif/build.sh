#!/bin/bash
# Build the two template enumerators on the instance (Linux, g++).
set -e
cd "$(dirname "$0")"
mkdir -p bin
g++ -O3 -march=native -std=c++17 -o bin/cle_templates code/lab/cle_templates.cpp
g++ -O3 -march=native -std=c++17 -o bin/cle_templates_la code/lab/cle_templates_la.cpp
sha256sum code/lab/*.cpp code/lab/*.py > bin/sources.sha256
echo build ok
