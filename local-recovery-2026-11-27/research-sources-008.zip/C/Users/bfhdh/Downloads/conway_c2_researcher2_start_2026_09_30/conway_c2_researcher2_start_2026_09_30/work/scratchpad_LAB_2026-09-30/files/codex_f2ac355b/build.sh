#!/bin/bash
echo "no build step (Codex f2ac355b, pure Python + python-sat)"
