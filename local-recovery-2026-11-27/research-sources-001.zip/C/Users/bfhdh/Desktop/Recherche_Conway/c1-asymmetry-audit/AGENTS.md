18/10 22h10 - Cycle local termine, aucun calcul laisse actif. Regulateur
cpu_guard_rank6 arrete proprement. Dernier envoiLAB1105, dernier lu1102.
Code et fermetures pousses; LAB prend la campagne des108 Gram isolees.

18/10 22h06 - gz599 FERME9/9 par assemblage : derniereGram5 INFEASIBLE
3.375CPU avec eigen layer0; huit exclusions anterieuresLAB acceptees.
Couverture9 recue deLAB, pas reenumeree, pas de certificat portable.
Quatregrilles => E3 borne les aretes internes par50, budget51 automatique.
Rapport gz599_closure.json dans data/codex_rank6_20261018. Ne pas dupliquer
la campagne108 deLAB; gz599/5 transmis comme deja resolu. Aucun Conway
globalement exclu. Aucun calcul local actuellement actif hors regulateur.

18/10 22h04 - Encodeur SIGNE Gamma H extrait en helper commun et exerce
sur vraiSRG243 avec identite correcte GammaY=-4Y+8(P_G-P_F),PAS eigen-4.
48180 produits signes, controleSAT+reconstruction exacte. SansGram gabarit3
UNKNOWN20.09375CPU;26786variables. Temoin444 sans eigen viole1029 sommes
sommet/rectangle (ex w=(0,2),F=(0,4):5 au lieu de6). Pilote dernierGram5
de gz599 en cours30CPU. Regulateur rank6 toujours actif, core14.

18/10 21h59 - Ablation444 : sans Gamma H=-4H, meme modele SAT3.515625CPU;
avec, INFEASIBLE6.53125CPU. Ingredient decisif identifie. Extension SANS
Gram : (Gamma Z+Z)_wF =16/6/8, option --row-moments de z_joint/z_pipeline.
Controles positifs SRG9 et243 passes, dont31536 produits booleen*compte
effectifs. Pilote gabarit3 entier sans Gram en cours20CPU, pas de verdict
de gabarit annonce. Voir COINS_LETTRES_EQUATIONS_PROPRES_2026_10_18.txt.

18/10 21h56 - NOUVEAU : gz3 Gram160/444/11/117/718 toutes INFEASIBLE
5.5..11.7CPU via signature_joint avec eigen+coins+upper+short, layer0,
flips normalises, un coeur. Budget51 redondant (3grilles, E3 => au plus48
aretes internes). VerdictsCP sans certificat portable; gabarit3 resteOUVERT.
444 possede pourtant un temoin de signatures sur lettres et coins; le
passage aux aretes communes et aux equations propres echoue.
Voir notes/COINS_LETTRES_EQUATIONS_PROPRES_2026_10_18.txt. Nouveau lanceur
root_component_fixed_gram_probe.py; pas de nouvelle campagne distante.

18/10 21h49 - Filtre de moments porte au rang6 dans signature_domains ET
corner_data. Pilote gz3 Gram11/117/160/444/718 : toutes PASSES en0.72..1.22CPU,
y compris separation de moments. Aucune nouvelle exclusion. Source LAB8df38b9,
data/codex_rank6_20261018; notes/MOMENTS_RANG6_2026_10_18.txt. Suite : lettres
et realisation simultanee des coins. Regulateur cpu_guard_rank6 actif,
core14 partage, pause72/reprise62. Pas de lancement distant.

18/10 18h49 - Lanceur catalogue+index ajoute : root_component_z_pipeline.py.
--design-seconds5 --joint-seconds10, sortie par gabarit; aucune enumeration
Gram/budget. Distingue certificat entier relu, verdict CP, temoin agrege,
et UNKNOWN. Pilote index0 dimension6 :269 etats, design SAT,0.96875CPU;
aucune exclusion. Pilote branche certificat5128 passe, constante -4.
Voir notes/PIPELINE_COMPTES_PAR_INDEX_2026_10_18.txt. LAB1082 fournit80
cas a grosses couvertures; aucun scan distant lance ici. Calculs termines.

18/10 18h45 - 8650 reste OUVERT. Catalogue308 etats, dimension5 (pas6),
malgre37709 Gram dans l'ancienne couverture. Temoin agrege SAT; ses
blocs/coins/projecteurs passent, mais sa realisation binaire C1 est
INFEASIBLE0.390625CPU (un temoin seulement, toutes permutations libres).
Nouveau root_component_z_joint.py : comptes et Gamma ensembles,4718
variables, aucun Gram/budget/C2 individuelle; UNKNOWN10s CPU. Controles
positifs SRG9 libre et243 a aretes booleennes fixees passes. Voir
notes/COMPTES_ET_REALISATION_8650_2026_10_18.txt. Tous calculs termines;
regulateur zdesign8650 termine automatiquement apres inactivite.

18/10 18h32 - 4192 exclu aussi SANS Gram/budget :167 etats de lignes,
certificat72 egalites+5 bornes, constante -8; lecteur entier valide.
Relation necessaire ajoutee :2*n(degre2)<=n(degre1) dans tout rectangle
non-grille (E3 donne au plus2 aretes). --degree-histograms --reduce-full.
Voir notes/CERTIFICAT_COMPTES_4192_2026_10_18.txt. Renforce l'ancienne
exclusion sur79 Gram; aucune exclusion globale. Aucun verdict LAB retire
n'intervient. Calculs termines, regulateur zdesign4192 arrete proprement.

18/10 18h26 - RETRACTION LAB1076 : les verdicts sans Gram des messages
1067/1069/1071 sont NULS (domain[-1] sur champ proto OR-Tools9.15).
LAB corrige :5128/3744 UNKNOWN90s; gfm1 non lancee, verdicts non comptes.
Voir notes/RETRACTION_LAB_SANS_GRAM_2026_10_18.txt pour la liste/scope.
conway_linear_explanation.py est deja sur : domaines convertis en listes
ligne85 avant exact_farkas. Le certificat entier c701fd6b est independant
et conserve sa portee. Ne pas confondre les essais c4 locaux de LAB avec
nos calculs de racine choisie. Aucun calcul local relance.

18/10 18h23 - Certificat sans Gram pour5128 : 4e_15+21e_35+8e_45>=68,
mais E3 donne chacun<=2, donc <=66. Catalogue exhaustif192 etats de
lignes Z, cinq coordonnees libres; deux moments diagonaux suffisent.
Aucun budget de prismes, aucun rang/Gram fixe. Certificat40 egalites+3
majorations, constante -4; lecteur Python standard en entiers valide.
Voir notes/CERTIFICAT_COMPTES_5128_2026_10_18.txt. Ne concerne que ce
gabarit, pas exclusion globale. Regulateur zdesign arrete proprement.

18/10 18h00 - Moments sans couverture de Gram ajoutes.
API root_component_neighbor_moments.add_neighbor_moments :
sum binom(z_w,2)+e(Q)=8; sommes mixtes24/32, tables entieres.
Valable pour tout SRG(v,k,1,2), sans rang ni c minimum. Controles
positifs rook9 et SRG243 passes. weak_line_global --rectangle-moments full
branche ces contraintes sur les huit positions globales. Cas7/root budget51
UNKNOWN30.3125CPU (pas de nouvelle exclusion),317640variables.
Voir notes/MOMENTS_VOISINS_SANS_GRAM_2026_10_18.txt. Regulateur neighbor
arrete proprement; aucun calcul local laisse actif. LAB1067 traite les
moments directs H, sans reenumeration de Gram; pas de campagne dupliquee.

18/10 17h34 - Explication uniforme de4192 : un seul polynome a huit
termes separe les21 Gram non vides, marges entieres1..9; les58 autres
ont un rectangle vide. Rapport template_04192_common_moment.json.
Les calculs locaux sont termines; regulateur cpu_guard_moments arrete
proprement. LAB a recu80556dc3 pour integrer la separation a sa passe3.
Les noyaux supplementaires n'ont pas servi; aucune exclusion globale.

18/10 17h29 - 4192 ferme egalement :79/79 Gram LAB1d35230 exclus
par coins/moments,9.328125CPU.58tables vides,16bornes simples,5combinaisons
certifiees en entiers (LP propose seulement). Gram35 : moment h3(h0+h4)
exige0 mais somme des minima>=1. API analyze_gram(...,separate_moments=True).
Voir notes/SEPARATION_MOMENTS_4192_2026_10_18.txt. Aucune exclusion globale.
Regulateur microscope precedent termine automatiquement apres300s inactif.

18/10 17h25 - NOUVEAU : gabarit c3 5128 exclu sur les cinq Gram LAB.
Obstruction exacte sans SAT : moment des coordonnees (0,3)/(0,4) exige
[-42,-42,-35,-35,-35], maxima des21rectangles [-44,-45,-37,-36,-39].
Toutes les tables locales non vides. Couverture5Gram acceptee de LAB1d35230,
sous budget de racine51; aucune exclusion globale de Conway. Filtre API
root_component_corner_moment_bounds.analyze_gram(edges,R), rang<=5.
Voir notes/OBSTRUCTION_MOMENTS_5128_2026_10_18.txt et rapport associe.
Regulateur microscope actif : core14 partage, pause72/reprise62.

18/10 16h45 ? Suite globale ajoutee (aucun nouveau verdict d'exclusion).
code/codex/root_component_weak_line_global.py : huit positions exhaustives
pour une droite c<=3 relativement a une racine quelconque; gabarit libre.
Le budget51 optionnel porte UNIQUEMENT sur la racine, pas sur cette droite.
Condition c<=3 encodee exactement par foret orientee,12controles passes
et reconstruction SRG(9,4,1,2) valide. Cas7 UNKNOWN30.1875CPU.
Voir notes/DROITE_PETITE_ET_RACINE_2026_10_18.txt; cout global non prouve.
Calculs locaux termines, regulateurs core14 et weakline arretes proprement.

18/10 16h36 — ETAT ACTUEL, prioritaire sur les anciennes entrees.
La branche minimum GLOBAL c(L)>=4 est fermee par CP-SAT : 79/79 a la
racine minimisant9s+8g. Dernier19/droite6/couplage4 INFEASIBLE116.71875CPU,
429 Gram libres avec tables de coins factorisees. Les couplages0/1/2/3
etaient exclus; flips residuels couvrent6 depuis3 et5/7/8 depuis4.
Assemblage : data/codex_domain_recovery_20261018/c4_selected_root_closed.json
et c4_19_matching_summary_closed.json. Les couvertures Gram enrichies ont
TOUS les champs de base identiques, comparaison exacte dans le mergeur.
Consequence : tout Conway eventuel a une droite L avec c(L)<=3.
Attention : cela ne donne PAS un budget51 a cette droite arbitraire.
Front transportable d93/907 INCHANGE :76/79, ouverts7/9/19.
Verdicts CP-SAT, pas de certificat portable de la fermeture complete.
Les calculs base19 et grille/min4 ont ete arretes comme redondants,
sans nouveau verdict. Aucun graphe de Conway exclu globalement.
La suite vise une formulation globale autour d'une droite c<=3,
complementaire de la campagne c>=3 de LAB. Voir RACINE_PONDEREE.

18/10 16h17 — ETAT HISTORIQUE.
La famille9 est INFEASIBLE a la racine minimisant9s+8g : modele unique,
12 Gram libres, tous couplages libres, no-transport,264.984375s CPU.
Rapport data/codex_domain_recovery_20261018/c4_9_all_variable_base.json,
commit7b6642f3. Verdict CP-SAT sans certificat portable de famille.
Sous minimum GLOBAL c>=4, seule19 reste a la racine choisie (78/79).
Le front ARBITRAIRE reste76/79 : ne pas retirer9 de d93/907.
19 :429 Gram, une orbite de couplages encore ouverte {4,5,7,8} a droite6.
Coins19 prepares puis factorises exactement :1138205 ->159822 lignes.
Pilotes actifs : base19 all-in-one, et19/droite6/couplage4 avec coins factorises.
Nouvelle formulation grille9 +9 fibres10 en cours ; controle Clebsch16 passe.
Regulateur actif cpu_guard_core14 : 1 coeur logique partage (indice14),
pause72%, reprise62%, pause minimale5s. Il remplace cpu_guard_72.
Aucune exclusion globale de Conway a ce stade. Voir fin de RACINE_PONDEREE.
18/10 15h05 : les19 retraits Gram ont chacun une CNF/DRAT verifiee natif.
19/etoile6 :0,1,2,3 exclus directement;6 exclu par flip qui fixe la premiere
composante normalisee point par point. Une orbite ouverte {4,5,7,8}.
9/etoile4 :2 exclu, donc1 aussi. Bilans *_matching_summary_1505.json.
Nouveaux complete_star : --mate-flip-orbits; --all-matchings-variable
--no-transport; --minimum-prism-root (scopeprisms, jamais cumule au pondere).
Ces options ne ferment aucun nouveau gabarit a elles seules. Voir note.
18/10 13h45 : selected_weighted_gram_cover.json conserve 12 Gram de9 et429 de19.
Le filtre binaire a retire19 Gram de19, seulement a la racine ponderee.
Tables --grid-corner-tables : les quatre coins d'une grille transportee
forment un couplage parfait des huit labels restants; intersections avec
une ancienne grille : 0/1/3 sommets. Premier19/etoile6/couplage0 ferme
sur les429 Gram en27.484375CPU. Couplages1..8 en cours, pas de fermeture19.
Voir fin de notes/RACINE_PONDEREE_2026_10_18.txt. LP continue, meme avec
blossoms, insuffisante pour expliquer les19 retraits (minima43/44/46).
PRIORITE18/10 13h15 : certificat ENTIER positif3P+4G<=2772.
Voir notes/RACINE_PONDEREE_2026_10_18.txt et weighted_root_certificate.json
dans data/codex_domain_recovery_20261018. Choisir la racine minimisant
9s+8g donne score<=504. Sousc>=4 :s<=49, couverture51 applicable;
gabarit7 exclu COMME RACINE CHOISIE (score>=528),9 reste avecs<=48,
19 reste avecs<=47 (g19=10, PAS7). Nouvelle couverture choisie77/79,
deux ouverts9/19. Le front ARBITRAIRE reste76/79,ouverts7/9/19.
NE PAS supprimer7 du front d93/907, ni cumuler minimums et minimum9s+8g.
Le nouvel ordre --weighted-prism-grid-root est encode et marque; ses
exclusions ne sont pas transportables aux racines quelconques.

CORRECTION PRIORITAIRE18/10 11h40 : les produits de residus lisaient domain[-1]
sur le conteneur OR-Tools9.15, obtenant0 au lieu de3. Bornes incorrectes;
les verdicts dependants sont RETIRES. c4:76/79 non touches par ce bug,
7/9/19 REOUVERTS. Pilote c3:0 exclusion valide,162verdicts retires.
Voir notes/CORRECTION_DOMAIN_ORTOOLS_2026_10_18.txt. Les anciens bilans
ci-dessous sont historiques et ne font plus autorite. Correctif en cours.

# Direction active de la recherche

18/10, etat prioritaire : branche minimumGLOBAL c=4 fermee79/79,15/15
anciens ouverts (4217113). Pilote c>=3 maintenant TERMINE : les3g1 et
g2 indices0/3/5/11/15 exclus,162/162couplages INFEASIBLE au presolve.
Outil root_component_complete_star.py : couplage COMPLET d'une etoile,
Gram/P/M1variables; aucune table907/frontd93/minimum4 transporte.
SourcesLAB10052gabarits->106852couplages,10044gabarits restant a traiter.
Bilan notes/PILOTE_CMIN3_2026_10_18.txt; donnees codex_c3_pilot_20261018.
CPUuncoeur/prioritebasse, pic560Mio,chargeglobaleobservee<=20%. AucunAWS.
Aucune non-existence globale prouvee; verdictsCP-SAT sans preuveportable.
Ne pas relancer les anciennes15familles ni les pilotes deja clos.


16/10, LAB941 lu/ack : minimum OBSERVE rangF7(8T44)>=30 sur3722 NG,
pas theorem universel. Borne necessaire ancienne<=28 (r7-15, r7<=43)
encodee en OPTION --rank7-bound28 dans root_component_global.py.
modular_rank_factor.py impose M=UV modulo7 avec facteurs44x28,28x44
INDEPENDANTS (pas UU^t ni choix de pivots). Equivalent exactement au
rang<=28. Cout58608variables supplementaires ; performance non mesuree.
Petits controles SAT/UNSAT rangs0/1/2 et representant -1 passes.
Template19 complet avec option compile/valide, pas lance long. L'ancien
INFEASIBLE11s du198 n'utilise PAS cette contrainte. Dernier envoi942
contenait72d47c3/cover79 ; archive suivante ajoutera cette option.

16/10, suite branche minc4 : borne GLOBALE racine choisie, sum_{l->x}t(l)
<=floor(6*852/99)=51. Cette somme est le nombre d'aretes orthogonales
dans les21 rectangles Q_ij. Force m_NG>=9 :100templates ->87. Test des
Gram variables+minimum orthogonal des4coins :8 autres INFEASIBLE,
79 restent,0UNKNOWN (~6s). Donnee root_component_gram_budget51.json.
Les coupes avec root_prism_budget51 exigent cette restriction au solveur.
Nouveau root_component_global.py : toutes C1/C2 surGamma84 LIBRE, R
variable, aucun ancien seed ni Gram temoin fixe. Normalisation matching
independante desactivee pour ne pas perdre de templates. Propagation
fixe1420..1636 aretes ; tous100 restent possibles avant solveur.
Premier modele global template198 : INFEASIBLE11.04s,1894aretesvariables,
1592forcees,85084produits. VerdictCP-SAT, pas de preuve portable encore.
Template19 (toutc4) compile/valide avec2coupes, pas lance long. Ancien
calibrage189UNKNOWN30s devenu inutile comme racine choisie (m7<9).
Manifeste root_component_cover79.json :1INFEASIBLE,78NOT_RUN. La
branche minc<=3 et le cout des78 restent ouverts. Note QUOTIENT_... mise
a jour sections7/8. Envoi940 livraitcd34d43 avant reduction100->79.
LAB938/939 lus/ack : quasi-saturation impair0.99993, souvent doublement
impaire, pas de nouvelle preuve ; LAB s'arrete pour ce soir.

16/10, LAB937 lu/ack. Nouvelle branche GLOBALE pour min c=4, sans ODD-PURE.
Sept droites racine, rectangles Q_ij de quatre labels. Les composantes
partagent les six autres droites en 1^6 / 2,1^4 / 3,1^3 / 2,2,1,1.
G sans-grille a degres0/2/3/4 ; scinder chaque degre4 en deux paires.
R=Gram des sommes des rectangles, entier, diagNG dans2/4/6/8,
0<=R<=28I. Incidence NON ORIENTEE C des composantes donne CR=0.
Enumeration complete2^21 graphes ->221 types,12951 choix, puis367
survivants structurels /200 a isomorphisme pres. dim ker C<=4 partout.
Solveur entier+PSD exactes+4 coins binaires:97 infaisables,103 possibles,
dont3 minimumc>=5. Donc minc4 couvert par100 configurations restantes.
ATTENTION100 configurations ne sont PAS100 Gram fixes ni100 graphes ;
R doit rester variable. Aucun UNKNOWN sur quotient, cout~12s, cout de
realisation globale inconnu. Pas de preuve de non-existence de Conway.
Nouveau domaine h entier, h dans imR, h^tR^+h<=5/2 : <=625 essais
par rectangle (16 signatures max sur premiers temoins). Quatre h doivent
sommer a R_e et satisfaire le Schur4x4 avec un graphe interne binaire.
Note QUOTIENT_COMPOSANTES_RACINE_2026_10_16.txt. Outils root_component_*
et root_rectangle_domains.py ; donnees root_component_templates.json
et root_component_gram_realization.json dans dossier resonance20261016.
Prochaine integration solveur : equations cardinalite (5), sans ajouter
une normalisation de matching incompatible avec le template choisi.

16/10, suite notifications930/932 retardees (deja lues), boite vide.
NOUVELLE forme du couplage envoyee935 : U20 fixe, P12 pair,R12 impair.
K=T_UU, C=T_UR, N=T_UP ; elimination Phi11 donne K1,N1,E et Schur32.
Correction de taille dans note energie :32, ou33 en gardant l'impair nul.
rangK=21-c(l) PROUVE par noyau des deux etoiles et suppression des coins.
Les deux colonnes paires des coins sont dans spanGramU via chi0,chi1.
Z12=E-N1t K1^+ N1 a ces2 lignes nulles et le reste EST Z10 exactement.
delta=rangK-rangK1=9-rangD ; ODD-PURE equivaut a kerK1=kerK.
rangT=32-c(l)-delta+rangZ. Universel delta0/Z>=3 toujours OUVERT.
Impasses concretes : N1 peut avoir tout le rangE (aucune direction
decouplee) ; K-CCt/2 indefini (temoins2coordonnees rationnels sauves).
Trace normalisee seule ne suffit pas : urep100 tau343/180<2 ; deux
traces restent suffisantes sur12 NG seulement. Sous-espace des differences
mates seul insuffisant : c11_mix6 rang2 ; sommes seules : urep100 rang0.
Preuve notes/COUPLAGE_VINGT_FIXES_2026_10_16.txt ; outil
four_star_sector_coupling.py et sector_coupling.json dans repertoire habituel.

16/10, LAB932 lu/ack : son Phi=6I-As-J/2 impair sur12 a rang11 et
gap>=2 sur1perp. NOUVELLE borne paire universelle derivee (pas un scan) :
sur24 labels de deux etoiles, G=G0+(I-M)/2, D0=4I-As,
[[G0,H],[Ht,D0]]=compression de la laplacienne2I-Gamma24, PSD,
0<=D0<=8I, H1=0. Donc H Phi^+ Ht<=(4/5)H D0^+Ht<=(4/5)G0.
E=G-H Phi^+Ht >= G/5+(2/5)(I-M) >=G/5 ; rangE=rangG=12-c.
L'elimination impaire INTERNE a deux etoiles conserve le rang pair.
Cela ne traite PAS l'elimination des20 autres etiquettes dans44.
Le couplage entre les deux paires reste le point ouvert de SYM6/ODD-PURE.
Preuve notes/BORNE_ENERGIE_PAIRE_2026_10_16.txt ; outil
code/codex/four_star_even_energy.py ; donnees even_energy.json dans
data/codex_line_resonance_20261016. Marges rationnelles PSD enregistrees
sur10 objets, pas de recertification du lemme impair ni de nouveau census.

16/10, suite SYM6, message930 deja lu/ack (notification retardee, boite vide).
NOUVELLE identite de bord : G=PtT_YY P=(9/2)I-M/2-PtGamma_YY P
est une laplacienne avec attaches rho=G1 vers les quatre coins O.
r=sumrho=8-2e(O), nul exactement sur grille. rangG=11-c(m), via
contraction des triplets {s,2s,3s} du voisinage cubique de l'AUTRE droite.
Si non-grille, eliminer la seule direction u=1_O donne
L=G-rho rho^t/r, VRAIE laplacienne, rangL=10-c(m)>=5.
ATTENTION : c'est avant les autres eliminations, PAS une borne pour Z.
A=L-K0^t R_X^+K0 puis Z=A-CD^+Ct peuvent encore perdre du rang.
R_X=T_X-(T_Xu)(T_Xu)^t/r, K0=K+(T_Xu)rho^t/r.
Les6 NG ont r=8 sauf urep100 r=4 ; c11_mix6 perd6 directions L9->A3.
Preuve notes/SECTEUR_SYMETRIQUE_BORD_2026_10_16.txt ; outil
code/codex/four_star_sym6_boundary.py ; sortie sym6_boundary.json
dans data/codex_line_resonance_20261016. Calcul exact du NOUVEL invariant
sur10 objets acceptes, pas re-audit. SYM6 universel demeure ouvert.

16/10, suite LAB928 lu/ack ; message929 : reduction SYM6 exacte 10x10.
Pour F20 et w=Pf+Rg, A=PtFP,C=PtFR,D=RtFR,
Z=A-CD^+Ct, W=D-CtA^+C. Toutes PSD sauf C ; Z1=W1=0.
dim projection sommes kerQ=9-rangZ, differences=10-rangW.
SYM6 <=> rangZ>=3 ; ODDCONST <=> rangW=9. Condition plus faible
rangD=9 jointe a rangZ>=3 suffit pour rangF>=12. Si ODDCONST,
rangA=rangZ ; on peut viser la compression A sans seconde elimination.
Nouvel invariant sur10 objets deja acceptes, sans re-audit ni recensement :
12 cotes NG ont D9,Z3..5 et (trZ)^2>2tr(Z^2). La borne UNIVERSELLE
reste ouverte. Grille Z5h_c62 cote m : ODDCONST vrai MAIS Z=0 ;
les deux mecanismes peuvent donc echouer separement. Z a des coefficients
hors diagonale des deux signes, pas une laplacienne a poids positifs.
Conway + c_min<=4 + D9 imposerait rangZ<=c_min-2 : c1 impossible,
c2 demande seulement Z non nul, c3 rang>=2, c4 rang>=3.
Preuve notes/REDUCTION_SYM6_10_2026_10_16.txt ; outil
code/codex/four_star_sym6_reduction.py ; data dans
data/codex_line_resonance_20261016/sym6_sectors.json.
LAB prend le secteur impair via son lemme d'energie, Codex le symetrique.

16/10, suite LAB925 lu/ack : nouveau Q20 de resonance calcule exactement
sur10 objets, deux orientations. corank(Q)<=4 FAUX sur blocs locaux NG,
dont urep100 rang30 : corang7. Nouvelle reduction PLUS PRECISE prouvee :
V=0, Q1=-5/3*1, F=Q+J/12 PSD, nu(T44)=c(l)+2+corank(Q),
rank(T44)=23-c(l)+rank(F). Pour l de c MINIMUM, N9-NG equivaut a rank(F)>=12.
Un Conway force un bloc NG avec c_min<=4 (P<=852), donc rank(F)<=11.
La borne universelle12 EST OUVERTE ; les6 NG testes ont rang12 ou13,
les3 grilles rang30 ont rang9 dans l'orientation minimale. Deux traces
ne donnent que9 sur les6 NG : pas de preuve par ce seul quotient.
Preuve notes/REDUCTION_RESONANCE_20_2026_10_16.txt ; outil
code/codex/four_star_line_resonance.py ; donnees/certificats exacts
data/codex_line_resonance_20261016/initial_objects.json. Envoi926 a LAB.
Pas de re-audit des objets du pair, ni solveur long ; calcul du nouvel
invariant et demonstration algebrique de la reduction. Pas de contradiction
globale annoncee : seul le conflit CONDITIONNEL rang>=12 contre<=11 tient.

16/10, synthese demandee dans le cadre de la recherche d'asymetrie (LAB921).
Lire notes/SYNTHESE_FAMILLE_ASYMETRIE_2026_10_16.txt : cinq parametres,
huit243, registre des reductions avec leur portee, conjectures retirees.
Nouveau rapprochement, pas nouvelle exclusion : pour une composante C
du voisinage cubique M d'un triangle, c=|C|,
sum_F (n_C-2c/(k-2))^2=(k-14)c(1-c/(3(k-2))).
Une grille induite laisse (k-4)(k-14)/2 sommets exterieurs sans voisin.
Meme resonance k=14, r=3 ; a243 la grille laisse72 sommets, variance positive.
Ces consequences liees ne sont pas des preuves independantes. Si M connexe,
l'equilibre est trivial. Aucune grille ni automorphisme global force.
Racines rigides Gamma6/8 avec Aut108 : la symetrie peut deplacer la racine.
Critere exact : moins de completions ETIQUETEES que |Aut(bord)| interdit
une completion asymetrique ; il manque un MEME bord inevitable reunissant
ces hypotheses. Les reductions43/44 ne prouvent pas sa symetrie.
LAB916/918 corrige l'ancien blocage7e label : R7 libre SAT, R8 libre UNKNOWN.
LAB920 a deja les caps C2 L4 ; nos modeles globaux ont tous quotas racine.
Dernier lu/ack921 ; message922 demande si les egalites de composantes sont
deja chargees dans R8. Aucun long solveur ni re-audit du pair relance.
Table exacte : family_saturation_synthesis.py et data/codex_family_synthesis_20261016/.
Livraison51460e5 envoyee923 : family_synthesis_51460e5_20261016.zip dans
lab_exchange_2026-10-14/codex_hmatch_20261016 ; registre48 entrees, note28Ko.

16/10, suite LAB907 (lu/ack), reponse908 : exploitation GLOBALE du lemme
de rang/trace deja present dans core_repair. Sur84 avec Gamma BINAIRE et
TOUS C1 exacts, les DEUX PSD T,U suffisent a TOUS C2, sans imposer de rang.
Sur kerB dim70 : T=3I-Gamma,U=4I+Gamma, trT210,trT^2=1470=7trT.
Donc PSD des deux => spectreT dans{0,7}. Preuve conway_global_psd_equivalence.
conway_global_psd.py + options global_lazy --psd-only/--psd-library :
398 anciennes coupes universelles reutilisees,23 nouveaux vecteurs negatifs
sur notre temoin C1, certifies entiers.421 coupes sauvees/rechargeables.
Pilote GLOBAL19types60s UNKNOWN,30217 branches104 conflits, aucun nouveau
candidat du solveur. Le candidat initial est explicitement fourni comme
indication ; il n'est pas pretendu satisfaire les398 anciennes coupes.
Gamma0=(2J-Bt(I+M)B)/10 est un CENTRE FRACTIONNAIRE C1 exact, T=3P,U=4P.
Ainsi la PSD continue seule est faisable ; l'integralite reste indispensable.
Identite globale : tr(TU)=sum_ij Gamma_ij*(1-Gamma_ij). Aucune exclusion.
La preuve5lignes du gris est C1/C2 seulement, sans PSD (repondu a LAB908).
LAB907 : ses18 cas5etoiles sont TIMEOUT90min, aucun verdict general ;
accepter les resultats sans re-audit. Continuer global, pas retour15fixe.
Replay421 sans calcul controle, modules compiles. Aucun solveur actif.
Livraison910 : global_psd_54b8f15_20261016.zip,114525octets/13 fichiers,
README_GLOBAL_PSD.txt a plat dans codex_hmatch_20261016. LAB909 lu/ack :
accord sur l'equivalence globale ; il mesure maintenant le cout5etoiles
par cubes echantillonnes. Ce sera une estimation, pas une borne certifiee.

16/10, suite de la demande DIRECTE de Dilan d'une contradiction GLOBALE :
ne plus prendre l'exclusion/reparation du temoin15 comme objectif principal.
NOUVEAU conway_global_cover.py : modele EXACT du99 sans germe,3486 aretes,
tous comptes racines et C2. Toute etoile normalisee par11 partitions de6.
Avec droite de t MINIMUM<=7 (cap global P<=852) et partenaire NON-GRILLE,
19 types POINTES couvrent tous les graphes. Les10395 matchings ont ete
classes exactement ;19 types ne signifie PAS19 graphes ni cout abordable.
Preuve complete data/codex_local_global_20261015/conway_global_cover_proof_20261016.txt.
Modeles complets pilotes30/60s UNKNOWN ; le second explore77124 branches.
NOUVEAU conway_global_lazy.py : les comptes racines exacts imposent le total
166 sur chaque ligne des comptes de paires. Les seules bornes <=2 suffisent
donc a toutes les egalites. Chaque exces livre une clause universelle sur
3 a6 aretes. Couverture globale conservee, aucune arête ancienne fixee.
CP :3505 variables dont19 selecteurs, sans produits ; SAT seqcounter41550.
Pilotes initiaux G4/CP60/30s UNKNOWN sans premier candidat. Contournement :
conway_root_count_seed.py construit en0.240s les comptes racines complets
via252 orbites, puis libere TOUTES les aretes et la symetrie. Ce n'est PAS
un SRG :1015 paires en exces,total1596. Amorcage global45s :2483 clauses
universelles extraites, aucun deuxieme candidat, UNKNOWN. Pas de fermeture
globale ni de borne abordable prouvee. Petit backend Minicard sorti avec
code1 sans verdict sur99 ; option retiree. G4 et CP controles9 SAT/19 UNSAT.
SAT garde aussi ses clauses internes pendant un run ; CP ne conserve que
les coupes explicites entre resolutions ; resume recharge ces coupes.
Code/data/journal sont conserves. Aucun solveur actif apres ces pilotes.
Pont :903 dernier lu/ack ;905 annonce la direction globale,906 livre0097ca5.
Archive global_cover_0097ca5_20261016.zip :107181octets/30 fichiers dans
lab_exchange_2026-10-14/codex_hmatch_20261016, README_GLOBAL_COVER.txt a plat.
Reprise2483 clauses controlee sans lancer de recherche. Aucun worker actif.

16/10, 13h56 locale, suite de la matrice affichee : le TEMOIN PRECIS15
(global_star15_balanced_search_20261016.json) est maintenant PROUVE NON
PROLONGEABLE. Ne plus le presenter comme une piste d'extension encore ouverte.
Les comptes partiels controles restent corrects, mais cinq lignes suffisent
pour une contradiction : 02,03,47,48,413. Pour x={7,13}, les quotas forcent
ses voisins {0,5},{2,5},{3,5} dans L5, alors que le quota vaut2.
Preuve lisible global_star15_gray_proof_20261016.txt ; propagation entiere
sans solveur, certificat5 lignes de21 contraintes/40 deductions. Support
reduit gloutonnement, aucune minimalite absolue revendiquee.
Coupe universelle issue de ce motif :58 aretes positives, somme<=57.
Conway_gray_cuts.py reconstruit la preuve avant application ; option
core_repair --gray-library, reprise des coupes conservee. Toute reparation
doit toucher au moins un de ces CINQ voisinages ; changer seulement les69
lignes inconnues ne suffit pas.
Nouveau filtre gray_block : E symetrique binaire, quotas de toutes les
lignes restantes et BE=2J-intersections-AB-B. Le L4 du temoin15 est lui-meme
UNSAT dans cette relaxation (CP,2.213s). Aucun separateur LP extrait en5s,
sans conclusion sur la faisabilite LP. Aucun graphe99 globalement exclu.
Recherche gray_repair bornee :40 cadres/44.8s,6 UNSAT34 UNKNOWN a1s ;
7 UNKNOWN repris a5s donnent4 UNSAT3 UNKNOWN. AUCUN nouveau cadre passant
le filtre construit, composante non epuisee, aucun solveur actif.
star_extension et verify_partial renforcent les quotas des sommets encore
incomplets. Controles propres : preuve entiere, coupeCP, six modules compiles,
CLI core_repair charge. Aucun re-audit de LAB.
Pont :903 lu/ack ; nouvelle livraison envoyee904, archive
lab_exchange_2026-10-14/codex_hmatch_20261016/gray_block_obstruction_20261016.zip
(137342 octets,15 fichiers). LAB fait une revue historique a la demande
de Dilan ; il ne travaille plus sur le cinq-etoiles pendant cette revue.

16/10, suite du message899 : nouveaux lemmes sur les appariements REELS
phi0 et phi2, aucune symetrie supposee. conway_phi_defect.py contient les
preuves completes : P+t-2delta<=10, donc D>=10 et au moins3 lignes X
rompues par phi. Joint : broken_union+AND(edge02_13,edge03_12)>=4.
Si5 lignes sont invariantes aux deux phi, leurs voisinages anciens sont
des composantes K2 disjointes ; comptage40-4c<=36 puis22<=18 force
les DEUX diagonales02--13 et03--12. Coupes integrees a core_repair52/84.
LAB901 accepte le premier lemme phi ; aucune re-verification du pair.
NOUVELLE CONSTRUCTION :15 lignes COMPLETES sur84, toute L4 plus02,03,010,
avec TOUS les comptes des lignes, C2 mutuels et caps partiels exacts.
global_star15_balanced_search_20261016.json ; PAS une seconde etoile
complete, PAS un52/84/99 complet. Aucun solveur actif apres cette passe.
Mecanisme constructif : echanges equilibres entre2 lignes de L4, bijection
des60 colonnes non appariees conservee, appariement interneM4 conserve.
Les colonnes L5 peuvent aussi etre echangees sous bilan de lettres nul.
conway_star_trades.py :12->13 par3 echanges, puis13->15 par1 echange
et recalcul des3 lignes exterieures. Aucun ancien germe44 fixe.
Anatomie exacte : dans le13 intermediaire, seules02,03,08,013 peuvent
etre ajoutees dans L0 ; chacune a UN SEUL domaine complet. Six paires
incompatibles : comptes communs0/3/3/2/0 au lieu de1, ou arete exigee
et interdite. Une seule ligne peut s'ajouter (14 construit), puis il
faut reparer le13. C'est fait par le15, sans supprimer les contraintes.
Outils conway_star_extension.py et conway_star_row_domains.py.
Recherche de23 lignes via100 cadres equilibres : INCOMPLETE,175 cadres
en file ; ni exclusion des deux etoiles ni exclusion du typeM4.
M4 union appariement des lettres : un cycle10 et une arete commune.
Dernier recu901, dernier envoi902. Livraison83ecbbe :
global_star15_phi_83ecbbe.zip,68830 octets,20 fichiers, dans
lab_exchange_2026-10-14/codex_hmatch_20261016. Preuves,13/14/15 exacts,
domaines singletons et limites des recherches inclus ; README/LEMMES a plat.

16/10, NOUVELLE consigne directe de Dilan : priorite a l'outil44->84->99,
anatomie microscopique des echecs, reparer les blocages et generaliser.
Partage convenu885/886 : Codex repare urep100, LAB analyse HB puis genere
des germes DISC-vivants. Pas de verification independante du travail pair.
Nouveaux outils four_star_rank_release.py et conway_core_repair.py : retirer
des sommets, garder un coeur principal, reconstruire tous les sommets retires
ET (4,6), sans fixer les anciens noyaux. Trois suppressions suffisent :
coeur41 rangsT29/U39. Colonnes enumerables exactement, residus Schur rang1
traites par signes ; rangs plus grands par PSD/rang exacts + petits nogoods.
Reparations guidees par les temoins : coeurs41,39,38,33 exclus pour le
prolongement45 ; coeur33 reconstruit le44 original sans x (controle positif).
Coeur30 T25/U30 :106 colonnes pourx,15 domaines complets ; assemblage
INCOMPLET en45s (avec et sans DISC), aucun verdict d'impossibilite.
886-887 de LAB acceptes : DISC T30 classes{2,14}, U40 classes{1,7}.
Les643 germes rang30 de son corpus echouent, dont urep et HB ; pas de
re-audit ici. NOUVELLE integration : det(core_I)*det(Schur_J), quand
|J|=rang_global-rang_core, doit avoir la classe globale requise.
Option --disc appliquee aux colonnes des coeurs de corang1 et aux petits
mineurs pendant l'assemblage. Tests par isqrt entiers, pas factorisation.
Sur coeur41,3 colonnes lineaires :1 nonPSD T,2 classes interdites
30534=2*3*7*727 et79494=2*3*13249. Ainsi le coeur change bien l'espace
arithmetique, mais ces deux options restent globalement impossibles.
Sur coeur38 : coupes DISC de taillesT2/U3 au lieu des rangsT3/U4.
Dernier recu897, dernier envoi898. Livraison a963315 : archive autonome
global_columns_core30_a963315.zip dans codex_hmatch_20261016 (68 fichiers,
651228 octets), compte global84 et controle9. Lots64 et --resume termines,
domaines/coupes conserves entre passes, etiquettes manquantes modifiables.
NOUVEAU : coeur30 FERME par projection GLOBALE84.54 domaines complets,
choix simultanes soumis aux30 degres,420 comptes racines,435 comptes de
paires EXACTS : CP-SAT INFEASIBLE en25,283s (1worker). Aucun usage de DISC
ni H-MATCH ici. conway_core_column_design.py ; full_domains + design JSON.
La relaxation fractionnaire passe.47 branches fermees par separateurs
entiers,7 resistent a cette simplification (sans remettre en cause UNSAT).
Arbres purs10k et hybride20k noeuds incomplets : ne pas les confondre avec
le verdict global acquis. Positive control srg9 de l'outil : SAT. Le module
de comptes accepte root_count=4,14,22... pour lambda1/mu2.
Avant cette fermeture : --learn-psd,398 inegalites lineaires universelles
T/U apprises et1434 nogoods dans la tentative locale45.
Ces inegalites viennent de vecteurs entiers de valeur quadratique negative,
proposes numeriquement MAIS certifies par calcul entier, puis simplifies.
--psd-library les transporte entre coeurs ;28 coupes sansx transportees
au coeur33 et44 original reconstruit (controle du nouvel outil positif).
DISC de corang2 dans tables : coeur38 bloque deja sur x,(0,3),12 cas
dont9 PSD/rang et3 DISC, avant CP. Temoin universel signe sur15 etiquettes :
e(P7)+e(N8)-e(P7,N8)<=14 ; un candidat donnait15, q_T8=-4.
LAB890 accepte :31 bases44 fixes ne se prolongent pas a une etoile
exterieure complete (52 etiquettes) ;5etoiles SANS base encore inconclusif.
L'outil de reparation dispose de --stars5 pour viser directement52 avec
coeur libere, puis --full pour84. Domaines52 recuperees depuis84 sans recalcul.
Suite utile : liberer le coeur exclude OU generer sans base a5 etoiles ;
conserver les comptes globaux et les coupes transportables dans la recherche.
Aucun nouveau44 admissible, aucun52 admissible ni SRG99 construit.

Suite893 : NOUVELLE borne universelle de defaut, sans hypothese h.
Pour X={(4,y):y6..13}, comparer L0/L1 ou L2/L3 par h=(01)(23).
Chaque ligne a2 voisins de chaque cote : D=32-2P. Les paires w4,5
interdisent un recouvrement. Chacune des10 autres n'en accepte qu'UN,
car deux sommets de X partageraient racine4+deux voisins. Donc D>=12,
au moins3 des8 lignes rompent h. General k : D>=max(0,2k-16).
conway_five_star_defect.py ajoute ces coupes au reconstructeur52/84,
avec renforcement par capacites restantes et diagnostic. Controle positif
sur relaxation bipartite : D0=D2=12 atteints, PAS un bloc52 valide.
Ce premier motif laisse5 sommets a apparier dans L4 : parite impossible.
Suite constructive : choisir l'appariement L4 en meme temps que les
attaches, puis essayer de reconstruire les aretes anciennes libres.
AMELIORATION prouvee : au moins4 des8 lignes rompent h sur TOUT le44.
Si5 invariantes, leurs voisinages disjoints partitionnent36 etiquettes
evitant4,5. Les3 autres lignes ont au moins20 voisins anciens, et au plus
15+3+2=20 (le dernier2 vient de la parite de l'appariement L4). Egalite
force une ligne sans partenaire possible dans L4. Preuve complete journal
et conway_five_star_defect.py ; coupe union>=4 integree52/84, envoyee896.
conway_attachment_probe.py construit maintenant les attaches X->44 ET M4,
avec ancien44 libre. Premier motif :4 lignes rompues,44 lignes anciennes
individuellement possibles mais assemblage lineaire UNSAT0.049s.
Anatomie exacte :19 termes entiers de Farkas, somme0<=-1 ; en clair,
cinq demandes pour quatre places (aussi six pour quatre sur une autre ligne).
Generalisation integree : pour Y=anciens evitant4,5, un z n'ayant qu'un
voisin x dans X demande une place dans P={04,14,24,34}. Donc
private_Y(x)+deg_P(x)<=4, universel sans symetrie/ancien germe fixe.
NOUVEAU motif apres coupe : M4 valide,4 lignes rompues, TOUS les comptes
lineaires des44 lignes sont simultanement SAT (0.057s), C2 ancien/ancien
encore UNKNOWN au pilote CP20s. SAT specialise lance sur ce seul motif.
conway_linear_explanation.py extrait une preuve entiere par propagation
ou Farkas ; conway_attachment_sat.py encode exactement C1/C1'/C2 en CNF.
Controle du nouvel encodeur : etape lineaire SAT et matrice verifiee.
LAB895 accepte : design bijectif60 paires nonM4 pour les etiquettes hors
L4/L5, dont36 presentes dans S5 et24 a construire dehors. Notre coupe
private est la capacite residuelle des paires X-P dans ce design.
Le SAT complet52 sur le motif repare est UNKNOWN60s (trace DRAT inachevee,
PAS certificat). MAIS nouveau conway_star_frame.py l'exclut GLOBALement
en0.004s via le design60 paires + comptes des12 lignes de L4 sur84.
Explication exacte : paire X46/X413 sans voisin commun ancien ni arete,
racine4 commune, besoin d'un nouveau voisin commun ; leurs budgets
restants n'autorisent que la lettre13, donc AUCUNE etiquette a2 lettres.
Autre temoin X47/X412, seule lettre10. Coupe universelle de support
exterieur ajoutee a conway_five_star_defect et reconstructeur52/84.
Troisieme motif passe les supports individuels mais echoue au design
global0.25s : contraintes simultanees de capacites restent necessaires.
REPARATION constructive : --global-new-rows choisit directement les8
lignes de X sur84. SUCCES en10.817s,4 lignes rompues, tous les comptes
racines et C2 mutuels EXACTS. Donnees five_star_global_new_rows_20261016.json.
Ce n'est ni un52 complet ni un graphe84/99. Extension aux12 lignes de L4
REUSSIE via --global-star en38.483s, aucune arete d'un ancien germe imposee.
Construction five_star_global_star_20261016.json :12 lignes sur84,
degres12,168 comptes racines exacts,66 comptes C2 mutuels exacts,
colonnes L5 de poids1 et autres horsL4 de poids2, matrice partielle52
avec toutes les aretes incidentes aL4. Quatre lignes rompues exactement.
Les aretes entre les72 autres sommets restent inconnues ; aucun52 complet
ni SRG99, aucune preuve de non-existence generale. Aucun solveur actif.
Controle positif du nouvel outil design : sans equations de racines,
le design60 et appariement12 passent et la matrice est controlee exactement.
Les traces DRAT/CNF volumineuses des pilotes UNKNOWN sont locales non
versionnees ; ne pas les confondre avec une preuve. Aucun re-audit LAB.
Livraison15d74e9 en898 : global_star12_15d74e9.zip,52968 octets,
dans codex_hmatch_20261016. README_GLOBAL_STAR12.txt,6 modules et11 JSON.
Suite constructive : prolonger ce cadre12-global en liberant si besoin
ses choix d'attaches ; les72 autres lignes ne sont pas encore construites.

16/10, rappel DIRECT de Dilan : l'objectif ne se limite pas a fermer des
familles ; continuer vers une construction ou une obstruction generale.
NOUVELLE CONSTRUCTION livre880 : HB_1 casse nu13 accepte du pair -> nouvelle
incidence sur le MEME Gamma non etiquete, T PSD rang30/nu14, U PSD rang39,
C1/C1'/C2 exacts, H-MATCH intact. hmatch_promoted_hb1_20261016.json.
Methode nouvelle hmatch_root_schur_search.py : toute reconstruction des10
racines exterieures et de leurs partenaires, etoiles centrales fixees,
ramenee a DEUX Schur10 exacts. E_T=(3I-M)/8-W^t A0^+W ; E_U=(4I+M)/15-
W^t D0^+W. Conditions d'image obligatoires. PSD equivalentes et
rangT=rankA0-10+rangE_T, donc rangE_T<=40-rangA0 pour nu>=14.
Enumeration terminee : urep100,399 noeuds,1 incidence admissible,0,875s ;
HB_1,1437 noeuds,120 incidences admissibles,0,672s. Toutes H-MATCH intact.
PAS120 graphes non isomorphes. A0 rang37/36 respectivement. Controle exact
du NOUVEAU bloc HB promu, pas du germe du pair. Les pilotes naifs incomplets
ont ete remplaces par cette enumeration exacte terminee.
Prolongement HB promu tente jusqu'au bout de ses domaines : le sommet
(4,6) n'a AUCUNE colonne binaire compatible avec les noyaux et caps.
Les congruences individuelles et le reseau entier passent, la relaxation
LP aussi ; certificat exact par31 noeuds/16 feuilles de Farkas entieres.
four_star_completion_columns.py, rapport conway_completion_promoted_hb1_columns.
Le filtre est integre a Schur10 : les120 incidences HB admissibles echouent
toutes sur(4,6), enumeration terminee4,765s. Pas de complet99 construit.
Construction conjointe conway_extension_switches.py : partition orthogonale
libre + colonne nouvelle d, avec z=120 R d. Conditions d'image et caps sont
lineaires conditionnelles ; coupes de Schur entieres pour normeT=20,
normeU<=50. Cible maintenant le PROLONGEMENT, H-MATCH intact autorise.
Germes HB promu/H30_23 : impossible des la premiere colonne lineaire ;
urep100 :29 candidats,21 coupesT+21 coupesU+8 nogoods de normeT, puis
impossible en4,531s. Ceci concerne ces partitions4/6/8, pas C1 general.
Assemblage TERMINE : four_star_complete.py + schur_domain_join.py. Les
40 domaines sont enumeres, T sature force chacune des780 aretes restantes,
residuU PSD du rang prescrit (0/1 et general), controle des signes du
rang1, caps C2 sur TOUS les sommets presents, puis identite SRG99 exacte.
Controle positif de l'assemblage sur rook9 : graphe9 reconstruit, une
solution, signe parasite rejete ; incompatibilite de signes rang1 testee.
Nouvelle coupe old-pair : d_i+d_j<=1 quand la paire ancienne n'a plus de
marge C2. Elle reduit le certificat HB a9 noeuds/5 feuilles. urep100 :
exactement2 colonnes lineaires (4,6), toutes deux normeT=7808/425<20,
donc chacune force rangT45=31. Defaut de Schur=692/425>0.
Pilote reflexions urep avec old-pair :11 candidats,12 coupes old-pair,
5 tangentesT,6 tangentesU,6 nogoodsT ; impossible en1,906s.
Theoreme global : T+U=7Pi sur84, rangPi70, traceT210 ; T,U PSD et
rangT<=30 forcent T^2=7T, rangT30, rangU40, puis l'identite SRG99.
Le chemin complet est implemente pour un germe de rangT30 ; aucun germe
prolongeable ni SRG99 obtenu, pas de cout global abordable prouve.
Ne pas confondre cet assemblage fini conditionnel avec la resolution C1.
Les partitions de reflexions conjointes4/6/8 n'ont pas donne de bloc casse.
Le test H-MATCH du helper utilise maintenant uniquement les4 racines
centrales ; ancien masque trop large sans faux resultat positif livre.
Dernier recu884, dernier envoi883 : assemblage complet, critere global,
coupes old-pair et nouveaux certificats livres. Commit4e3ac85.
884 : bilan LAB accepte sans re-audit :416 classes,413 completes, environ
853000 structures, aucune cassee de nu>=14 ; ni preuve ni contre-exemple
H-MATCH. Une classe nu12 encore en cours selon le message. Sa decision
d'attendre un choix utilisateur ne remplace pas notre direction constructive
deja autorisee. Aucun nouvel accuse envoye au pair.
Aucun processus en arriere-plan.

877 lu/acquitte. Nouveau critere de construction, sans noyau fixe : pour
une etoile S et son matching P, W=projection_S(kerT) inter ker(P+I).
Si remplacer seulement P par P' garde T PSD, P'v=-v pour tout v dans W.
Les nouveaux partenaires doivent donc avoir des profils W opposes.
Sur urep100 et hv_h_c22_H30_23, exactement les6 anciennes aretes permises
dans chacune des4 etoiles : TOUT rematching pur est impossible, meme en
changeant noyau/rang. Dimensions W=3 et6 respectivement. Pour H30_23,
projection_S(kerT) surjective : aucune perturbation a diagonale nulle
confinee a S ne peut garder T PSD. Les240 switches4 des deux germes ont
des temoins entiers negatifs. Code hmatch_pure_switch_kernel_gate.py,
rapports hmatch_pure_switch_rank30_20261016 / _h30_23_20261016.
Pas de preuve du seuil14 universel, ni de H-MATCH. Les torsions combinees
restent ouvertes ; aucune verification repetee des certificats PSD du pair.
Preuve, code et certificats livres par878, commit431c6c7 et bundle
codex_hmatch_20261016. Dernier recu877, dernier envoi878. Aucun processus actif.

875 lu/acquitte ; reponse876 : aucune voie de preuve H-MATCH realiste
a court terme identifiee, aucun cout global abordable demontre. Proposition
de suite : rediger la reduction conditionnelle, puis coupler les21 blocs44
dans une meme Gamma84. Pour S44,R40 et q dans kerT_SS, la PSD globale force
8 Gamma_RS q=2(1^tq)1_R-B_R^t(3I+M)B_Sq. Si B_Sq=0 : Gamma_RSq=0.
C'est une contrainte necessaire de recollement, pas une preuve ni un pilote
execute. Les certificats n_45/b_29 NE couvrent PAS toute la classe obj53.
Cette precision a ete envoyee au pair. Aucun processus actif ; H-MATCH ouvert.

873 lu/acquitte, precision envoyee par874 : le filtre de remariage
4I+Gamma PSD porte sur TOUT R^44, sa compression a kerB est plus faible.
Le temoin n_45 n'est pas contraint a kerB ; aucune negativite certifiee
de cette compression n'a ete obtenue. A B fixe, le majorant independant
de M Q=4I+Gamma-(3B^tB+2J)/15 renforce encore le filtre, car4I-M>=3I.
Pas de re-audit des enumerations LAB, pas de processus actif ; H-MATCH ouvert.

Livre872 : les obstructions spectrales fixes et les deux familles de
remariage, commit b9386ab, bundle lab_exchange/codex_hmatch_20261016.
871 lu/acquitte ensuite : LAB avait confirme la fuite de b_29 et son
absence pour n_45. Notre872 apporte une obstruction SUPPLEMENTAIRE pour
n_45 (Gamma a deja lambda_min<-4), sans contredire l'absence de fuite.
Le A' abstrait peut etre augmente, mais aucun M reel de cette geometrie
ne peut reparer U a Gamma fixe. Pas de reponse d'ACK au871. Aucun processus
actif ; dernier message recu871, dernier envoi872. H-MATCH reste ouvert.

870 lu/acquitte. LAB a fourni near53/n_45 (nu14 annoncee numeriquement)
et dump_obj53/b_29 (nu15 annoncee). Aucun contre-exemple obtenu.
Les944 remariages nouveaux de n_45 ont TOUS rangT>=31 mod101. Pour b_29 :
921 rang>=31,4 T nonPSD exact,19 U nonPSD exact. Le M d'origine est saute.
OBSTRUCTION PLUS FORTE : chacun des DEUX Gamma a un temoin entier w
tel que w^t(4I+Gamma)w<0. Comme L(M)>=0, U(M)<=4I+Gamma : AUCUN couplage
M, ni reecriture des etiquettes, ne peut reparer U a Gamma fixe.
n_45 : hauteur16,||w||^2=3496,energie=-20. b_29 : hauteur6,||w||^2=768,
Bw=0,energie=-96, donc quotient de Rayleigh Gamma=-33/8.
Pour b_29 on a aussi Bq=Bz=0, z=(4I+Gamma)q, q.z=0,||z||^2=48,
z^t(4I+Gamma)z=192 ; w=3q-z donne-96. Temoin de fuite au bord impair,
pas un nouveau controle de la PSD/rang T du pair. Script
hmatch_mate_invariant_obstruction.py et rapports hmatch_mate_obstruction_*.
Cette preuve ferme les familles a Gamma fixe, PAS H-MATCH general.

16/10, messages865-867 lus/acquittes. LAB propose maintenant une seule
cible : H-MATCH (C1/C1'/C2, T/U PSD, nu>=14 => matchings h-relies),
avec preuve ecrite ou contre-exemple exact. Sa consigne horaire et son
intention de clore a08:00 sont un RELAIS du pair, pas une nouvelle
instruction directe de Dilan. Travail dans le perimetre deja autorise.
LAB prend les nouvelles classes de noyau ; Codex cherche analytiquement
et par constructions orthogonales/remariage, sans refaire ses audits.
PAS de resultat H-MATCH obtenu. Trois outils ne sont que des tentatives :
hmatch_cycle_reflections.py, hmatch_partial_star_reflections.py et
hmatch_broken_mate_family.py. Les deux premieres ne donnent aucun bloc
casse de nu>=14 sur les germes testes. Sur le HB_1 casse nu13 du pair,
les944 NOUVEAUX couplages exterieurs sont ecartes exactement :210 C1',
734 rangT>=31 modulo101. Le couplage original n'a pas ete re-audite.
868 demande au pair UN export obj53 casse T PSD nu>=14 dont le bloc
impair C' est PSD (invariant sous remariage). Reponse encore attendue.
869 signale une normalisation necessaire dans867 : hors etoiles,
A+A'=7Pi_+ et non7I dans les coordonnees brutes. Pour q=sum_c(e_cy-e_c,y^1),
Pi q=2q/3. La formule Phi devient correcte apres blanchiment par Pi_+,
mais ||B_mix||F^2=b/2 n'est alors plus une norme non ponderee. Ne pas
supposer nu(C)=2 hors de l'echantillon de structures cassees de LAB.

Extension support14 sauvegardee au commit de7eb67, transmise par863.
Bundle codex_flat_c4do_20261015 complete. Aucun processus actif. D7 a
deja utilise le seuil entier9-max c ; pas de correction d'arrondi.
Suggestion analytique transmise : dim intersection<=tr((P_L P_M P_L)^k),
k>=1. Pas de borne universelle ou de calcul d'echantillon nouveau.

862 lu/acquitte : LAB ajoute R7 sous SYM (gain de quotients suffisant),
D7 (borne des projecteurs insuffisante dans11/109 cas) et D8 (trou impair
3,1e-6 mais determinant81 non nul). Resultats acceptes sans re-audit ;
LAB prend QUOT via comptes V4/G21. Aucun de ces constats ne prouve SYM.
NOUVEAU suite862 : la preuve plate est etendue au support<=14, avec la
conclusion PLUS FORTE q|O=0. Pour7 sommets par signe, les caps C2 et degre
minimum3 forcent l'unique H7 : va,vb,vc,vd,ab,cd,ea,ec,fb,fd,ef. Les deux
centres de degre4 sont relies entre signes. Les paires pouvant partager
une racine forment K3,3 moins2 aretes sur les6 autres, et isolent v.
Chaque racine se repete au plus2 fois ; une racine centrale de v reste
singleton. Le compte d'incidence7+o<=1+2+2+2 force o=0. Pour6 sommets,
toucher O aurait force la violation C4DO deja exclue. Donc toute relation
plate dans kerT, Bq=0, qui touche O a support>=16, meme si elle satisfait
C4DO. Code four_star_flat_support_fourteen.py, certificat
flat_kernel_support_fourteen.json, calcul entier0,16s. Pas de graphe du
pair relu. Ni C4DO generale, ni SYM, ni NG5/NG7 demontrees.

860 lu/acquitte apres l'envoi861 : preuve finale C4DO plate transmise,
commits216746a et d6dcaad, bundle lab_exchange/codex_flat_c4do_20261015.
LAB propose SYM (kerT invariant par les deux echanges de lettres) + QUOT
(borne du noyau du quotient21). Observes sur109 non-grille PSD, pas prouves.
Ses reductions conditionnelles sont acceptees sans re-audit. Ne pas
extrapoler notre preuve plate a SYM ni a QUOT ; aucune reponse d'ACK.

858 lu/acquitte. LAB : ODDCONST/EVEN'/C4DO observees, pas prouvees ;
secteur h-impair=extremite spectrale3. Codex a obtenu une PREUVE RESTREINTE
de C4DO : sous binaire,C1,C2,T/U PSD, tout q dans kerT, Bq=0, coefficients
0,+1,-1, support<=12, satisfait q02-q03-q12+q13=0. Pas une preuve generale.
La tentative de violation force deux prismes anticomplets6+6, +02,-03,
profil de lettres(1,2,2,2) central et5 lettres exterieures distinctes.
Il y a52 supports couvrants,16 orientations chacun ; leurs832 coeurs12
ont TOUS T PSD rang11 et U PD rang12, mais AUCUN ne se prolonge en44 avec
cette relation. T PSD propage AUTOMATIQUEMENT le noyau principal au noyau
global : ces832 coeurs sont donc des sous-graphes induits INTERDITS, sans
hypothese supplementaire de noyau prescrit. Enumeration propre exacte1,4s.
PREUVE D'EXTENSION : p=0,1,2 paires mates parmi5 lettres. Pour v=1_prisme+,
d=v^t(8T)v=6-2p, w=8Tv. Cauchy sur12/13 impose zero voisin dans les
prismes (121>20d). C1 force6,3,2,2 incidences exterieures ; d'ou
||w||^2>=384,304,304. T+U=7Pi<=7I =>||w||^2<=56d=336,224,112.
Contradictions strictes48,80,192. Ni h,nu14,F7 ni C1-prime necessaires.
Scripts four_star_flat_c4do_obstruction.py (preuve),
four_star_flat_kernel_prism_cores.py (classification), rapports homonymes
flat_c4do_obstruction.json / flat_kernel_prism_cores.json. Trois pilotes
40s UNKNOWN historiques sont maintenant resolus ANALYTIQUEMENT pour
cette famille ; ne pas les relancer. Le pilote four_star_doubly_odd_kernel.py
applique desormais l'exclusion par defaut. 859 avait transmis la reduction
avant cette preuve finale. Aucun processus actif. NG5/NG7 restent ouverts.

855 lu/acquitte apres l'envoi856 (theoreme de cloture, commit ced8534).
LAB propose l'attaque h-invariante de NG5 ; Codex prend le cas general
et le rang de Schur, partage transmis857. Ce message du pair reste une
contribution dans la recherche autorisee. Aucun gain9 suppose prouve.
Pour X_l24 et Y20, rangS=21+c_l-nu : pour exclure nu>=14 quand
c_l=1,2,3,4, les bornes suffisantes sont respectivement9,10,11,12.
La borne uniforme12 est plus forte (N9-NG). Garder les18 motifs O
non-grille, pas seulement e(O)=0. AUCUNE PREUVE NG5 obtenue.
Essai moments CORRIGE suite858 : tr(T8)=880 et
tr(T8^2)=32384+64e(O)+48a+16b,
a=tr(Gamma D^tD),b=tr(Gamma D^t M_ext D), a,b<=40 par C1-prime.
Hors-grille e(O)<=3, donc rangT>=23 seulement : insuffisant pour31.
Ancienne formule corrigee : deg_F interne=6-2deg_O, mais deg_Gamma=6-deg_O.
D designe l'incidence des10 lettres exterieures. Aucun run actif.

854 lu/acquitte. LAB poursuit les profils et les marches non-grille ;
observations acceptees, pas de re-audit. NOUVEAU THEOREME : cloture des
relations de noyau retenues par les composantes des reseaux deux-etoiles.
Pour W retenu et K indicatrices des anciennes composantes, H={a:Ka dans W}.
Deux composantes de signatures distinctes dans H ne peuvent etre reliees
dans la cible. Les unions de meme signature donnent de nouvelles relations
globales sous T PSD ; iterer sur les deux cotes. Une ancienne grille isolee
de signature unique persiste sous C1/C1-prime et donne2 prismes.
CAS UN RETRAIT : W hyperplan de N0, contenant les4 etoiles forcees.
La restriction alpha de la fonctionnelle retiree aux indicatrices d'un
cote doit etre0 ou proportionnelle a e_i-e_j. Sinon la cloture retablit
TOUT N0 : retrait inutile, independamment des graphes cibles. En c55,
10 choix de paire par cote :4 actif/grille,6 grille/grille. Ce ne sont
PAS tous les hyperplans globaux (coefficients mixtes/couplage libres).
Outil four_star_kernel_partition_closure.py : close_retained_kernel et
release_component_merge. Six sous-espaces abstraits propres testes, PAS
des graphes ; rapport kernel_partition_closure.json. Aucun export du pair
recalcule. O grille reste force si on conserve1_O ; interpolation PSD
depuis une grille nu14 vers un non-grille perd au moins1 nullite dans
l'interieur du segment. Aucun interdit pour les autres chemins/discrets.
NG7/N9-NG/NG5 restent ouverts, aucune nouvelle construction SRG.

849/850/852 lus/acquittes ; resultats transmis851,complement853. LAB852
corrige aussi le 'jamais' et vise maintenant NG7. Son meilleur non-grille
avec min t<=7 reste nu13,t=(6,8) ; parmi742 objets de cette classe de
noyau,nu14 apparait seulement a t=(8,8), selon ses calculs acceptes.
Pas de reponse d'accuse au852. Pas d'audit des
germes LAB. Correction explicite au debut de note100 : son profil P=0
satisfait les consequences SCALAIRES affichees, pas un modele simultane
des lemmes structurels, de leurs preuves ou des blocs44. Ne pas conclure
qu'aucune combinaison future ne pourrait exclure Conway.
NOUVEAU : P=0 survit a l'INTEGRALITE du census fourni7/8/9. Un point a57
parametres entiers donne6435 comptes entiers non negatifs, rho=0 ; sommes
C(99,n). Recherche propre CP-SAT1worker7s, puis evaluation exacte de
toutes les expressions. Source acceptee sans regeneration. Ni graphe,
ni compatibilite des PSD/rangs/extension affirmee. Script
conway_integer_census_zero.py, rapport integer_census_prism_zero.json.
NOUVEAU THEOREME : P<=852 => au moins18 droites t<=7 et au moins254
blocs NON-GRILLE contenant une telle droite. Pour m droites basses,
I>=max(9m,6m+216) incidences non-grille ; spectre du graphe des droites
18,7,0,-3 => e<=floor(7m/2+m²/42) ; N>=max(ceil(I/2),I-e)>=254.
Script conway_forced_low_prism_blocks.py, rapport forced_low_prism_blocks.json.
Cible SUFFISANTE plus etroite (NG7), OUVERTE : aucun bloc non-grille
avec min(t_l,t_m)<=7 ne passe les conditions necessaires de Conway.
850 : LAB propose N9-NG (nu<=9+min c hors-grille) / NG5 (nu>=14 =>min c>=5).
Son inegalite acceptee c<=g+floor((6-g)/2), avec g<=t/2, donne t<=7=>c<=4.
Donc NG5 implique NG7 ; il suffit meme d'exclure cette intersection.
LAB recherche les non-grilles ; ne pas dupliquer ses marches. Ses97
objets non-grille satisfont N9-NG, mais c'est un echantillon. Quatre des6
PSD de sa nouvelle classe de noyau c55 ne sont pas G1 et echouent F7/DISC
selon ses certificats ; ne pas leur appliquer notre seule preuve G1.
L16 est DEJA sans hypothese Hamming ; L8 requiert les bijections absentes
en torsion generique, L10 requiert la capacite1 vers les grilles completes.
Conjecture(P) toujours ouverte ; ODD9 refutee. Aucun processus actif.

847 lu/acquitte apres le848 sortant (famille120,commit48914cb). LAB donne
deux exemples exacts nu13,(a,b,s)=(9,2,2),gains9/9 : sum_hb1_SUM_1 c42
et oddw_o9b_HB_1 c22. Notre formule donne eta_l=eta_m=0 malgre s2.
Donc ODD9 ponctuelle n'implique PAS N h-invariant. Ces exemples sont
acceptes sans re-audit. Le second descend du contre-exemple nu14 ; les
dimensions passent de(11,3,0) a(9,2,2), pas une preuve de loi generale.
Aucune reponse d'ACK au pair ni nouvelle lecture de graphes requise.

845 lu/acquitte, relations du pair recues depuis Downloads/.../for_codex/
odd9_counterexamples_2026-10-15.json ; copie conservee lab843_odd9_counterexamples.json.
NOUVEAU : les deux hv_h_c22_H30_23 et _10 sont LE MEME Gamma local a
permutation exterieure pres, mais cette permutation ne preserve pas M.
Relation impaire normalisee : hauteur24,16 coefficients exterieurs pairs,
24 impairs,aucun nul, O=0 ; voila comment elle evite la parite plate.
NOUVELLE FAMILLE FINIE EXACTE : Gamma du _23 fixe,945 choix possibles de
M exterieur,750 C1' compatibles,120 T/U PSD. Tous nu14, rangs pairs(11,20),
gain impair8/8 herite. Ni classes d'isomorphisme ni SRG complets nouveaux.
EXPLICATION : P={4,7,8,11,12},Q={5,6,9,10,13}. q(c,y)=+1 surP,-1 surQ,
q|O=0, Gamma*q=2q. q^t*T(M)*q=-8*r, r=nombre de paires internes a P/Q.
T PSD force M entre P et Q ; les5!=120 choix restants sont tous PSD,
elimination entiere exacte sur les nouveaux blocs pairs seulement (~0,55s).
Blocs impairs/C1/C2 du producteur herites sans re-audit. Profil c :
22:16,23/32:20chacun,24/42:10chacun,25/52:2chacun,33:24,34/43:8chacun.
O grille isolee implique ici min c>=2 AUTOMATIQUEMENT : ce remariage ne
prouve PAS B' hors-grille. Script odd9_endpoint_mate_family.py + rapports
odd9_endpoint_mate_family.json et odd9_counterexample_coefficients.json.
Ce q h-pair a incidence exterieure non nulle : ne pas le confondre avec
les q equilibres de la coupe48. La relation h-impaire a incidence nulle.

CORRECTION MAJEURE843 : ODD9 UNIVERSELLE REFUTEE, MEME A NU14,c22,h.
Cela remplace toutes les mentions historiques 'ODD9 ouverte' ci-dessous.
LAB a58 exemples h-invariants nu14, gains8/8, neuf types(c_l,c_m), et
un exemple nu9,c22,gains5/5. C1/C1'/C2 et T/U PSD certifies exactement
par le producteur ; acceptes SANS re-audit. hv_h_c22_H30_23 est le temoin
c22. SUM14 universelle aussi refutee : nu13,s2,dim(N+hN)=15. La version
nu14 reste ouverte. B' reste ouverte ; ne pas recycler ODD9=>B'.
NON TOUCHES : coupe binaire48, reduction de Schur et diagnostic rho,
exclusion propre <Z5,hM> par cyclotomie/F7. Ses192 PSD ont9/9 selon LAB.
NOUVEAU MECANISME EXACT : a=dim(N inter V+),b=dim(N inter V-),s=nu-a-b.
Defaut d_l=9-gain_impair_l=b-2+eta_l, avec0<=eta_l<=s,
 eta_l=nu-rho_l-b-c_l. Le vieux noyau24 a parites(c_l,1) : composantes
du reseau toutes h-paires, difference d'etoiles h-impaire. Si N est
h-invariant, eta=0, gains11-b des deux cotes ; pas besoin d'ODD9.
Sur V- orthogonal aux2 differences forcees, T-=3I-Gamma-,U-=4I+Gamma-.
Donc b-2=multiplicite de3 dans le quotient comprime Gamma-. PSD autorise
l'extremite3, ne force PAS la stricte inegalite. Sous vraie symetrie h,
Gamma- est un quotient signe ENTIER22, avec2 directions forcees retirees.
Budget sans symetrie : gain_pair_residuel_l=12+c_l-nu+d_l. Si une borne
independante e_l>=k existe, nu<=12+c_l+d_l-k ; ne pas effacer d_l.
Pour les58 h,nu14,gain8 : (a,b)=(11,3), e_l=c_l-1,e_m=c_m-1. La borne
min c>=2 devient e_l,e_m>=1 dans CETTE classe ; ce n'est pas une preuve.
Parite renforcee : normaliser une relation pure h-impaire en retirant
les2 etoiles forcees annule toute incidence. Une relation entiere ainsi
normalisee ne peut avoir TOUS les40 coefficients exterieurs impairs,
meme si O non nul : C1 donne e(O,F)<=16, donc>=24 sommets sans voisin O.
Module odd9_defect_decomposition.py, identites geometriques exactes et
fixture abstraite eta_l=1,eta_m=0 (PAS un graphe), environ1,2s.
Message844 : demande au pair UNE relation supplementaire certifiee et
labels du contre-exemple, pour etudier ses coefficients sans refaire
les rangs. Fichiers hv_h_* non presents ici au moment du843. Aucun calcul
de campagne actif. Le nouveau module normalise les vecteurs fournis.

841 lu/acquitte. KER-SYM UNIVERSELLE REFUTEE par LAB :46 premieres PSD
de nullite9 dans <Z5,tau>,tau=(02)(13), aucun noyau invariant sous les
9496 h*p. Resultat accepte sans audit ; une version restreinte a nu>=14
n'est pas refutee par ces nu9. LAB poursuit sa campagne, ne pas dupliquer.
NOUVEAU PROFILAGE, pas une verification des graphes : toutes les coupes
equilibrees ont586278 directions q~-q. Demi-patterns de5 lettres, comptes
par etoile complementaires ; Numpy int64, environ0,03s/objet apres cache.
Nombre par a=n01=n23 :31752,220500,252000,75600,6300,126. a=0 est h-impair.
Exports locaux, hypotheses du producteur acceptees : rank30_urep100 max46,
null13 max46, asym_c31 max45, grille_Z5h_c22 max43. Aucune saturation48.
Ce sont4 exports seulement, PAS les331 objets de rang30. Dans les trois
premiers, le maximum survient a a=5 (direction h-paire), contre maxima
h-impairs43,44,44. Notre modele fractionnaire atteint49, comme prevu ;
notre fixture binaire nonPSD atteint49 avec1 direction violee.
Module odd9_balanced_cut_profile.py et rapport odd9_balanced_cut_profiles.json.
API profile(G,labels,scale=1), from_export(data) ; ni rang ni PSD ni Aut
recalcules. Coupes48 prouvees, serrage48 NON etabli. ODD9 refutee en843.

839 lu/acquitte. LAB integre le diagnostic de projection du noyau ;
KER-SYM tient sur342 structures de ses campagnes, pas de preuve generale.
LAB enumere <Z5,tau>,tau=(02)(13),5 cubes, sans element de type h.
Ne pas dupliquer. La seule dimension ne force pas KER-SYM : avec les4
etoiles forcees, codimension des noyaux invariants>=150 a nullite14.
Ce calcul abstrait ne refute pas la conjecture pour les graphes.
836/837 lus/acquittes. Repartition relayee : LAB A(mecanisme sans
symetrie)+B(construction), Codex C=ODD9 ; extension-d'abord D mise de cote.
NOUVEAU THEOREME SANS SYMETRIE : pour S20 exterieur,5 sommets par etoile
centrale et2 par lettre exterieure, q=+1 surS,-1 surF-S,0 surO. Kq=0.
C1 donne deg_F(x)=6-2deg_O(x) PAIR pour tout x exterieur, meme hors grille.
Donc, pour Gamma binaire, Tq=0 serait impossible (Gamma q pair,3q impair).
L'identite C1 q^tTq=8*(49-e(O union S)) et T PSD donnent la coupe STRICTE
 e(O union S)<=48, au lieu49. Hypotheses : C1,binaire,T PSD SEULEMENT.
Ni U,C2,h*p ni O grille. Si O grille, specialisation e(S)<=44 au lieu45.
31752 directions h-impaires indexees apres identification q~-q. A l'egalite
interdite49, v=5q-2s_i e_i avec s_i=(Tq)_i impair donne v^t(8T)v=-80s_i^2.
Fixture C1 binaire propre a49, certificat -2000, et identites hors-grille.
Autre resultat : modele FRACTIONNAIRE C1/C1',boite[0,1],T/U PSD exactes,
matchings internes moyenne explicite225 matchings, MAIS gain impair8 et
C2 viole. Il montre les limites des relaxations, PAS un contre-exemple
binaire ODD9. Module odd9_necessity_models.py, reproduction~1,1s.
Diagnostic depuis noyau COMPLET fourni N : rho=rang(n_2y+n_3y), gain impair
=11+c_l-nu+rho ; defautODD9=nu-c_l-2-rho. Consomme N sans re-audit.
ODD9 reste OUVERTE : des relations non plates et d'autres parites ne sont
pas exclues par les coupes. Message d'etape838 envoye. Aucun processus actif.
837 : KER-SYM est une CONJECTURE empirique de LAB, lignages biaises ;
asy11 N invariant sous fausse h(46), profil(9,2). Ne pas confondre symetrie
du noyau et de Gamma. 'Une seule saturation' REFUTE :128 PSD c22 ont4
saturations par rapport a h. Tests a froid LAB en cours, ne pas dupliquer.

834 lu/acquitte apres le835 sortant : profils LAB maintenant192/192.
Les12 manquants sont tous null9,c22,t22,5 relations de cote+4 mixtes
PAIRES. Total128 de ce type,32 null5,c22,16+16 null9,c26/c62. H_hM tient
des deux cotes sur192 ; plafond via6h reste conditionnel a ODD9.
Marche HB_1 :15777 visites PSD,max sans h*p11 ; c22 :3774 visites,
aucune sans h*p dans ce run. Aucun calcul relance ici. Nouvelle deduction
sans symetrie livree dans835, commit7b89328 ; ne pas repondre par simple ACK.

Suite833 : LAB confirme ODD9 conditionnel et180/192 profils ; relance
cube0 pour les12 manquants. Marche HB_1 :8884 visites PSD, meilleur
sans h*p null11,c32,t=(7,10). Graine c22 :2019 visites, aucune nouvelle
PSD sans h*p dans CE run. Aucun audit des visites par Codex.
NOUVEAU axe SANS SYMETRIE : delta=nullT_O vaut1 seulement si O est C4,
sinon0. Relations de cote=c_l+c_m+2-delta. Eliminer O et choisir les
supports positifs des deux cotes donne R=A-E*C^-1*E^t, dimension
19-c_l+delta, nullR=relations mixtes. RangR=21+c_m-nullT ; cible14
equivaut rangR<=7+c_m, SANS ODD9. Pour c32,null11 : R16/17 de rang12,
cible<=9 ; il manque3 relations mixtes a c fixes. Delta du seed inconnu.
Autre deduction : en fixant les deux cotes et T-kernel N, les variations
croisees satisfont Delta*N_R=0, Delta^t*N_L=0 ; Delta=P_L*Z*P_R^t,
tailles des facteurs21+c_m-nu,21+c_l-nu. A c32,nu11 :12*13=156
dimensions REELLES, pas des mouvements binaires valides. C1 central
est automatiquement conserve. C1',C2,boite binaire,U restent a imposer.
Chaque espace propre de h*p sur un cote20 a dimension<=10. Si un facteur
depasse10, ces seules equations ne peuvent forcer AUCUN h*p fixe ; une
union finie de leurs sous-espaces fixes ne couvre pas l'espace reel.
Donc tant que nu<11+max(c_l,c_m), le noyau seul ne force pas h*p.
Pour c32, seuil14 : a14, cet obstacle dimensionnel DISPARAIT, sans preuve
que h*p soit force. Module asymmetric_mixed_residual.py ;6 fixtures
Gram abstraites +19 motifs O de C1,1,0s. Aucun SRG construit par ce lemme.

Suite831 : profils LAB de180/192 PSD <z,hM> :116 null9,c22,4 relations
mixtes PAIRES ;32 null5,c22 ;16+16 null9,c26/c62 sans relations mixtes.
Aucun(3,6) parmi ces180,12 restent a profiler. H_hM observe sur les180.
Son plafond via gain pair utilise ENCORE ODD9 ; ne pas effacer cette
condition. Nouveau front LAB : structures LOCALES44 sans symetrie h*p,
null10,c22,t=(6,10) et null11,c32,t=(7,10). L'absence de h*p ne signifie
ni groupe complet trivial ni construction d'un SRG asymetrique.
NOUVEAU Codex : filtre ramifie Z[zeta5]/5=F5[e]/e^4. Le determinant
hermitien a coefficients(c0,0,c2,-c2). Pour les5 types nu0=5 restants,
une congruence QUADRATIQUE explicite sur les moments des decalages
determine c2 ; c2!=0 exclut les4 relations impaires et donne plafond9.
En D/D,nu0=6 : det4T- a c2=p^2, det2T+ a c2=4L^2 ; p et L non nuls
imposent nullite6. Null14 necessite p=L=0. Zero residue reste INCONCLUSIF.
Module portable z5_hm_ramified_filter.py,112 fixtures de coefficients
synthetiques,0,2s ; aucun graphe LAB lu, pas de campagne dupliquee.
Le plafond9 pour tous les candidats restants n'est toujours PAS prouve
par cet argument. Il explique une contrainte d'arithmetique des phases,
pas une impossibilite generale de l'asymetrie ou de C1.

Suite828 : lemme LAB pour g=h*p : sous(H_g), les differences g_y-g_p(y)
imposent gain pair>=k (nombre de transpositions exterieures). La formule
de nullite donnee par Claude utilise EN PLUS ODD9, encore une condition.
NOUVELLE PRECISION Codex : z seul impose c_l,c_m dans{2,6} (O isole et
partition des cinq paires exterieures invariante sous C5). Avec exclusion
damier de(6,6), min c=2 est PROUVE pour toute la famille <z,hM> PSD.
NOUVEAU FILTRE MOD5 : pour N=4T_- cyclotomique, representants de Laurent
evalues en1, detN(1)=576*d, d=(7-2e)(7-2f)-(2(t+w)+1)^2. e,f=+1 pour
R=D_s,-1 pour R=M ; R est le matching ENTRE etoiles conjuguees, pas M0.
Phi5(1)=5 => reduction Z[zeta5]->F5. d non nul mod5 force b=0. Sept des
14 QUADRUPLETS de quotient sont ainsi couverts : nu0=5, a<=1 deja prouve,
donc plafond LOCAL9 sans ODD9 ni borne globale F7. Ne pas interpreter
7/14 comme une proportion de graphes. Aucun converse si d=0.
Profil(3,6) a nullite9 possible seulement dans5 quadruplets : e,f mixtes,
(t,w)=(2,0) ou(0,2), OU e=f=-1,t=w=0. Necessite R=M d'au moins un cote.
Les deux autres quadruplets ont nu0=6, donc ne peuvent avoir nullite9.
Module z5_hm_rank_obstruction.py --parity-only, standardlib,0,37s ; rapport
z5_hm_mixed_parity.json. 828 lu/acquitte, deductions envoyees829. Claude
collecte les profils sur ses PSD ; ne pas relancer ses calculs.

Suite826 : campagne LAB <z,hM> COMPLETE,25 cubes termines UNSAT,339556
structures admissibles,192 PSD, nullite maximale9, aucune>=10. Verdict
SAT complet SANS certificat exporte, accepte sans audit. CORRECTION
IMPORTANTE : l'absence de relations mixtes est FAUSSE. Les c=(2,2) de
nullite9 ont5 relations de cote et4 mixtes ; c=(6,2)/(2,6) ont9 de cote.
Ne plus propager l'interpretation du message819. Claude renonce au
relecteur dedie conformement a la consigne de Dilan.
DEDUCTION Codex : a nullite9, nu0=5 et a+b=1. Sous g=hM, les5 noyaux
triviaux (4 etoiles+indicatriceO) se repartissent3 pairs,2 impairs.
Les quatre autres relations constituent un module irreductible Q(zeta5)
et sont toutes de MEME parite g. Donc (null_g+,null_g-)=(7,2) ou(3,6).
Pour c=(2,2), c'est exactement la parite des4 relations mixtes ; pour
c=(6,2)/(2,6), les quatre relations de grille sont g-paires : (7,2).
Diagnostic structurel nouveau, aucune matrice sauvegardee du pair relue.

Suite818/819/821 : NOUVELLE EXCLUSION de toute la famille LOCALE <z,hM>,
z=(4 6 8 10 12)(5 7 9 11 13), h=(01)(23), M=(45)...(12 13).
Aucune extension du groupe au graphe99 supposee. Sous C1/C1'/C2 et T/U PSD,
null_Q T<=14 ; si nullite14, rang_F7(8T)>=29. Les bornes GLOBALES deja
etablies rang_Q<=30 et rang_F7<=28 excluent toute completion Conway.
Le plafond LOCAL9 est maintenant annonce complet par LAB826 ; sa preuve
structurelle reste a trouver. L'absence de relations mixtes est REFUTEE.
Ne pas presenter ce resultat comme exclusion de tout C1.
Preuve portable code/codex/z5_hm_rank_obstruction.py, bibliotheque standard,
certificats data/codex_local_global_20261015/z5_hm_negative_certificates.json.
Execution4,6s : secteur+128 colonnes par cote,304 blocs de rang2,3152
relevements,520 admissibles ; tous refutes par vecteurs ENTIERS (416U,104T).
Secteur-32 colonnes par cote,0 bloc de rang2. Donc chaque nullite sur
Q(zeta5) <=1. Quotient z-trivial :14 cas T/U PSD, nullite5 ou6 ; seulement
deux cas de nullite6, equivalents par(23), matchings D/D, comptes B diag2
et C tous1. Son rangF7 vaut5. Phi5 irreductible mod7 : les autres rangs
sont4 fois les rangs des blocs4x4 sur F_(7^4). Secteur+ :88 colonnes/cote,
0 bloc rang<=2. Secteur- :212/cote,16 blocs,8 relevements binaires ; tous
violent C1' (3 voisins contre plafond2). Donc rangF7>=5+12+12=29.
Cas deux diagonales+ singulieres exclu ANALYTIQUEMENT sous hM seul :
c_l=c_m=6 donne sur les modes damier U=[[2I5,B],[B^t,2I5]], B diagonale0,
hors diagonale+-1. PSD=>BB^t=4I ; deux lignes ont3 positions communes,
produit scalaire impair, contradiction. Une diagonale singuliere seule
se traite par echange des droites. Calculs nouveaux sur petits mineurs,
aucun graphe/producteur re-audite ni enumeration du groupe dupliquee.
Claude821 :9/25 cubes generaux finis,130856 structures,80 PSD max9 ;
FORCE_TM complet26340/16PSD max9 ; FORCE_TL+TM en cours. Accepte sans audit.
823 lu/acquitte : Claude17/25 cubes finis,max9 ; t=(12,12) complet4788,
0PSD. Il envisage une relecture independante : rappeler la consigne de
Dilan, deux chercheurs et pas un verificateur. Aucun agent a lancer ici.
Suite823 : certificats enrichis des520 graphes explicites (lignes hexa),
tau=(02)(13) et les blocs B^*,(MCM)^* detailles dans la preuve. Reproduction
complete environ5s. Resultats820/822, exports et commande transmis824.

Suite815/816 : Claude garde un MILP sans verdict, meme le temoin G1
n'a pas encore trouve de PSD. C2 desormais linearise exactement avec
10668 auxiliaires CONTINUS y. NOUVELLE PROJECTION Codex : pour la paire
i,j, s lettres communes, e=x_ij, L_t=x_it+x_jt,
 e+sum max(0,L_t-1)<=2-s,
equivalente aux y>=0,y>=L-1,sum y<=2-s-e, aussi aux points fractionnaires.
Pour tout W : e+sum_W L_t<=2-s+|W| ; separateur complet en prenant L_t>1.
Termes repetes groupes avec multiplicites. c2_projected_cuts.py exporte
des lignes entieres et leur derivation :1 fois la somme C2, plus les
bornes inferieures selectionnees, plus la nonnegativite des autres y.
Peut supprimer les10668 colonnes ; aucune acceleration/iteration bornee
prouvee. models_from_edge_orbits respecte les indices du producteur,
separate_all traite un point exact, subset_cut accepte tout sous-ensemble.
Certificats mixtes : mixed_binary_tree_certificate ne branche QUE les
indices binaires declares ; les y restent continus dans Farkas. Lignes
creuses supportees pour ne pas remplir de matrices10922 colonnes.
486 controles fractionnaires,72 petits cas binaires propres ; certificat
mixte x binaire,y continu et branchement continu rejete. Aucun calcul
du pair relance. Decoupage23004 cubes envisage par Claude, cout non prouve.

Suite812/813 : Claude a integre nos coupes G1'' mais les cubes restent
grands et incomplets ; il passe a un MILP HiGHS sur254 orbites, C1/C1',
C2 paresseux et coupes PSD numeriques, avec G1 temoin. Ne pas le doubler.
NOUVEAU module psd_exact_cuts.py : pour M(x)=C+sum x_j B_j et tout q
rationnel, la coupe -sum(q^t B_j q)x_j<=q^t Cq est exacte ; lignes
entieres primitives, separation par elimination rationnelle (y compris
pivot diagonal nul), aucune troncature des petits nombres negatifs.
g1_twist_square.lift_schur_direction releve un q10 en w44 rationnel :
w^t M w=4 q^t M_reduit q sur l'interface normalisee. La coupe w^t M w>=0
est ensuite valide dans l'espace original ; adjacency_psd_cut la traduit
directement dans les orbites d'aretes, sans254 matrices44x44.
Farkas unique seulement si la RELAXATION LINEAIRE exacte est infaisable.
Si seule l'integralite echoue : arbre couvrant0/1 et Farkas par feuille,
ou autre preuve pseudo-booleenne. Le module consomme un tel certificat ;
il ne l'extrait PAS d'un verdict HiGHS. Aucune borne abordable sur sa taille.
Rationaliser a posteriori ne suffit pas : prouver le systeme exact obtenu.
Exemples propres, dont2x=1 binaire (LP faisable, deux feuilles certifiees),
quatre entrees invalides rejetees, huit identites de relevement exactes.
Aucun candidat ni calcul du pair re-audite ; pas de nouvelle exclusion.

Suite809/811 : NOUVELLE EXCLUSION DANS G1''. Pour P=6/7,8/9,10/11,12/13,
le degre interne d_P de R_P={2y,2y^1,3y,3y^1} satisfait d_P<=1. Preuve :
mineur T sur q_F et1_RP normalises, diagonales5,2-d_P, couplage+-1 ;
5(2-d_P)>=1 puis integralite. Donc m ne forme aucune grille avec ces
quatre paires. Sans autre hypothese c_m<=4 ; si M2 ne contient pas45
(cas qui brise H-MATCH), g_m<=1 et c_m<=3. Les cubes brises c_m>=4
sont exclus sous T PSD, sans enumeration. Quatre coupes a trois termes
exportees dans square_template(...).internal_degree_cuts. Claude809
annonce26811 couples M0,M2 tous admissibles, mais quatre cubes sondes
incomplets et sans PSD ; son ordre3e8 n'est PAS un plancher prouve par
ce seul echantillon. Il raffine par les composantes et impose leurs
noyaux, avec notre normalisation. Ne pas doubler son enumeration.

Suite807 : campagne G1'' de Claude INCOMPLETE (26760 admissibles en600s,
aucun PSD), marches a froid inconclusives jusque dans G1 temoin. Accepte,
pas de doublement. Codex808 : NOUVELLE NORMALISATION SOUS T>=0.
Pour G1''=<a=(01)M,b=(23)M''>, F={04,05,14,15} est un C4 FORCE : b
fixe F, C1 force le matching entre ses deux lignes, C2 rejette le croise.
Son indicatrice kappa a normeT nulle, donc T*kappa=0. Chaque R2/3,y,
y=6..13, a exactement UN voisin dans F ; tous les autres labels hors F
en ont zero. Les quatre paires6/7,...,12/13 se partagent deux/deux entre
les orbites{04,15},{05,14}, avec deux orientations chacune :96 interfaces.
Le groupe C2 wr S4 des quatre paires agit transitivement : en fixer UNE
ne perd aucune structure PSD G1''. Ce n'est pas un facteur temps garanti.
Nouveau module autonome g1_twist_square.py, template20 aretes presentes,
146 absentes,8 absences de plus par C2. Les choix abstraits M2 brises
passent250->216 (tous M2:331->284), M0 reste81 ; pas de cube SAT enumere.
Eliminer F donne exactement quatre blocs10x10 pour T et quatre pour U,
au lieu des caracteres12,12,10,10. RangT=3+somme rangs reduits ; cible
rang30 => somme<=27. Borne GLOBALE additionnelle rangF7<=28 => somme<=25.
Offsets T de denominateur10 (inversible mod7). Les tests U restent requis.
Outil et artefact g1_twist_square.json ; aucun graphe du pair relu,
aucune nouvelle exclusion de G1'', H-MATCH ou C1.

Suite805 : HB_1 exactement invariant par g=h(4 6), hors cadre car p ne
preserve pas les mates ; resultat du pair accepte. Il teste G1'' contenant
la VRAIE symetrie h(4 5), sans h, et G1 a froid ; ne pas doubler ces marches.
Nouvelle reduction Codex pour TOUT g=h*p, p involution exterieure quelconque,
Gamma g-invariant. D=K-gKg=J4 tensor(M-pMp)/8 sur40 labels, zero sur O.
gTg=T+D ; gUg=U-(8/15)D. Si l'union des matchings a c composantes,
rangD=10-2c et rangE=5-c<=4 pour D_mixte=E. Donc T_mixte=-E/2,
U_mixte=4E/15. E=X Y^t : sous positivite des diagonales et portee, les
tests exacts sont4G_A^-1-G_C PSD et225/16 G_Aprime^-1-G_Cprime PSD,
taille<=4, G_A=X^t A^+ X, etc. NulliteT=nulliteT_moyen+nullite(residuT).
N=gN observe chez HB_1 signifie residuT STRICTEMENT positif, pas saturation.
Le defaut rang2 seul ne force pas le plafond13 : deux exemples algebriques
propres ont nulliteT14 et nulliteU4 avec ce meme rang/ratio des defauts,
sans etre des graphes. L'explication du plafond exige encore la structure
des blocs moyens / C1-C2. h_geometric_defect.py ;945 matchings geometriques
en7 types, rangs mixtes0..4 de comptes1,20,140,400,384 ; aucun graphe compte.

Suite803 : filtre volume INCONCLUSIF sur HB_1 (produits flottants0,0067,
0,0001,~0) ; ne pas le presenter comme exclusion du mur13. Resultats du
pair acceptes sans audit. Nouveau critere EXACT, derive de ses noyaux de
composantes h-pairs : entre W de H_l ne contenant pas m et Z de H_m ne
contenant pas l, chaque canal casse est une arete d'un multigraphe biparti.
Parallele={a,d}, croise={b,c} dans[[a,b],[c,d]] ; une cassure double donne
DEUX canaux. Les equations B^t*kappa_W=B^t*kappa_Z=0 ont des signes ssi
toutes les valences sont paires et chaque composante connexe contient un
nombre PAIR de canaux du type croise. Attention : croise ici n'est PAS
simplement 'entre L et R'. Construction par tour eulerien. Dimension
lineaire exacte E-V+c_bal, c_bal nombre de composantes dont CHAQUE cycle
a parite croisee paire. Solvabilite exige seulement la parite TOTALE par
composante : deux cycles impairs partageant un sommet peuvent cooperer.
Module h_component_circulation.py,32 petits multigraphes propres contre
comptage litteral. Aucun germe producteur lu, aucune famille C1 exclue.

Suite801 : faits du pair acceptes, aucune classe relancee. KHOMOG du germe
hm_id_c22_HB_1 :672 structures annoncees completes ; toutes les nullite14
(8 PSD,340 non PSD) h-reliees ; cassees seulement nullite12/13. Marches
sans h pres de c55 restent h-reliees ; Claude teste projwalk sans groupe.
Nouveau critere Codex sur une MOYENNE FIXEE : i=nulliteT0, T0=diag(A,C).
Pour T PSD, i=dim(kerT inter hkerT) et nulliteT-i est le nombre de valeurs
singulieres1 de K=A^-1/2 B C^-1/2. Shorter les blocs U sur les supports
positifs de A,C donne S,Q, supposes definis positifs sur ces supports.
Si nulliteT>=i+p, produit des p plus petites valeurs generalisees(A,S)
fois produit des p plus petites valeurs generalisees(C,Q) <=1.
Donc un produit>1 rejette cette perte de rang. p2 cible i12->nullite14,
pas les anciennes moyennes i14. h_nullity_volume.py certifie des bornes
rationnelles via inertie exacte de A-tS et C-tQ ; aucune moyenne du pair
testee. Exemple algebrique permet p1 mais exclut p2 ; pas un bord C1.
Si KHOMOG n'impose qu'une inclusion du noyau12, utiliser i ACTUEL.

Suite799 acceptee : Claude a termine140 classes newk2 (SAT, sans certificat
exporte) :404 structures PSD et14960 non PSD, toutes h-reliees ; aucune
cassee. Total287 classes de noyau annoncees completes. Seule obj53 contient
9408 structures cassees, aucune PSD. Pas de nouvelle moyenne a traiter.
Ses marches suivantes utilisent des groupes sans h. Ne pas relancer ni
re-auditer ces campagnes. La borne4096 envoyee dans800 est une reduction
theorique pour les moyennes du type concerne, pas une nouvelle exclusion.

Suite797 : NOUVELLE BORNE ABORDABLE PAR MOYENNE. Si les40 cassures sont
toutes simples, sans incidence avec O, avec un C10 dans L, un C10 dans R
et20 paires croisees, les seules quatre relations d'etoiles donnent au
plus13 signes libres : <=4096 essais modulo h pour CHAQUE moyenne de ce
type. Preuve : B a sommes de lignes/colonnes nulles dans chaque bloc ;
chaque C10 donne <=1 dimension, le support croise biparti D donne
20-|V(D)|+c(D), et ses degres doivent etre pairs. Alors |V|-c>=9.
Si les20 sommets croises ont degre2, la borne tombe a64 (<=5 cycles).
Fonction forty_simple_cycle_bound dans h_orientation_kernel.py.
Le support abstrait K4,6 prive d'un K2,2 atteint
la dimension13 et donne552 orientations modulo h sur4096 essais ; ce
n'est PAS un bord C1. Aucun des47 moyens du pair relu. Aucune borne sur
le NOMBRE de moyennes, aucune nouvelle exclusion de C1 ou de famille.

Suite794/795 : exports communiques avec chemins ABSOLUS dans
C:\Users\bfhdh\Desktop\Recherche_Conway\lab_exchange_2026-10-14.
Les commits restent locaux. h_mixed_energy.py est desormais importable
seul avec SymPy (seul report() depend du depot). Claude795 annonce que
les47 moyennes passent nos bornes : energie7,108<=10, capacite151,43>20 ;
la norme operateur1,495 detecte encore l'obstruction. Resultats acceptes,
pas de re-audit ni de nouvelle exclusion. Les classes deja enumerees ne
sont pas relancees. Nouveau module autonome h_orientation_kernel.py :
contraintes de noyau R*epsilon=0 sur la SOMME des canaux, reduction exacte
epsilon=L*z, propagation des relations de signes a deux termes, borne
par moyenne2^(d-1) essais modulo h. Aucun d effectif des47 moyens mesure ici.
Une coupe operateur rationnelle |2u^t Bv|<=u^t A'u+v^t C'v devient une
inegalite lineaire entiere en epsilon ; elle peut voir une direction
interdite meme quand le test Frobenius passe. Deux coupes rejettent une
fixture algebrique propre (pas un bord C1). Controles48 petits systemes
contre enumeration directe. Garde d'enumeration d<=14 par defaut.
Aucun processus actif ; ODD9, H-INV et C1 ouverts.

## Etat courant du14 octobre, messages741/743

Suite792 : cout EXACT des cassures de h. Delta=Gamma-HGammaH, b nombre
d'orbites d'aretes{e,h(e)} dont une seule arete est presente, q nombre de
paires d'orbites de SOMMETS cassees. Alors ||Delta||F^2=4b=8||B||F^2,
donc ||B||F^2=b/2 et q<=b<=2q. Sous T PSD et rangA10, rangB<=10 et
||B||op^2>=b/20>=q/20. Les40 cassures du pair impliquent au moins
||B||F^2=20 et ||B||op>=sqrt2, mais ne prouvent PAS tU<1.
Pour une moyenne fixee, b est fixe : changer les orientations ne reduit
pas la norme Frobenius. Deux nouveaux tests de moyenne : shorted upper
S=A'-A'N(N^t A'N)^+N^t A', N base kerA, puis b<=14trS (borne sure),
ou capacite spectrale sum eigS_i eigC'_i ; et energie d'orientation
epsilon^t H epsilon<=10, H_kl=tr(A'^+ B_k C'^+ B_l^t), sous les conditions
de portee/rang. H-diag(d) PSD, sum d>10 donne un certificat d'exclusion
de toutes orientations. Aucun de ces nouveaux tests applique aux47 moyennes.
Code h_mixed_energy.py, artefact h_mixed_energy.json. Controles propres
des16 blocs binaires,3 matrices arbitraires,shorting et16 signes ; aucun
germe/rang/PSD du pair relu. Pas de processus actif ; ODD9/H-INV/C1 ouverts.

Suite790 : reponse mathematique au pair sur la compression h-paire A22.
Sans supposer h automorphisme, Gamma_+=Q^t Gamma Q/2, K_+=Q^t K Q/2,
R=Gamma_++K_++J/2>=0 et A=3I-R+J/2. w=(2,2,1^20), v=(0,0,1^10,-1^10)
sont les somme/difference des deux etoiles paires, Aw=Av=0. Rw=3w+12*1.
D_w A D_w=L_R-L_K/2, conductances w_i*w_j*R_ij et w_i*w_j. Le reseau
fixe K_++J/2 est deja connexe (151 aretes), donc pas de lecture du rang
par ses composantes. RangA10 equivaut a multiplicite11 de12 dans4R,
matrice entiere NON NEGATIVE22x22 ; sous A PSD, une valeur propre>12 et
dix<12. Cela ne prouve pas nulliteT14=>rangA10 ni H-INV.
Au moins10 paires hors diagonale de A sont strictement POSITIVES :
une dans chaque ligne/colonne du bloc L-R, par les deux noyaux d'etoiles.
L'ajout canonique alpha*v*v^t cree aussi des entrees positives dans L
pour alpha>0 ; l'analogue direct du reseau a une droite n'est pas un
laplacien ordinaire. Ne pas generaliser cette obstruction a toute
representation possible. Code h_even_network.py, artefact h_even_network.json.
Controles de geometrie et une fixture rationnelle propre ; aucun germe du
pair lu, aucune certification du producteur refaite. Aucun processus actif.

Pont :787/788 lus et acquittes apres observation du trou de sequences lors
de l'envoi789 (resultats ci-dessous). Claude confirme T2/T3 et la distinction
des trois N9. Son observation120 structures non positives avec gain impair9
est acceptee comme observation, PAS comme preuve algebrique universelle.
Il etudie T3 via T=[[A,B],[B^t,C]] selon la parite h ; nulliteC=2 reste
conjecturale. Aucun besoin de refaire ses rangs. Pas de processus Codex actif.

15/10 matin, suiteT2 : reduction ODD9 sans groupe par reseau pondere.
8T_X=L8-u*u^t, L8=8(2I-Gamma_X)+3(I-F)+(I-M)+(I-FM), u=(1^12,-1^12).
F est le flip des lettres centrales, M celui des mates exterieurs ;
ce ne sont PAS des automorphismes supposes de Gamma. L8 est un laplacien,
L8u=24u, d'ou rangT_X=23-c. Pour les neuf combinaisons impaires de somme0,
Kf=0, sources q=Gamma_X,F P orthogonales a u et aux composantes.
Grounder une ligne/colonne par composante donne G inversible (taille24-c),
S9=d8-64*qg^t*G^-1*qg. Gain impair=rangS9. Sous T PSD, ODD9 equivaut
a det[[G,-8qg],[-8qg^t,d8]]>0 ; detG compte les arbres ponderes.
Code odd9_network_schur.py, artefact odd9_network_schur.json. ODD9 OUVERTE.
L'explication plus simple 'S10 est un laplacien a poids non negatifs' est
FAUSSE : nouvelle statistique sur le c11 certifie783,14 entrees hors diagonale
positives (maximum592/63 dans la normalisation8T). Aucun rang/PSD du pair
re-audite ; odd9_conductance_probe.py ne calcule que ces nouvelles entrees.

Suite785,15/10 matin : pont repris,782-785 lus/acquittes, reponse786.
Les nouveaux contre-exemples de Claude sont acceptes sans re-audit.
H-MATCH => point de Hamming est accepte ; H-MATCH et ODD9 restent OUVERTES.
Codex prend T2 (ODD9 par Schur / structure des couplages), Claude T3
(absorption / mur de nullite13). Ne pas refaire T1 ni les temoins du pair.
ATTENTION aux deux N9 : le theoreme GLOBAL LAB635 interdisant neuf sommets
avec17 aretes est distinct de la conjecture de nullite<=9+min(c), refutee.
Notre travail interrompu est conserve : general c55 NON GRILLE SANS G1,
128 coeurs etiquetes /18 types,19 permutations S4 restantes, quotient
equitable impose. Aucun automorphisme impose par ce quotient. Deux relations
d'etoiles reduisent le secteur standard33 a31 dimensions. Le vecteur propre
-4 de norme28 et l'histogramme exterieur(10,24,6) s'etendent sans G1.
La borne de29 profils brisant h reste G1 seulement. Adaptateur general
add_completion_counts dans four_star_c55_permutation_lift.py. La famille
generale reste ouverte ;18*24^19 n'est PAS une enumeration abordable prouvee.
Outils four_star_c55_general_overlap.py / four_star_c55_permutation_lift.py,
artefacts c55_general_overlap2/3.json, c55_permutation_lift.json.

Suite778,15/10 : nouveau budget GLOBAL sans G1 pour les relations mixtes.
Le certificat exact conserve P+5rho<=1386, avec P>=6rho, donne rho<=126.
Poser m_lm=nullite(T_S44)-(2+c_l+c_m-epsilon_lm), o_v nombre de degres
impairs du graphe des grilles, h_v=sum(3+floor(g_l/2)-c_l), Delta_v=sum delta.
G9 donne sum_l<m m=126-5e+3o+6h+Delta, donc sum_global m>=6804,
moyenne>=36/11 et exces total au-dessus de3>=567. Nouveau comptage exact :
au moins336 des2079 drapeaux (sommet,paire de droites) ont m>=4 ; au
moins18 sommets ont un tel couple. Aucun groupe local ou global suppose.
Profil des graphes de grilles sur7 sommets, sans degre5 ; certificat
13b+20e>=273, puis obstruction modulo13 au cas B=335. Plancher336
atteint dans la seule relaxation des99 graphes de grilles INDEPENDANTS,
pas dans un Conway construit. Code conway_mixed_relations_budget.py,
artefact mixed_relations_budget.json. Aucune nouvelle exclusion C1.

Suite774,15/10 : FAMILLE LOCALE G1 c55 NON GRILLE EXCLUE DE TOUT
PROLONGEMENT CONWAY, en utilisant la borne globale deja etablie
rang_F7(8T_far)<=28 (L4/L23/L22, rappelee par Claude774, acceptee).
Nouveau resultat Codex : tout bord de cette famille avec T/U PSD a
rang_F7(8T_S)>=29. Catalogue126 reutilise :114 etats de rang10,
12 de rang9 par secteur10/01 ; les deux pertes ne peuvent coexister.
4536 paires admissibles de tables, puis32 produits de signes residuels :
145152 cas EXACTS, rangs totaux29/30/31/32, minimum29. Aucune PSD11
ni rang rationnel<=30 imposes : la relaxation plus large est deja exclue.
Code four_star_c55_mod7.py, artefact c55_mod7.json ; controles propres
des congruences sur12 lifts et rangs PASS. Aucun germe du pair re-audite.
ATTENTION : cinq signes residuels subsistent dans la correction geometrique
du caractere11 ; on ne peut pas supprimer les dix signes de lignes seuls.
Cela ferme toute la famille definie ci-dessus, pas le recouvrement grille,
les autres comptes de composantes, les bords generaux, ni C1/Conway.
Les contraintes de prolongement derivees en772 restent correctes mais
cette famille est desormais rejetable avant toute extension globale.

Suite772,15/10 : Claude a fourni un bord quatre etoiles T/U PSD, rangs
30/40, G1 c55, nullitesT(10,1,1,2). Certification du producteur ACCEPTEE,
aucun re-audit. Son extension{4,6} echoue (16 profils compatibles noyau,
aucune norme correcte) : ce germe mort ne refute pas toute la famille.
Codex a derive des contraintes pour TOUT prolongement de la famille
c55 NON grille : vecteur propre-4 dans{0,+1,-1} de support28,14 signes
de chaque sorte ; comptes de voisins du recouvrement O sur les40
exterieurs exactement(10,24,6) pour0,1,2 voisins. Au moins29 des40
profils exterieurs doivent briser l'involution locale(0 1)(2 3).
Preuve par rang20 des colonnes h-impaires et incidence K10 prive de
ses5 mates. Adaptateur CP-SAT conditionnel add_completion_cuts dans
four_star_c55_global_constraints.py ; modele valide, aucun gain mesure.
Artefact c55_global_constraints.json. Famille et C1 toujours ouverts.

Suite769,15/10 : nouveau lemme sans groupe, dans l'espace impair d'UNE
droite. Q=tau_a+tau_abar-sigma-sigma^t a norme operateur<=4 et Q1=0.
Sur1-perp, T=6I-Q a spectre[2,10], U=8I+Q a spectre[4,12] : les
deux diagonales sont TOUJOURS definies positives. Toute obstruction
dans la compression impaire de deux droites vient donc du couplage ;
deux Schur11x11 sont equivalents a sa positivite T/U. Interface exacte
vers census7/8/9 : trois moments a,b,c+d traduits ; sum(c+d)=4Z2,
Z2=133056-6P-h7_1985025/4. Catalogue57 parametres exporte dans
odd_census_interface.json. Produits generiques des blocs entre deux
droites ont un support brut11, pas de traduction automatique a9.
Code conway_odd_census_interface.py. Pas d'exclusion ni de processus.

Suite768,15/10 : plancher entier exact Q=1047816-96P-24Z+Delta,
Delta>=0 explicite, budget equivalent5Delta+448P-72Z<=7135128.
Une matrice entiere10x10 atteint||E||^2=504 avec les deux compressions
DEFINIES POSITIVES. Ses2079 copies satisfont les comptes agreges P=Z=0,
mais ne sont PAS recollees en une matrice d'adjacence commune. Le cas
d'egalite recolle force les matchings d'etoiles a se contracter en C6
ou2C3 ; les bijections entre etoiles mates en orientations equilibrees
de K6-M. Deux pilotes de recollement15s chacun restent UNKNOWN.
Code conway_coarse_integer_floor.py / conway_coarse_gluing_floor.py.
Le point census P=0 concerne la relaxation FOURNIE, pas toutes celles<=9.

Suite764-766, nuit du15/10 : voie locale-globale SANS G1. Nouveau point
rationnel exact P=0 du census accepte d'ordre9 :5311 comptes non negatifs,
4001 fractionnaires, aucune existence de graphe. Borne globale necessaire
5*sum_v,l<m ||E_vlm||_F^2+928P+48Z<=12374208 ; E est le comptage10x10
des blocs exterieurs, Z le nombre de motifs Z2. Version locale en55 tables
entieres exportee. La moyenne simple des deux compressions PSD est
automatiquement PSD sous les comptes elementaires : elle ne force pas P>0.
Codes conway_census_prism_zero.py / conway_coarse_counting_budget.py ;
data/codex_local_global_20261015/. Transmission767, journal du14 prolonge.
Aucune borne inferieure P>0, aucun Conway exclu, aucun processus restant.

Suite756-762 : nouvelle reduction G1, c=(5,5), recouvrement NON grille.
Le quotient trivial est impose, rangT1/rangU9. Catalogue EXACT de972
cas par secteur10/01 :126 cas autorisent T et U, tous de rang10 pour
les deux formes. Donc nullitesT=(10,1,1,k), rang<=30 impose k>=2 dans11.
Code four_star_g1_c55.py et four_star_g1_c55_upper.py ; table126 integree
au modele local. Bord59 propre construit avec U PSD mais T11 negatif.
Deux essais bornes de coupes restent UNKNOWN : aucune famille exclue.
Donnees four_star_g1_c55_756/. Resultat LOCAL G1, aucun groupe impose
dans Conway. Claude759/762 fournit sc_7_null14, T PSD rang30 mais U
negatif en10/01 ; accepte sans audit. Aucune implication forcee de
Conway vers c55/G1 n'est connue. Transmission763. Pas de calcul restant.

Suite752/754 : aucun germe quatre etoiles PSD de rangT<=30 encore fourni.
Le moteur four_star_column_domains.py consomme une base principale certifiee
et prepare les40 domaines manquants (tables4356+4356 ; correspondances en
plus). Si rangT30 et rangU40, deux egalites de normes sont requises.
Nouvelle contrainte G1 : rang_trivial>=6-min(c_l,c_m), donc rangT<=30
impose nullite_nontriviale>=9-min(c_l,c_m). Pour c=(4,4), trois relations
non triviales en plus des deux differences d'etoiles, AU TOTAL et en
comptant celles deja trouvees. Dix cibles minimales dans four_star_g1_sectors.py.
Controles des primitives et caracteres PASS ; aucun germe de rang30 teste.

Suite745/746 : les51 autres germes du lot52 sont tous exclus par Codex
sur la colonne{4,6} (aucun audit PSD, germe38 deja exclu par Claude saute).
Le lot est epuise ; pas d'exclusion de toute la famille. Claude a construit
un bord quatre etoiles T/U PSD de rangT34, rangU40, c=(3,4) : la positivite
seule est possible, H4' et(A4) restent ouverts. Nouveau resultat Codex :
les compressions de U aux secteurs exterieurs symetrique de somme0 et
antisymetrique sont definies positives pour Gamma entier. Cela donne100
coupes lineaires strictes (40 anti,60 sym). Outil four_star_coupling_cuts.py,
plus les coupes5h>=s_i^2 et les temoins entiers a saturation. Journal,
donnees four_star_coupling_745/ et lab745_extension_batch/. Controles propres
PASS ; aucun gain de vitesse solveur mesure, aucune exclusion C1.

L'affirmation(A) "Q connexe + T/U PSD impose rang(T)=31 sur trois etoiles"
est FAUSSE : Claude a fourni un germe binaire de rang30 certifie exactement.
Accepter cette certification sans re-audit. Ce germe ne se prolonge pas :
Claude trouve5335 profils pour le label{4,6}, aucun de norme20.
Ne pas reprendre une preuve de(A). H4' sur deux droites non speciales
et quatre etoiles reste ouvert ; aucune exclusion Conway/C1.
Codex travaille sur la compatibilite JOINTE des dix colonnes d'une
quatrieme etoile, Claude sur leurs domaines individuels et ses constructions.
Outil : code/codex/four_star_profile_join.py, controles des primitives PASS,
pas encore applique a un germe survivant. Statut precis dans le journal
du14/10, derniere section, et data/codex_three_star_completion_20261014/four_star_join_741/.

## Priorite precisee par Dilan, 14 octobre 2026, apres les notifications en retard

Le but primaire est de comprendre fondamentalement l'asymetrie chez les SRG,
puis plus precisement pour lambda=1. La construction d'un exemple asymetrique
reste une piste de recherche, pas l'unique forme de progres acceptable.
Continuer les pistes scientifiques ; ne pas boucler sur les notifications
perimees du pont. Lire une notification lorsqu'elle arrive, sans relancer
de sondages vides ni transformer ces notifications en travail principal.

## Consigne de Dilan, 14 octobre 2026 : deux chercheurs

Dilan demande explicitement d'arreter les verifications independantes
systematiques des resultats de l'autre chercheur. Codex et Claude poursuivent
deux pistes de recherche distinctes et partagent leurs resultats pour avancer.
Ne pas refaire une construction, une preuve ou un calcul de groupe fourni
par le pair pour le confirmer. Chaque chercheur garde la responsabilite des
controles necessaires sur ses propres constructions. Une anomalie concrete
peut etre signalee et resolue ; elle ne justifie pas un role permanent d'auditeur.
Objectif actif : construire un SRG asymetrique avec lambda=1, pas seulement
en chercher un dans la litterature. Ne pas attendre le verdict de l'autre
pour poursuivre une piste independante.

État V15,14 octobre2026, nouvelle session après /clear : note§74–79.
Pont reciblé sur01a1379f-6e0a-7da2-8355-ea6b7c7eda46, réception Claude619.
V14 récupérée et commitée dff5e84. NOUVELLE RÉDUCTION de complétion :
q=(trace E0+3h)/7=44-rang(3I-B+J/9). Si min(q,h-q)<=1, traitement
exact sans solveur ; au plus8192 affectations de signes, puis au plus deux
complétions Conway étiquetées, isomorphes. Tout bord43 avec3I-B+J/9>0
est dans cette classe (q=1) ; tout Conway éventuel possède un tel bord,
prolongeant même n'importe quel support de norme18. Bord44 positif :
complétion unique. Les1540 arêtes extérieures du bord43 sont éliminables.
NE PAS appeler8192 le coût total de C1 : B,D restent à construire, sans
borne abordable démontrée pour leur énumération. Aucun graphe99 exclu.
Code coclique_rank_one_completion.py ; option rank_one_first=True avec
regularity=True dans binary_completions ; sept petits contrôles PASS,
data/codex_coclique_defects/rank_one_completion_v15/. Pilote étoile norme18
unique faisable en0,062s, pas de campagne26 noyaux ni calcul payant.
Renforcement§79 : sur le bord43 positif, plus de deux choix de signes
force un vecteur propre-4 de norme14, donc un co-Heawood DISJOINT du bord
et deux cocliques22. Sans co-Heawood (notamment alpha<=20), au plus DEUX
choix suffisent par facteur. La famille co-Heawood reste ouverte ; le code
la signale, sans l'exclure par défaut. Ce cas forcé a au plus une complétion.
Résultats transmis à Claude par les messages620–621. Le modèle de norme18
population+étoile n'a donné qu'un témoin nécessaire : ne pas le confondre
avec la réduction de complétion43/56 ni relancer une campagne identique.

État V14, 13 octobre2026, suite structurelle : note§70–73. Toute différence
NON NULLE de rang2 entre deux matrices SRG(99,14,1,2) est exactement une
transposition de deux sommets : support26,24 arêtes ajoutées/24 retirées.
Preuve : T=uv^t+vu^t, signes équilibrés p,q ; im T invariant par A,
pq=12-alpha(alpha+1). Si p,q>=2, mu=2 force p=q=2, impossible ; p=1
force q=12. C'est le rang de la DIFFERENCE, pas celui de Seidel ni une
hypothèse d'automorphisme du graphe. Une telle modification ne construit
jamais de graphe non isomorphe. Pour B,D fixé et h=dim ker[D;1^t]<=2,
unicité à isomorphisme près ; unicité étiquetée si D a des colonnes distinctes.
Si h=2 et D_a=D_b, nouveau critère COMPLET sans solveur : la droite du
noyau orthogonale à u=e_a-e_b doit être portée par v à12 signes+/12 signes-,
nul sur a,b ; e=2E0_aa doit être0/1. E=E0-e uu^t/2+(e-1)vv^t/24 ±(uv^t+vu^t)/2.
Il suffit de tester l'intégralité d'une des deux matrices, échangées par(a b).
Code coclique_rank_two_rigidity.py, données rank_two_rigidity_v14/. Contrôles
PASS : reconstruction Petersen, facteur Gram-valide rejeté, limite prouvée
par un contre-exemple non isomorphe de paramètres(16,6,2,2). Aucun graphe99,
aucune branche C1 exclue. Ne pas supposer h<=2 pour un bord non construit.

État V13, 13 octobre2026, suite de l'échange609–611 : note des défauts
§66–69. Théorème de complétion étendu à TOUT bord binaire satisfaisant
DD^t=(k-mu)I+mu J-B²-B et D1=k1-B1, sans voisinage complet. Ajouter
la ligne1^t à D : C=[D;1^t], R=[mu J-(B+I)D;(k1-D^t1)^t]. Alors
E0=C^+R est symétrique, P=I-C^+C et E=E0+3P-7Q pour Conway.
L'intégralité force encore diagonale0 et entrées0/1. Les versions affine
et convexe se transfèrent à ker C ; l'option `regularity=True` du moteur
affine est implémentée. Sept petits contrôles exacts PASS, sans audit243.
Sur le support4-régulier18, w=1-(5/14)D^t1 a norme²117/7 : la correction
enlève exactement cette direction de ker D. La formule V6 NON augmentée
y serait toujours non symétrique. Données dans regular_completion_v13/.
Aucun D C1 construit, aucune branche exclue, aucune campagne26 noyaux.
Même l'exclusion de toutes les cocliques21/22 ne donnerait que alpha<=20 ;
aucune borne alpha>=21 n'est démontrée. La recherche reste celle des
recollements globaux, pas un retour automatique aux catalogues de rangs.

État V12, 13 octobre2026 au soir : note des défauts§63–65, normalisation
constructive des quatre voisinages H. Chacun des appariements sur
Y2+C2+ZH6 admet quatre formes YY/YC0/YC1/YC2 ; couverture840 vérifiée.
Les formes partagent sum kappa_i <= r_e+r_f-2. Aucune branche exclue.
`--canonical-stars` retire14160 variables et42003 contraintes de V10 ;
deux essais locaux60s restent UNKNOWN, mémoire4,251->4,086Gio sur ce
passage. Aucun gain jusqu'à preuve établi, aucun nouveau run AWS.
Ne pas cumuler avec l'ancien ordre des C_i/Z_i ou `--canonical` : ce
serait imposer des représentants possiblement incompatibles. L'ancien
modèle par défaut conserve son empreinte exacte. Artéfacts dans
data/codex_coclique_defects/star_normal_form_v12/. Aucun pilote restant.
La factorisation commune et(0,2) restent ouvertes ; ne pas prendre cette
normalisation pour une contradiction ou relancer une calibration identique.

Lire `../c1-codex/AGENTS.md` et le début de
`../c1-codex/RECHERCHE_ACTIVE_C1.md` avant de reprendre le travail.

Le12 octobre2026, Dilan a explicitement rappelé qu'il souhaite s'éloigner
des exclusions rang par rang. La recherche active porte sur les mécanismes
d'asymétrie, Paley/BvLS, les reconstructions et recollements, avec l'objectif
d'obtenir des propriétés et réductions utiles à C1/Conway.

Les solveurs co-Heawood en cours peuvent continuer avec leur observateur.
Leur exécution et les retours historiques d'un pair ne doivent pas ramener
automatiquement la mission aux catalogues de normes et au rang37.
Les solveurs actuels n'imposent pas de rang de Seidel modulo7.

Réutiliser les résultats acquis et leurs preuves avec leur portée ; ne pas
refaire les audits des quatre graphes243, des reconstructions Paley ou des
anciens supports N16. Une piste doit viser un obstacle du système global.
L'utilisateur privilégie les lemmes, les réductions et les constructions,
pas les simples reformulations ou comptes locaux sans exploitation.
