#!/bin/bash
# local split of the slow P3NB job p3nb_088_005400 (core 88, borders 5400..5612) with the frozen program
S="$(cd "$(dirname "$0")/.." && pwd)"
V=/c/Users/bfhdh/conway99-env/.venv/Scripts/python.exe
s=$1; n=$2
cd "$S/p3nbprod" && "$V" -X utf8 py_extend.py "$S/k3prod_v4/pkg/code/codex" P3NB "$S/pybd_p3nb_all/core_088.json.gz" $s $n --sat --lean --enc=seq --verbose --out="$S/p3nb_core88_split/core088_$(printf %06d $s)_$(printf %06d $((s+n-1))).json.gz" > "$S/p3nb_core88_split/log_$s.txt" 2> "$S/p3nb_core88_split/verbose_$s.txt"
echo "done $s $n" >> "$S/p3nb_core88_split/log_$s.txt"
