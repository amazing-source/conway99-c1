"""Checks of the v2 rehearsal (q_v2_rehearsal.yml) on branch queue-ci / run/qci-* (C2, 2026-10-02).
  python3 q/tools/v2_check.py s1 NAME   the machine NAME (Q_TEST, package v2) installed, passed both calibrations, ran its claimed job(s),
                                        pushed each result (chunk_ok, chunk_done, v2 engine sha) BEFORE its done event, and ended FINI.
  env EXPECT_PKG (default v2): package version the machine must report; O24_REF='{"31": [nodes per depth]}': each listed O24 class
  must have been run and must give exactly the lab's node counts (v3 rehearsal).
Exit 0 = PASS."""
import os, sys, json, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
QBR, PREFIX = "queue-ci", "run/qci-"
V2_ENGINE = None
FAILS = []


def git(*a, check=True):
    r = subprocess.run(["git", *a], capture_output=True, text=True)
    if check and r.returncode: sys.exit("git %s: %s" % (" ".join(a[:2]), r.stderr))
    return r.stdout


def ok(c, m):
    print(("PASS  " if c else "FAIL  ") + m)
    if not c: FAILS.append(m)


def main():
    name = sys.argv[2]
    git("fetch", "-q", "--prune", "origin", "+refs/heads/%s:refs/remotes/origin/%s" % (QBR, QBR), "+refs/heads/%s*:refs/remotes/origin/%s*" % (PREFIX, PREFIX))
    ev = [json.loads(l) for l in git("show", "origin/%s:events.jsonl" % QBR).splitlines() if l.strip()]
    st = dict(l.split("=", 1) for l in git("show", "origin/run/%s:status.txt" % name).splitlines() if "=" in l)
    ok(st.get("STATE") == "FINI", "%s ended FINI (state %s, reason %s)" % (name, st.get("STATE"), st.get("REASON")))
    want = os.environ.get("EXPECT_PKG", "v2")
    ok(st.get("PKG") == want, "%s reports package %s (PKG=%s)" % (name, want, st.get("PKG")))
    man = json.load(open(os.path.join(os.path.expanduser("~"), "c2_cloud_run", "MANIFEST.json")))
    eng = man["engine_code_sha"]
    eng_by_kind = {"o24": man.get("engine_code_sha_o24"), "golay_pairs": man.get("engine_code_sha_golay"), "resolve": man.get("engine_code_sha_resolve")}
    o24_ref = json.loads(os.environ.get("O24_REF", "{}"))          # {class: nodes per depth of the lab run}, compared exactly
    done = [j for e in ev if e["m"] == name and e["op"] == "done" for j in e["jobs"]]
    ok(len(done) >= 1, "%s completed %d job(s): %s" % (name, len(done), done))
    for j in done:
        lid, k, n = j.split(":"); f = "results/%s_%s_%s.jsonl" % (lid, k, n)
        txt = git("show", "origin/run/%s:%s" % (name, f), check=False)
        recs = [json.loads(l) for l in txt.splitlines() if l.strip()]
        r = recs[-1] if recs else {}
        ok(bool(r.get("chunk_ok")) and bool(r.get("chunk_done")), "%s: chunk_ok %s chunk_done %s verdicts %s" % (f, r.get("chunk_ok"), r.get("chunk_done"), r.get("verdicts")))
        e = eng_by_kind.get(r.get("kind")) or eng
        ok(r.get("code_sha") == e, "%s: engine %s == package engine %s" % (f, r.get("code_sha"), e))
        if r.get("kind") == "o24" and str(r.get("class")) in o24_ref:
            ok(r.get("nodes_per_depth") == o24_ref[str(r["class"])], "%s: O24 nodes per depth %s == lab run %s" % (f, r.get("nodes_per_depth"), o24_ref[str(r["class"])]))
    for c in o24_ref:
        ok("000:%s:141" % c in done, "O24 class %s was run (job 000:%s:141 done)" % (c, c))
    print("RESULT:", "PASS" if not FAILS else "FAIL (%d)" % len(FAILS))
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__" and sys.argv[1] == "s1":
    main()
