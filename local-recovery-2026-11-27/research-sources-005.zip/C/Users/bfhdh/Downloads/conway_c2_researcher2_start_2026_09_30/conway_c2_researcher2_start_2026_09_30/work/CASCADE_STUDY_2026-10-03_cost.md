# Where the remaining cost comes from, and what does not reduce it (C2, 2026-10-03)

All experiments are local and use the v8 engine (frame_dfs_next 267d2bb5). Scripts are in lab `scripts/analysis/`.

## Measurements on 011

**Producer.** About 15–60 s per y1 representative: negligible.

**Consumer.** All of the cost is the stage-1 DFS on the 2–8 % of pairs that escape the trap, swap and twin rules.

On the PC, per searched pair:

| Part | Time | Detail |
|---|---|---|
| Setup | 112 ms | compat 71 ms |
| DFS | 392 ms | — |

The nodes sit at depth 3 (48 %) and depth 4 (46 %); depth 5 holds 1.3 %.

**Engine version.** The 011 and 014 cost ratios used for planning (1.9 and 2.9) were measured with the OLDEST engine (v1 b48cf844,
all 47 + 12 chunks).

- Re-running the y1 representatives of old chunk 55/646 with v8 on the PC: 55 → 58 s, 701 → 276 s, 1347 → 50 s, 1993 → 3,538 s
  (2639 still running at the time of writing). That is 73k pairs in 65 min, against 6.7 h on AWS for the whole v1 chunk (112k
  pairs).
- So v8 is roughly 2.5× faster than v1 on 011, to be confirmed with 2639.

## Why the searches die (death trace, 011)

- **Dead points.** 76 % flex, 12 % target-1, 8 % boundary, 5 % exact-3.
- **Candidates through a dead point.** About 2,000 at the root. After 3 chosen h:
  - 91 % are not orthogonal to some chosen h. This is the independence expectation: 1 − 0.45³.
  - The remaining ~9 % (~180) ALL share a target-1 point with a chosen h.
- **Mechanism: exact cover of the target-1 points.**
  - The 7 h must partition the K target-1 points, so Σ t(h_c) = K, an average of 2–3 per h.
  - A typical candidate has t(h) = 4–7.
  - Frames would have to consist mostly of rare low-t candidates. The DFS mostly explores high-t ones and runs out of target-1
    points.
- **No pairwise bias.** P(orthogonal | covers β, does not cover β) = 0.474, against 0.451 overall.
- **Not a parity obstruction.** At every sampled death there are about 180 norm-4 lattice vectors orthogonal to y1, y2 and the chosen
  h with (x, β) = ±1. They are admissible but share target-1 points with the chosen h.

## Ideas tested that do NOT reduce the cost

All verdicts were identical to the original kernel.

| Idea | Result |
|---|---|
| Norm-24 characteristic trap (same proof as the norm-16 trap; bound Y_z ≤ 122) | max Y_z = 122 on all 2,350 sampled 011 pairs; kills 0 |
| Per-component budget ILP (pair_budget) | 0/25 pairs killed; slower than the search |
| Deduplication by the rank-22 complement K | 490 distinct cheap invariants among 600 pairs: no repetition |
| Twin envelope | single and involutive (shell theorems §5.1); already fully used |
| Static path consistency on the compatibility graph | at the root every point has 1,700–2,080 candidates: nothing to prune |
| Dynamic forward checking of children | nodes ×2.1 fewer, time only ×1.15 |
| Target-1 count bound s·tmin ≤ R ≤ s·tmax | prunes 1.86M nodes, but exactly those the pending-point scan kills at the same node: ×1.0 |

## Conclusion

- The per-node work is already cheap (about 1.6 µs per node).
- A large factor would need a different search organisation, for example exact cover over the target-1 points with subset-sum
  reasoning, or a learning (CDCL) solver. Both are substantial rewrites with an uncertain gain.
- The measurable levers now are:
  - v8 instead of v1: about ×2.5 on 011 and 014;
  - 31 workers per c7a.8xlarge instead of 26: +19 %, memory to be checked;
  - forward checking: +15 %.
