#!/bin/bash
export MSYS_NO_PATHCONV=1
A="aws --profile frere --region eu-north-1"; B=conway99-c1-runs-733515672125
for i in $(seq 1 200); do
  $A s3 cp s3://$B/runs/verif6b/status.json - 2>/dev/null | grep -q '"all_done": true' && break
  sleep 20
done
mkdir -p collect_verif6b
$A s3 sync s3://$B/runs/verif6b/ collect_verif6b/ --only-show-errors
py -3 -I analyse_v6.py
