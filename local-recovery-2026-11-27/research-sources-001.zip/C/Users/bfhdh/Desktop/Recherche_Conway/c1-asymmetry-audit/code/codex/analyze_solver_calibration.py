"""Preserve the baseline worker table and the actual next-run portfolio."""
import json
from pathlib import Path
import re

data = Path(__file__).resolve().parents[2] / 'data/codex_coheawood'
old = (data/'global_8workers_long.log').read_text(encoding='utf-8')
new = (data/'global_no_max_lp_8w.log').read_text(encoding='utf-8')

def fingerprint(text):
    return re.search(r'model_fingerprint: (0x[0-9a-f]+)', text)[1]

assert fingerprint(old) == fingerprint(new), 'Compared models differ'
def worker_table(text):
    table = {}
    if 'Search stats' not in text:
        return table
    section = text.split('Search stats', 1)[1].split('\n\n', 1)[0]
    for name, values in re.findall(r"^\s*'([^']+)':\s+(.+)$", section, re.M):
        numbers = [int(s.replace("'", '')) for s in values.split()]
        table[name] = dict(zip(('booleans', 'conflicts', 'branches', 'restarts',
            'backtrack_to_root', 'backtracks', 'boolean_propagations', 'integer_propagations'), numbers))
    return table

def sharing_table(text):
    table = {}
    if 'Clauses shared' not in text:
        return table
    section = text.split('Clauses shared',1)[1].split('\n\n',1)[0]
    for name,values in re.findall(r"^\s*'([^']+)':\s+(.+)$",section,re.M):
        table[name] = dict(zip(('exported','imported','binary_read','binary_total'),
                              (int(s.replace("'",'')) for s in values.split())))
    return table

workers = worker_table(old)
assert workers['max_lp']['conflicts'] == 32
portfolio = re.search(r'full problem subsolvers: \[(.*?)\]', new)[1].split(', ')
report = dict(baseline_status='UNKNOWN', baseline_wall_seconds=3601.0247283,
    baseline_workers=workers, same_model_fingerprint=fingerprint(old),
    next_full_subsolvers=portfolio,
    portfolio_change=dict(removed='max_lp', automatically_added='probing_max_lp'),
    interpretation='One named worker excluded; scheduler replaced it with probing_max_lp. This is not a test without every maximal LP relaxation. No superiority established.',
    next_metadata=json.loads((data/'global_no_max_lp_8w.run.json').read_text(encoding='utf-8')),
    monitor=json.loads((data/'telemetry/observer.json').read_text(encoding='utf-8')))
finished = data/'global_no_max_lp_8w.json'
if finished.exists():
    report.update(next_final_result=json.loads(finished.read_text(encoding='utf-8')),
                  next_final_workers=worker_table(new),
                  baseline_clause_sharing=sharing_table(old), next_clause_sharing=sharing_table(new),
                  conclusion='Both one-hour trials UNKNOWN. Replacement probing_max_lp exported zero clauses and had zero conflicts. No demonstrated improvement; do not adopt the change as a winning setting from one stochastic comparison. No automatic rerun; active research is asymmetry and reconstruction.')
(data/'telemetry/calibration_decision.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
latest=json.loads((data/'telemetry/latest.json').read_text(encoding='utf-8'))
print('LATEST', latest['captured_utc'])
for name, run in latest['runs'].items():
    print(name, 'running', run['running'], 'cores', run.get('average_cpu_cores'),
          'status', run['solver'].get('status'), 'stderr_bytes', run['stderr_bytes'])
print('IDENTICAL_MODEL_FINGERPRINT', fingerprint(old))
print('NEXT_PORTFOLIO', portfolio)
print('OBSERVER', report['monitor'])
