# Lattice 143 (root system a_15 a_8) hosts no frame: a two-line proof

Lab session (Claude), 2026-10-07. Replaces, for this lattice, the "component-budget test" of 28/09 (a solver plus an exact
enumeration, never reread). **Refereed by Codex on 07/10: accepted** (`lemma/t20_CODEX/REFEREE_143_PROOF.md`); script re-run by
the laptop session on another machine. It does not depend on the v10 run of 143 (stopped, nothing imported).

## Statement

**Proposition 143.** Let U be lattice 143 of the list (odd unimodular, rank 24, root system a_15 a_8; even neighbours A_15 D_9
and A_24). There are no vectors y_1, y_2, h_1..h_7, u_1..u_42 of U satisfying (R-ii) and (R-v) of Theorem R
(`AUDIT_REDUCTION.md`). In particular U hosts no frame.

Only two properties of a frame are used:
- (R-ii) the 42 vectors u_o are vectors of U of norm 3;
- (R-v) for every real v, the sum of (v,f)^2 over the 51 frame vectors f equals 7 (v,v).

The h, the y, the products between frame vectors, the new roots, T16 / T18 / T20, the pair enumeration and the search engine
are not used.

## The budget identity

Let V be a subspace of R^24 of dimension d and P_V the orthogonal projection onto it. Summing (R-v) over an orthonormal basis
e_1..e_d of V:

    sum over the 51 frame vectors f of |P_V f|^2 = sum_j sum_f (e_j,f)^2 = 7 d.          (B)

All terms are >= 0, so the 42 vectors u alone satisfy: sum_o |P_V u_o|^2 <= 7 d.

## Three facts about U (exact computation, `budget_143.py`)

1. U has 312 roots, in two classes under non-orthogonality: 72 roots of rank 8 and 240 roots of rank 15 (a_8 and a_15).
   Let W be the span of the first class, dim W = 8. For every x, |P_W x|^2 = S_8(x) / 18, where S_8(x) is the sum of (alpha,x)^2
   over the 72 roots. (For an irreducible root system of rank n with N roots of norm 2, sum of alpha alpha^T is invariant under
   the Weyl group, which acts irreducibly on the span: it is c P with c = 2 N / n by the trace; here c = 18.)
2. The vectors of U orthogonal to all roots are the multiples of one primitive vector z, and (z,z) = 144. Let l = R z, the
   orthogonal complement of the span of the roots (dimension 24 - 23 = 1). For every x, |P_l x|^2 = (x,z)^2 / 144.
3. U has 4096 vectors of norm 3, of three kinds (completeness of this list: see below, it is proved by the glue description and
   does not rest on an enumerator):

   | (x,z)^2 | S_8(x) | \|P_W x\|^2 | \|P_l x\|^2 | vectors |
   |---|---|---|---|---|
   | 81 | 0 | 0 | 9/16 | 1120 |
   | 169 | 16 | 8/9 | 169/144 | 288 |
   | 9 | 36 | 2 | 1/16 | 2688 |

## Proof of Proposition 143

Let c be the number of u_o of the third kind ((u,z)^2 = 9). By (B) for V = W: 2 c <= 7 * 8 = 56, so c <= 28.
The other u_o, at least 42 - 28 = 14 of them, are of the first two kinds and have |P_l u|^2 >= 9/16. By (B) for V = l:

    7 = 7 * 1 >= sum_o |P_l u_o|^2 >= 14 * 9/16 = 63/8 > 7.

Contradiction. QED

**The same proof as one linear certificate (Codex, 07/10).** For each of the three kinds, 4 |P_W u|^2 + 16 |P_l u|^2 is 9, 67/3
or 9, hence at least 9. Summing over the 42 u and using (B) on W and on l: 378 <= 4 * 56 + 16 * 7 = 336. Contradiction. (This is
the form proposed as a first target for a Lean check: a finite sum of rationals; the table of kinds is the separate part.)

## How the three facts were obtained, and how they were checked

- `budget_143.py <package>`: takes from the v10 package a basis of U and the lists of the vectors of norm 2 and 3
  (`scripts/frame_dfs_next.lattice_data`); asserts the sizes 312 and 4096; then, in exact integer / rational arithmetic: the two
  classes of roots and their ranks (elimination over Q), the null space of the 156 x 24 matrix of products with the roots
  (dimension 1, primitive generator z, (z,z) = 144), the table of ((x,z)^2, S_8(x)) over all vectors of norm 3 (asserted equal to
  the table above), and the identity 3 = S_8/18 + S_15/32 + (x,z)^2/144 for each of them. Output: `budget_143.json`. Run on the
  lab PC on 07/10: all assertions pass (a few seconds).
- Second computation, other enumeration code: the lab's script of 28/09 `exact_budget.py` (short vectors by the v1 engine
  `frame_dfs.short`; copies in `q/tools/lab_2026-10-07/`) prints the same three kinds with 560, 144, 1344 vectors up to sign,
  re-run on 07/10. Its own conclusion ("946 sums of u-types x 36 sums of h-types: INFEASIBLE") is the same statement with the h
  included; the proof above shows the u alone suffice.
- Completeness of the list of norm-3 vectors: proved for this lattice by the glue description of the next section, made exact
  by the referee (`lemma/t20_CODEX/referee_143_checks.py`, exact arithmetic: the reduced basis is unimodularly related to the
  input generators, Gram determinant 1, explicit A_8 and A_15 chains, z primitive of norm 144, index [U : M + Z z] = 144, the glue
  classes checked on every basis vector, the 41 possible heights enumerated). It uses no list of norm-3 vectors and no
  theta-series count. (Correction of the referee, applied here: `theta_odd24.py` takes N_3 as an input and does not prove
  N_3 = 4096; an earlier version of this note cited it for completeness. The value 4096 agrees with the count found for all
  156 lattices, hole H3 of the engine audit, but that is not what the proof rests on.)

## The table by hand: the glue description (made exact by the referee)

M = A_15 + A_8 is the lattice generated by the roots, det M = 16 * 9 = 144. By fact 2 and unimodularity, the primitive closure
of M in U has determinant (z,z) = 144, so M is primitive, and U / (M + Z z) is cyclic of order 144. Every x of U is
x = x_15 + x_8 + (t/144) z with t = (x,z), x_15 in the class u t of A_15^*/A_15 = Z/16 and x_8 in the class v t of
A_8^*/A_8 = Z/9, for fixed units u, v. The norms in the class i of A_n^* are i (n+1-i)/(n+1) + 2k, k >= 0.
Integrality of the norm for t = 1 gives 9 u^2 + 16 v^2 = 1 (mod 144): u = +-3 or +-5 (mod 16), v = +-2 (mod 9). With u = +-3
the class t = 5 would contain a vector of norm 15/16 + 8/9 + 25/144 = 2, a root outside M: impossible. So u = +-5, v = +-2.
Norm 3 with |t| <= 20 then has exactly the solutions
- t = +-3: classes +-1 and +-3, 15/16 + 2 + 1/16: 2 * 16 * 84 = 2688 vectors;
- t = +-9: classes +-3 and 0, 39/16 + 0 + 9/16: 2 * 560 = 1120 vectors;
- t = +-13: classes +-1 and +-1, 15/16 + 8/9 + 169/144: 2 * 16 * 9 = 288 vectors;

in all 4096 vectors. (t = (x,z) is an integer with t^2/144 <= 3, so |t| <= 20; within the class of t the norms are the minimum
plus an even integer; the minimum is 0 for t = 0, 3 for t = +-3, +-9, +-13, 4 for t = +-4, +-6, +-10, +-16, 5 for
t = +-1, +-5, +-7, +-19 and at least 6 for the other t: norm 3 occurs only where the minimum is 3.) This reproduces the table,
counts included; the classes with minimum 4 are the kinds of norm-4 vectors found by the programs as well.

## Why the packing criterion does not settle 143

C1's packing test (`c1/code/envelope_pack.py`): m(x) = r/8 - E(x) with r = 312 and E(x) = sum over the positive roots of
(alpha,x)^2 = 9 |P_W x|^2 + 16 |P_{a_15} x|^2. For the three kinds: E = 39, 23, 33, so m = 0, 16, 6. There are 1120 vectors
with m = 0, so the 42 smallest values of m sum to 0, against 24 * min(16, 25) - 312 = 72 new roots: the test passes trivially.
The tracker field "packing: survives" of 28/09 is consistent with this.

## Status

- Proof: two lines from (R-ii), (R-v) and the table. Refereed by Codex (accepted); logic also checked by the laptop session.
- Table: the exact glue description (referee's checker; actual units u = 5 mod 16, v = 7 = -2 mod 9), and two programs with
  different enumeration code that find the same three kinds and counts.
- The record of 28/09 (solver verdict "component budgets infeasible", `scripts/component_budget.py`) is superseded: no solver
  output is used here.
