# Instructions pour le PC du labo (C1)

> **Gelé le 25/09/2026 (décision de l'utilisateur) : plus aucune campagne de solveurs** (SAT, CP-SAT,
> cube-and-conquer, générateurs), y compris sur ce PC. Raisons : branche C2 (SAT de 8 h, cassage de symétrie,
> cube-and-conquer, générateur : rien) et C1 (les solveurs n'ont exclu que la torsion faible, jamais le cœur ;
> notes/100). Les entrées ci-dessous restent comme archive ; la recherche continue en mathématiques.

Machine : 32 Go de RAM. Dépôt : `git clone https://github.com/amazing-source/conway99-c1` (privé).
Environnement : Python 3.12+ avec `numpy scipy sympy networkx python-sat` ; pour les certificats : `cadical` et
`drat-trim` natifs (images Docker de la branche C3 : `satbox`, `c3box`), ou compilés depuis les sources.
Tout résultat se rapporte avec : commande exacte, temps, verdict, empreinte SHA-256 du CNF.

## 1. Contrôle positif SAT au niveau CNF (priorité 1)
Le générateur d'équations est validé sans SAT sur srg(9) et BvLS (`code/validate_rooted.py`, 0 violation). Le contrôle
au niveau CNF + solveur reste à faire sur BvLS (t = 10, ~20 M clauses, ~10–15 Go) :
```
cd code
python rooted_generic.py --graph bvls --root 0 --plant      # doit être SAT immédiatement (solution plantée)
python rooted_generic.py --graph bvls --root 0 --solve      # doit être SAT (τ de BvLS, arêtes disjointes libres)
```
Un UNSAT ici invaliderait tous les résultats UNSAT (L7, L8, L10, L11, L14) : les arrêter et chercher l'erreur.

## 2. Certificats DRAT (priorité 2)
Pour chaque cas, écrire le CNF, puis `cadical --no-binary cas.cnf cas.drat` et `drat-trim cas.cnf cas.drat`.
```
python hamming_phi.py --iso --breaksym --dimacs L7_phi_iso.cnf          # L7 (point de Hamming + σ_x ∈ Aut)
python hamming_point.py --t 6 --sigma --dimacs L7_adj.cnf               # L7, 2e encodage   (option --dimacs à ajouter si absente)
python hamming_phi.py --dimacs L8_phi_nobreak.cnf                       # L8 sans cassage de symétrie
python hamming_phi.py --breaksym --dimacs L8_phi_break.cnf              # L8 avec cassage
python rooted_model.py --case g19A --dimacs L10_g19A.cnf                # L10 (idem g19AA, g19AB)
DIMACS=L11.cnf python rooted_family.py 012                              # L11 (torsions confinées à 3 classes)
DIMACS=L14_C2.cnf python rooted_family.py sources 00,10 23              # L14, |C| = 2 (idem 234, 2345, 23456)
```

## 3. Frontière de torsion (priorité 3)
État : aucun sommet n'a 21 ou 19 grilles ; torsions confinées à 3 classes impossibles ; une étiquette seule, une
classe seule, deux étiquettes avec |C| = 2 ou 3 : impossibles. À faire, dans l'ordre :
1. deux étiquettes, |C| = 4 et 5 : `python rooted_family.py sources 00,10 2345` et `… 23456` ;
2. trois étiquettes : énumérer les motifs (`python wpatterns.py 3`), puis un SAT « sources + domaines » par motif ;
3. `python rooted_family.py 0123` (torsions confinées à 4 classes) ; puis 01234.
Chaque UNSAT = un lemme ; noter le temps, garder le CNF pour DRAT.

## 4. Sondes τ aléatoires (priorité 4, en parallèle)
`python random_tau_probe.py SEED` pour SEED = 1…32 (un cœur chacun, ~1 Go chacun). Un SAT produirait un
srg(99,14,1,2) (fichier `data/SAT_candidate_SEED.json`) : le vérifier immédiatement avec `graphs.srg_params`.

## 4 bis. Analogue du test Gewirtz : une seule grille en x (priorité 4)
Sur l'analogue q = 2, imposer une seule fermeture en 3-cube rend Gewirtz impossible (UNSAT, 13 s) : il est sans cube.
Pour 99 : imposer la grille G₀₁ en x (τ mate entre les classes 0 et 1), τ libre ailleurs. UNSAT ⇒ Γ est **sans
grille**. SAT ⇒ un srg(99,14,1,2) (!) à vérifier. Modèle : `rooted_family.py` avec toutes les étiquettes libres et
les 8 contraintes de mate entre classes 0 et 1 (à ajouter : mode `onegrid`). Probablement long (τ entièrement libre).
Aussi : famille « τ Fano-cohérent » (`python rooted_family.py fano`, 42 bits de signe libres).

## 5. Recherche de géométries tordues à t = 6 (priorité 5)
`python tricirc_sat.py 7 N N 20` pour N = 34…80 (un N par cœur). Une solution tordue tuerait F17 et fournirait un
témoin au bon t.
