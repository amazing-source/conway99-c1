#!/bin/bash
# Wait (at most 20 min) until both build logs are in S3, then print them.
export MSYS_NO_PATHCONV=1
A="aws --profile frere --region eu-north-1"; B=conway99-c1-runs-733515672125
for i in $(seq 1 80); do
  ok=1
  for m in a b; do $A s3 ls s3://$B/runs/verif1$m/build.log > /dev/null 2>&1 || ok=0; done
  [ $ok = 1 ] && break
  sleep 15
done
for m in a b; do echo "== verif1$m build.log"; $A s3 cp s3://$B/runs/verif1$m/build.log - 2>&1 | tail -5; done
