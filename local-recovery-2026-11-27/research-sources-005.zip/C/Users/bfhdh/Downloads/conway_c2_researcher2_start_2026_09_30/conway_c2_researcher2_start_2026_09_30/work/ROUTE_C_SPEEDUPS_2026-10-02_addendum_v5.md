# Route (C): engine fix and package v5 (2026-10-02, ~04:00–04:50 UTC, C2, user asleep, "loop mode")

Addendum to `ROUTE_C_SPEEDUPS_2026-10-01.md`, section 9.

## 1. A crash in the joint star sums (engines v1 and v2), found by AWS job 001:5:17
- **Symptom.** After 4.4 h of computation the v3 job 001:5:17 died with:
  - `ValueError: operands could not be broadcast together with shapes (32,) (80,)`;
  - in `frame_dfs_next.joint`, at `dl = tgt_ws[x] - part_ws[x]`.
- **Cause.** The boundary-point lemma (FD_BND, on by default since 29/09) appends the boundary points z (characteristic, norm 16,
  Y_z = 58) as extra columns of `ps["HS"]` and `ps["WS"]`, and filters the rows of H. FD_WPRUNE also filters rows.
  - Neither updates `ps["HSfull"]`, which `joint()` reads (`tgt_ws = 3 * HSfull[c]`).
  - So any pair that reaches the joint stage (a leaf surviving the local star sums) while boundary points exist crashes.
- **Effect: crash only.**
  - The shapes cannot broadcast, so no verdict was ever computed from misaligned arrays.
  - A crashed job writes no chunk_ok record, so no lattice was ever excluded through such a pair.
  - The same defect is in the v1 engine `frame_dfs.py`: line 1002 extends HS, line 1164 reads HSfull.
  - In about 900 queue jobs, this is the only crash.
- **Fix.** In the generator `make_frame_dfs_next.py`, step 5, `ps["HSfull"] = ps["HS"]` is set after both modifications.
  - New engine sha: 267d2bb5. The diff against 41fbcbff is exactly these two lines.
  - `HSfull` has no other use, so every pair that does not reach the joint stage with boundary points behaves identically.
  - **Checked:** the regenerated stream references are identical to v4 apart from `code_sha`: job 118:2:8, and the 1,200-pair
    stream of 011. So is every calib_v4 check.
- **Soundness of the joint stage with the boundary columns.** The pruning `feas()` needs two facts about every word still to
  choose:
  - parity: (w, z) is odd, because z is characteristic and the words have odd norm;
  - size: |(w, z)| ≤ 1, or 3 at a flex column hit once (slack 2·F1).
  - For an actual frame both hold, by the energy identity at a norm-16 characteristic vector (|(z,u)| = 5 impossible when
    Y_z = 58). This is the same convention as stage 1 already uses for these columns.
  - With HSfull aligned, `joint()` is the exact 42-word search, projected onto the same columns as stage 1.
- **Which pair crashed.** Not located. It lies somewhere in block 5 of 001 (pairs 34,431–41,318, y1 class 4); a backwards scan
  of the last 53 pairs found nothing. With FD_SYM3 + FD_BND the block costs about 5 s per pair here, so a full local scan
  would take hours. The cloud re-run with v5 will compute it.

## 2. Node counts are CPU-dependent (verdicts are not)
- **What the v5 rehearsal showed.** Two rehearsals on a GitHub runner disagreed with the lab on the node counts of the
  retry-path check (pair 365 of 010):
  - same first verdict (INCOMPLETE at 2·10⁵ nodes);
  - same final verdict (EXCLUDED, no local star sums);
  - but depths 3–6 differ by about 1.5 % (for example 604,386 against 595,173).
- **Cause.** `frame_dfs_next` orders the boundary points with an unstable `np.argsort(cnt_)` (line 1450). In numpy 2.5 the tie
  order of the default sort depends on the CPU's SIMD dispatch; the lab PC is X86_V3.
  - The v4 rehearsal runner and the AWS c7a machines happened to match the lab.
  - The v5 runner did not, twice.
- **Consequence.**
  - The search is exhaustive, so verdicts do not depend on the order.
  - Per-pair node counts, and therefore whether a pair hits a node limit, can differ between machines.
  - No exclusion is affected.
  - Calibrations should compare verdicts. They should compare node counts only where the code is order-stable; O24 kernel 3 and
    the stream calibrations matched everywhere.
  - `calib_v4` now compares the retry path on verdicts. The counts are kept as an uncompared diagnostic.
- **Rehearsal 36965488087: PASS.**

## 3. Package v5 and the queue
- **Package:** v4 + engine 267d2bb5 + 10 jobs `001:50..59:170`. These tile block 001:5:17 exactly, since
  ⌊N·k/170⌋ = ⌊N·(k/10)/17⌋, so the block can be redone in parallel.
- **Agent:**
  - `mode_<pkg>` and `max_fail_<pkg>` override `mode_v2`/`mode` and `max_fail`;
  - live control: `max_fail` = 1, so older agents never retry a failed job, and `max_fail_v5` = 3, so v5 agents do.
  - The rehearsal checked this. 010:1:400 carried an earlier FAIL and was still run by the v5 agent.
- **Importer** (`import_golay.py`): an envelope is excluded when the union of the ranges of its chunk_done blocks covers
  [0, N), whatever the block sizes. Tested on a synthetic gap.
- **Machines:** v5 machines replace the others as AWS frees spot capacity. The quota is full in both regions.

## 4. State
- **Tracker 109/156.**
  - New since the last note: 059 (queue).
  - 001: its 17 v3 blocks were still running; 001:5:17 needs v5.
  - 004: 186/330 blocks at 04:15 UTC, all excluded so far.
- **037:** 2 INCOMPLETE stream pairs (chunk 14/18) are being resolved on the PC without a node limit.
  - Tool: `scripts/resolve_incomplete_next.py`, the v5 engine. It records the engine; the earlier `resolve_incomplete.py` used v1.
  - This is one local process, longer than the 5-minute rule. It follows the 049 precedent of the previous night.

## 5. Packages v6 and v7 and the completion rule (2026-10-02, 07:00–12:30 UTC)

### v6: no more INCOMPLETE pairs at the source, and a resolve job kind
- **Stream jobs.** `run_jobs.start` passes node limit 4·10⁹ to `hstage_stream_next.py`, its 4th argument (default 2·10⁸).
  - No engine change.
  - The regenerated 118:2:8 calibration differs from v5 only in `node_limit`.
- **Job kind `resolve`.** `r<lid>:<i>:<m>` searches pair i of `data/resolve/<lid>.json` with no node limit (`scripts/resolve_job.py`,
  the same code as the PC resolver).
- **Rehearsal 36981157786:**
  - job r037:0:28 gave EXCLUDED (stage 1 empty);
  - **286,986,404 nodes, the same count as the PC resolution of the same pair.**

### 037
- Its 30 INCOMPLETE pairs, from 4 chunks, are all EXCLUDED: 5 resolved on the PC and 25 by AWS resolve jobs, without a node limit.
- 037 is now "swept; pending twin classes": the twin types of 045, 046, 047, 048 and 052.

### Completion rule generalised (`scripts/stream_finish.py`)
- A lattice is complete when its done chunks, in any mixture of chunkings, cover all y1 representatives of its plan.
  - Chunk k/n of the producer, run with `--from-plan`, holds representatives k, k+n, k+2n, …
  - With a single chunking this is exactly the former rule.
- **Tests** (isolated copies of the 165 MB stream data):
  - old and new versions give identical trackers: 109 excluded, identical notes;
  - with synthetic sub-chunks of 052 (`k/64`, k ≡ 7 mod 8), 7 of 8 sub-chunks do not complete 052;
  - all 8 complete it, and the twin cascade excludes exactly the 13 predicted lattices.
- The old version is kept as `stream_finish_v1_backup.py`.

### v7: spare sub-jobs
- jobs.json gains, for every job, its sub-jobs, so that a slow job can be split without a new package:
  - stream: `lid:(k+n·j):(8n)`;
  - golay: `lid:(m·k+j):(m·n)`, with m = 10 for 001 and 8 otherwise.
- That is 27,408 stream sub-chunks and 5,908 golay sub-blocks.
- Only jobs.json differs from v6; this is asserted by the builder.
- **Rehearsal 36994383034:** sub-chunk 028:1:64 and sub-block 010:5:128 both completed, all excluded.

### 052 (the cascade's last blocker)
- Job 052:7:8 ran 9.7 h on a v3 machine (31,001 pairs, 14 y1 orbits) and ended with 4 INCOMPLETE pairs at the old 2·10⁸ limit.
- Two routes are running to close them:
  - the PC resolver;
  - its 8 v7 sub-chunks (limit 4·10⁹). Sub-chunk 55/64 took 27 s: 766 pairs, 79 % trapped.
- A simulation on a copy shows the cascade once 052 is complete: **23 lattices excluded**, 109 → **132**.
  - 052, 045–048, 035–043, 037, 031–034;
  - 022, 025, 027, 029, 030, all fully computed meanwhile.

## 6. The cascade (2026-10-02 ~14:50 UTC): 132/156
- The 4 INCOMPLETE pairs of 052:7:8 were resolved on the PC without a node limit (v5 engine). All are EXCLUDED, stage 1 empty, in
  1,790, 2,658, 1,897 and 2,529 s.
- stream_finish then excluded, in one fixed-point pass, exactly the 23 lattices of the simulation:
  - 052, 045–048, 035–043, 037, 031–034;
  - 022, 025, 027, 029, 030.
- **Tracker: 132 excluded, 24 open.**
- A frozen copy of their stream data, the two trackers and the 037 resolve list is in the lab, `data/cascade_snapshot_2026-10-02`,
  with a sha256 manifest. It is the base for the planned study: death mechanisms per lattice, invariants of the hardest pairs,
  the twin-deferral graph.
