#!/bin/bash
# Wait until run verif1b is all_done (at most 40 min), then download its done/ and files/ and summarise.
export MSYS_NO_PATHCONV=1
A="aws --profile frere --region eu-north-1"; B=conway99-c1-runs-733515672125
for i in $(seq 1 160); do
  $A s3 cp s3://$B/runs/verif1b/status.json - 2>/dev/null | grep -q '"all_done": true' && break
  sleep 15
done
mkdir -p collect_verif1b
$A s3 sync s3://$B/runs/verif1b/ collect_verif1b/ --only-show-errors
py -3 -I analyse_p3.py collect_verif1b manifest_verif1.tsv.pilot.json
