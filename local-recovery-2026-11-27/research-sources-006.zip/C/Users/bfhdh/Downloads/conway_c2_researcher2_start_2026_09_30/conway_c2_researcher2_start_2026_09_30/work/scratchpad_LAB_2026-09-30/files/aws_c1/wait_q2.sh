#!/bin/bash
export MSYS_NO_PATHCONV=1
A="aws --profile frere --region eu-north-1"; B=conway99-c1-runs-733515672125
for i in $(seq 1 240); do
  $A s3 cp s3://$B/runs/verif2b/status.json - 2>/dev/null | grep -q '"all_done": true' && break
  sleep 15
done
mkdir -p collect_verif2b
$A s3 sync s3://$B/runs/verif2b/ collect_verif2b/ --only-show-errors
py -3 -I analyse_q2.py
